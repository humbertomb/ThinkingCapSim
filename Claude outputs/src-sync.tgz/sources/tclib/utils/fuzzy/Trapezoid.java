/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.utils.fuzzy;

public class Trapezoid extends FSet
{
	/* Trapezoidal fuzzy sets have the following shape. 
		             ______
	                /      \ 			    y <= 1.0 
	               /        \
	      ________/          \_________ 	y >= 0.0
	             a  b      c  d       
	 */

	private static final int		TPOINTS		= 4;
	private static final double[]	trap_y		= { 0.0, 1.0, 1.0, 0.0 };

	/* Constructors */
	public Trapezoid ()
	{
		this (0.0, 0.0, 0.0, 0.0);
	}

	public Trapezoid (double a, double b, double c, double d)
	{
		int			i;
		
		shape[A].x (a);
		shape[B].x (b);
		shape[C].x (c);
		shape[D].x (d);
		for (i = 0; i < TPOINTS; i++)
			shape[i].y (trap_y[i]);

		mean = (b + c) * 0.5;
	}

	/* Instance methods */

	/* ----------------------------------------------------------- */
	/* Copies a set onto another. 
	 */	
	public FSet dupset ()  
	{
		int			i;
		Trapezoid	s;
		
		s = new Trapezoid (shape[A].x (), shape[B].x (), shape[C].x (), shape[D].x ());
		for (i = 0; i < TPOINTS; i++)
			s.shape[i].y (shape[i].y ());

		return s;
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the degree of membership to a trapezoidal fuzzy set. 
	 */
	public double dmember (double x)  
	{
		double		m, n;
	
  		if ((x == shape[A].x ()) && (shape[A].x () == shape[B].x ()))	return shape[B].y ();
    	if (x <= shape[A].x ())											return shape[A].y ();
    	if ((x == shape[D].x ()) && (shape[C].x () == shape[D].x ()))	return shape[C].y ();
    	if (x >= shape[D].x ())											return shape[D].y ();
    	
    	if ((x >= shape[B].x ()) && (x <= shape[C].x ()))
    	{
			if (shape[B].y () == shape[C].y ())	return shape[B].y ();
			if (shape[B].x () == shape[C].x ())	return shape[B].y ();
			m = (shape[C].y () - shape[B].y ()) / (shape[C].x () - shape[B].x ());
			n = shape[C].y () - m * shape[C].x ();
			return m * x + n;
    	}
    	if (x < shape[B].x ()) 
    	{
			m = (shape[B].y () - shape[A].y ()) / (shape[B].x () - shape[A].x ());
			n = shape[B].y () - m * shape[B].x ();
			return m * x + n;
    	}
    	if (x > shape[C].x ()) 
    	{
			m = (shape[D].y () - shape[C].y ()) / (shape[D].x () - shape[C].x ());
			n = shape[D].y () - m * shape[D].x ();
			return m * x + n;
    	}
		return 0.0;
	}
	
	/* ----------------------------------------------------------- */
	/* Applies an alpha cut to a trapezoidal set.
	 */	
	public FSet alphacut (double alpha)  
	{
		Trapezoid		set;
		
		set = (Trapezoid) dupset ();			
		alphacut (set, alpha);
				
		return set;
	}

	public void alphacut (FSet set, double alpha)  
	{
		double			m, n;
		
		if (shape[A].x () != shape[B].x ())
		{
			m = (shape[B].y () - shape[A].y ()) / (shape[B].x () - shape[A].x ());
			n = shape[B].y () - m * shape[B].x ();
			set.shape[B].x ((alpha - n) / m);
		}
		set.shape[B].y (alpha);
		if (shape[C].x () != shape[D].x ())
		{
			m = (shape[D].y () - shape[C].y ()) / (shape[D].x () - shape[C].x ());
			n = shape[D].y () - m * shape[D].x ();
			set.shape[C].x ((alpha - n) / m);
		}
		set.shape[C].y (alpha);
	}

	/* ----------------------------------------------------------- */
	/* Calculates the integral of a given set. 
	 */
	public double integral ()  
	{
		double		res;
	
		res =  (shape[A].y () + shape[B].y ()) * (shape[B].x () - shape[A].x ()) * 0.5;
		res += (shape[B].y () + shape[C].y ()) * (shape[C].x () - shape[B].x ()) * 0.5;
		res += (shape[C].y () + shape[D].y ()) * (shape[D].x () - shape[C].x ()) * 0.5;

		return res;
	}

	/* ----------------------------------------------------------- */
	/* Calculates the first moment of a given set. 
	 */
	public double moment ()  
	{
		double		res;
	
		res =  (shape[A].y () + shape[B].y ()) * (shape[B].x () - shape[A].x ()) * (shape[B].x () + shape[A].x ()) * 0.25;
		res += (shape[B].y () + shape[C].y ()) * (shape[C].x () - shape[B].x ()) * (shape[C].x () + shape[B].x ()) * 0.25;
		res += (shape[C].y () + shape[D].y ()) * (shape[D].x () - shape[C].x ()) * (shape[D].x () + shape[C].x ()) * 0.25;

		return res;
	}
	
	/* ----------------------------------------------------------- */
	/* Creates a textual representation of the set.
	 */	
	public String toString ()  
	{
		return new String ("[" + shape[0].toString () + ", " + shape[1].toString () + ", " + shape[2].toString () + ", " + shape[3].toString () + "]");
	}	
}
