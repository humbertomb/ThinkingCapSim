/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.utils.fuzzy;

public class Sigmoid extends FSet
{
	/* Constructors */
	public Sigmoid (double a, double b)
	{
		shape[A].x (a);
		shape[B].x (b);
	}

	/* Instance methods */
	
	/* ----------------------------------------------------------- */
	/* Copies a set onto another. 
	 */	
	public FSet dupset ()  
	{
		int			i;
		Sigmoid		s;
		
		s = new Sigmoid (shape[A].x (), shape[B].x ());
		for (i = 0; i < MAXPOINTS; i++)
			s.shape[i].y (shape[i].y ());

		return s;
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the degree of membership to a sigmoidal fuzzy set. 
	 */
	public double dmember (double x)  
	{
		return 1.0 / (1.0 + Math.exp (-shape[B].x () * (x - shape[A].x ())));
	}

	/* ----------------------------------------------------------- */
	/* Applies an alpha cut to a sigmoidal set.
	 */	
	public FSet alphacut (double alpha)  
	{
		Sigmoid		set;
		
		set = (Sigmoid) dupset ();			
		alphacut (set, alpha);
		
		return set;
	}
	
	public void alphacut (FSet set, double alpha)  
	{
		set.shape[D].y (alpha);
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the integral of a given set. 
	 */
	public double integral ()  
	{
		return 1.0;
	}

	/* ----------------------------------------------------------- */
	/* Calculates the first moment of a given set. 
	 */
	public double moment ()  
	{
		return 0.0;
	}
	
	/* ----------------------------------------------------------- */
	/* Creates a textual representation of the set.
	 */	
	public String toString ()  
	{
		return new String ("[" + shape[0].x () + ", " + shape[1].x () + "]");
	}	
}
