/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.utils.fuzzy;

public class Crisp extends FSet
{
	/* Constructors */
	public Crisp (double a)
	{
		shape[A].x (a);
		shape[A].y (1.0);
		
		mean = a;
	}

	/* Instance methods */

	/* ----------------------------------------------------------- */
	/* Copies a set onto another. 
	 */	
	public FSet dupset ()  
	{
		Crisp		s;
		
		s = new Crisp (shape[A].x ());
		s.shape[A].y (shape[A].y ());

		return s;
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the degree of membership to a crisp value. 
	 */
	public double dmember (double x)  
	{
    		if (x == shape[A].x ())		return shape[A].y ();
		return 0.0;
	}

	/* ----------------------------------------------------------- */
	/* Applies an alpha cut to a crisp value.
	 */
	public FSet alphacut (double alpha)  
	{
		Crisp		set;

		set = new Crisp (shape[A].x ());
		alphacut (set, alpha);

		return set;
	}

	public void alphacut (FSet set, double alpha)  
	{
		set.shape[A].y (alpha);
	}

	/* ----------------------------------------------------------- */
	/* Calculates the integral of a given set. 
	 */
	public double integral ()  
	{
		return shape[A].y ();
	}

	/* ----------------------------------------------------------- */
	/* Calculates the first moment of a given set. 
	 */
	public double moment ()  
	{
		return shape[A].y () * shape[A].x ();
	}
	
	/* ----------------------------------------------------------- */
	/* Creates a textual representation of the set.
	 */	
	public String toString ()  
	{
		return new String ("[" + shape[A].x () + "] alpha= " + shape[A].y ());
	}	
}
