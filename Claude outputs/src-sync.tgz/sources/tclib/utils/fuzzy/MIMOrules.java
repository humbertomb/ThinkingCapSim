/*
 * (c) 2001-2002 Humberto Martinez
 */

package tclib.utils.fuzzy;

public class MIMOrules extends Object
{
	protected int							rules;				// Number of rules
	protected int							inputs;				// Number of input variables
	protected int							outputs;			// Number of output variables

	protected FSet[][]						isets;				// Antecedent fuzzy sets
	protected FSet[][]						osets;				// Consequent fuzzy sets
	public double[]							ovars;				// Output variables
	private FSet[][]						f_acut;				// Rule output alpha-cuts (fuzzy sets)
	private double[]						c_acut;				// Rule output alpha-cuts (crisp values)

	// Constructors
	public MIMOrules (int inputs, int outputs, int rules)
	{
		int			i, j;

		this.inputs		= inputs;
		this.outputs	= outputs;
		this.rules		= rules;

		osets			= new FSet[rules][outputs];
		isets			= new FSet[rules][inputs];
		ovars			= new double[outputs];
		f_acut			= new FSet[rules][outputs];
		c_acut			= new double[rules];

		for (i = 0; i < rules; i++)
			for (j = 0; j < outputs; j++)
				f_acut[i][j]		= new Trapezoid ();
	}

	// Instance methods
	public void input_sets (int rule, FSet[] sets)
	{
		int				i;

		if ((rule < 0) || (rule >= rules))		return;
		if (sets == null)						return;

		for (i = 0; (i < inputs) && (i < sets.length); i++)
			isets[rule][i] = sets[i];
	}

	public void input_sets (int rule, FSet set)
	{
		if ((rule < 0) || (rule >= rules))		return;

		isets[rule][0] = set;
	}

	public void input_sets (int rule, FSet set0, FSet set1)
	{
		if ((rule < 0) || (rule >= rules))		return;
		if (inputs < 2)							return;

		isets[rule][0] = set0;
		isets[rule][1] = set1;
	}

	public void output_sets (int rule, FSet[] sets)
	{
		int				i;

		if ((rule < 0) || (rule >= rules))		return;
		if (sets == null)						return;

		for (i = 0; (i < outputs) && (i < sets.length); i++)
			osets[rule][i] = sets[i];
	}

	public void output_sets (int rule, FSet set)
	{
		if ((rule < 0) || (rule >= rules))		return;

		osets[rule][0] = set;
	}

	public void output_sets (int rule, FSet set0, FSet set1)
	{
		if ((rule < 0) || (rule >= rules))		return;
		if (outputs < 2)						return;

		osets[rule][0] = set0;
		osets[rule][1] = set1;
	}

	public void COGinference (double[] ivars)
	{
		int				i, j;
		double			alpha;
		double			mom, sum;

		if ((ivars == null) || (ivars.length < inputs))		return;

		for (i = 0; i < rules; i++)
		{
			// Compute the antecedent of the i-th rule (applying a t-norm)
			alpha = 1.0;
			for (j = 0; j < inputs; j++)
				if (isets[i][j] != null)	alpha = FSet.tnorm (alpha, isets[i][j].dmember (ivars[j]));

			for (j = 0; j < outputs; j++)
				f_acut[i][j].alphacut (osets[i][j], alpha);
		}

		// Compute the inference value of the outputs (centre of gravity)
		for (j = 0; j < outputs; j++)
		{
			mom	= 0.0;
			sum	= 0.0;
			for (i = 0; i < rules; i++)
			{
	     		mom += f_acut[i][j].moment ();
	    		sum += f_acut[i][j].integral ();
    		}

	    	if (sum == 0.0)
	    		ovars[j] = 0.0;    			// No rule applies
	    	else
	    		ovars[j] = (mom / sum);
		}
	}

	public void MOMinference (double[] ivars)
	{
		int				i, j;
		double			alpha;
		double			mom, sum;
		double			degree;

		if ((ivars == null) || (ivars.length < inputs))		return;

		for (i = 0; i < rules; i++)
		{
			// Compute the antecedent of the i-th rule (applying the 'min' t-norm)
			alpha = 1.0;
			for (j = 0; j < inputs; j++)
				if (isets[i][j] != null)
				{
					degree = isets[i][j].dmember (ivars[j]);
					if (degree < alpha)
						alpha = degree;
				}
			c_acut[i]	= alpha;
		}

		// Compute the inference value of the outputs (mean of maximum)
		for (j = 0; j < outputs; j++)
		{
			mom	= 0.0;
			sum	= 0.0;
			for (i = 0; i < rules; i++)
			{
	     		mom += c_acut[i] * osets[i][j].mean ();
	    		sum += c_acut[i];
    		}

	    	if (sum == 0.0)
	    		ovars[j] = 0.0;    			// No rule applies
	    	else
	    		ovars[j] = (mom / sum);
		}
	}
}
