/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.utils.fuzzy;

public class Bell extends FSet
{
	/* Constructors */
	public Bell (double a, double b, double c)
	{
		shape[A].x (a);
		shape[B].x (b);
		shape[C].x (c);
	}

	/* Instance methods */

	/* ----------------------------------------------------------- */
	/* Copies a set onto another. 
	 */	
	public FSet dupset ()  
	{
		int			i;
		Bell		s;
		
		s = new Bell (shape[A].x (), shape[B].x (), shape[C].x ());
		for (i = 0; i < MAXPOINTS; i++)
			s.shape[i].y (shape[i].y ());

		return s;
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the degree of membership to a bell-like fuzzy set. 
	 */
	public double dmember (double x)  
	{
/*
		b	=  Math.pow (2.0, shape[C].x ());
		a	=   (x - shape[A].x ()) / shape[B].x ();
		m	=  Math.exp (-Math.pow (a, b));
*/
		return 1.0 / (1.0 + Math.pow (Math.abs ((x - shape[C].x ()) / shape[A].x ()), 2 * shape[B].x ()));
	}

	/* ----------------------------------------------------------- */
	/* Applies an alpha cut to a bell-like set.
	 */	
	public FSet alphacut (double alpha)  
	{
		Bell			set;
		
		set = (Bell) dupset ();			
		alphacut (set, alpha);
		
		return set;
	}
	
	public void alphacut (FSet set, double alpha)  
	{
		set.shape[D].y (alpha);
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the integral of a given set. 
	 */
	public double integral ()  
	{
		return 1.0;
	}

	/* ----------------------------------------------------------- */
	/* Calculates the first moment of a given set. 
	 */
	public double moment ()  
	{
		return 0.0;
	}
	
	/* ----------------------------------------------------------- */
	/* Creates a textual representation of the set.
	 */
	public String toString ()  
	{
		return new String ("[" + shape[A].x () + ", " + shape[B].x ()  + ", " + shape[C].x () + "]");
	}	
}
