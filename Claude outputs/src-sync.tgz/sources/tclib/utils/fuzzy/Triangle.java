/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.utils.fuzzy;

public class Triangle extends FSet
{
	/* Tiangular fuzzy sets have the following shape. 
		             
	                /\			    y <= 1.0 
	               /  \
	      ________/    \_________	y >= 0.0
	             a   b  c      
	 */

	public static final int				POINTS		= 3;
	private static final double[]		tri_y		= { 0.0, 1.0, 0.0 };

	/* Constructors */
	public Triangle (double a, double b, double c)
	{
		int			i;
		
		shape[A].x (a);
		shape[B].x (b);
		shape[C].x (c);
		for (i = 0; i < POINTS; i++)
			shape[i].y (tri_y[i]);
			
		shape[D].x (shape[C].x ());
		shape[D].y (shape[C].y ());
		
		mean = b;
	}

	/* Instance methods */
	
	/* ----------------------------------------------------------- */
	/* Copies a set onto another. 
	 */	
	public FSet dupset ()  
	{
		int			i;
		Triangle	s;
		
		s = new Triangle (shape[A].x (), shape[B].x (), shape[C].x ());
		for (i = 0; i < MAXPOINTS; i++)
			s.shape[i].y (shape[i].y ());

		return s;
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the degree of membership to a triangular fuzzy set. 
	 */
	public double dmember (double x)  
	{
		double		m, n;
	
    	if (x <= shape[A].x ())					return shape[A].y ();
    	if (x >= shape[C].x ())					return shape[C].y ();
    	if (x <= shape[B].x ()) 
    	{
			m = (shape[B].y () - shape[A].y ()) / (shape[B].x () - shape[A].x ());
			n = shape[B].y () - m * shape[B].x ();
			return m * x + n;
    	}
    	if (x > shape[B].x ()) 
    	{
			m = (shape[C].y () - shape[B].y ()) / (shape[C].x () - shape[B].x ());
			n = shape[C].y () - m * shape[C].x ();
			return m * x + n;
    	}
		return 0.0;
	}

	/* ----------------------------------------------------------- */
	/* Applies an alpha cut to a triangular set.
	 */
	
	public FSet alphacut (double alpha)  
	{
		Triangle		set;
		
		set = new Triangle (shape[A].x (), 0.0, shape[C].x ());
		alphacut (set, alpha);
		
		return set;
	}

	public void alphacut (FSet set, double alpha)  
	{
		double		m, n;
		
		set.shape[A].y (shape[A].y ());
		set.shape[B].y (alpha);
		set.shape[C].y (alpha);
		set.shape[D].y (shape[C].y ());
			
		if (shape[A].x () != shape[B].x ())
		{
			m = (shape[B].y () - shape[A].y ()) / (shape[B].x () - shape[A].x ());
			n = shape[B].y () - m * shape[B].x ();
			set.shape[B].x ((alpha - n) / m);
		}
		else
			set.shape[B].x (shape[A].x ());
		if (shape[C].x () != shape[D].x ())
		{
			m = (shape[C].y () - shape[B].y ()) / (shape[C].x () - shape[B].x ());
			n = shape[C].y () - m * shape[C].x ();
			set.shape[C].x ((alpha - n) / m);
		}
		else
			set.shape[C].x (shape[C].x ());
	}

	/* ----------------------------------------------------------- */
	/* Calculates the integral of a given set. 
	 */

	public double integral ()  
	{
		double		res;
	
		res =  (shape[A].y () + shape[B].y ()) * (shape[B].x () - shape[A].x ()) * 0.5;
		res += (shape[B].y () + shape[C].y ()) * (shape[C].x () - shape[B].x ()) * 0.5;
		res += (shape[C].y () + shape[D].y ()) * (shape[D].x () - shape[C].x ()) * 0.5;

		return res;
	}

	/* ----------------------------------------------------------- */
	/* Calculates the first moment of a given set. 
	 */

	public double moment ()  
	{
		double		res;
		
		res =  (shape[A].y () + shape[B].y ()) * (shape[B].x () - shape[A].x ()) * (shape[B].x () + shape[A].x ()) * 0.25;
		res += (shape[B].y () + shape[C].y ()) * (shape[C].x () - shape[B].x ()) * (shape[C].x () + shape[B].x ()) * 0.25;
		res += (shape[C].y () + shape[D].y ()) * (shape[D].x () - shape[C].x ()) * (shape[D].x () + shape[C].x ()) * 0.25;

		return res;
	}
	
	/* ----------------------------------------------------------- */
	/* Creates a textual representation of the set.
	 */	
	public String toString ()  
	{
		return new String ("[" + shape[0].toString () + ", " + shape[1].toString () + ", " + shape[3].toString () + "]");
	}	
}
