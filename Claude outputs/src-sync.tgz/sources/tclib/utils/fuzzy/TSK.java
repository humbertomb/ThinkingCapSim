/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.utils.fuzzy;

import tclib.behaviours.bg.interpreter.*;

import wucore.utils.geom.*;

public class TSK extends FSet
{
	protected String[]					vars;
	protected Interpreter				exec;
	
	/* Constructors */
	public TSK (Interpreter e, String[] v, double[] c)
	{
		int			i, n;
		
		n		= v.length;
		shape 	= new Point2 [n + 1];
		vars	= new String [n];
		exec	= e;
		
		for (i = 0; i < n + 1; i++)
			if ( c != null)
				shape[i] 	= new Point2 (c[i], 1.0);
			else
				shape[i] 	= new Point2 (0.0, 1.0);

		for (i = 0; i < n; i++)
			vars[i] 	= v[i];
	}

	/* Instance methods */

	/* ----------------------------------------------------------- */
	/* Copies a set onto another. 
	 */	
	public FSet dupset ()  
	{
		TSK			set;
		int			i;
		
		set = new TSK (exec, vars, null);
		for (i = 0; i < set.shape.length; i++)
		{
			set.shape[i].x (shape[i].x ());
			set.shape[i].y (shape[i].y ());
		}

		return set;
	}
	
	/* ----------------------------------------------------------- */
	/* Calculates the degree of membership to a TSK consequent  (NONSENSE). 
	 */
	public double dmember (double x)  
	{
		return 0.0;
	}

	/* ----------------------------------------------------------- */
	/* Applies an alpha cut to a TSK consequent.
	 */
	public FSet alphacut (double alpha)  
	{
		TSK			set;

		set = new TSK (exec, vars, null);
		alphacut (set, alpha);

		return set;
	}

	public void alphacut (FSet set, double alpha)  
	{
		int			i;

		for (i = 0; i < set.shape.length; i++)
		{
			set.shape[i].x (shape[i].x ());
			set.shape[i].y (alpha);
		}
	}

	/* ----------------------------------------------------------- */
	/* Calculates the integral of a given set. 
	 */
	public double integral ()  
	{
		return shape[A].y ();
	}

	/* ----------------------------------------------------------- */
	/* Calculates the first moment of a given set. 
	 */
	public double moment ()  
	{
		int			i;
		double		s;

		/* Rule format: f = c + ax1 + bx2 */
		s = shape[A].x ();
		for (i = 1; i < shape.length; i++)
			s += shape[i].x () * exec.access (vars[i - 1]);
		
		return s * shape[A].y ();
	}
	
	/* ----------------------------------------------------------- */
	/* Creates a textual representation of the set.
	 */	
	public String toString ()  
	{
		String		str;
		int			i;
		
		str = "[";
		for (i = 0; i < shape.length - 1; i++)
			str += shape[i].x () + ", ";
		str += shape[i].x () + "] alpha= " + shape[A].y ();
		
		return str;
	}	
}
