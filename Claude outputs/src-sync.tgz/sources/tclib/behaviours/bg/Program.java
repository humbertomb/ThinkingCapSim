/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

import java.io.*;

public class Program  extends Object
{
	protected VSymbol		vars;
	protected Function		funcs;
	protected Command		init;
	protected Agent			agts;
	
	/* Constructors */
	public Program ()
	{
	}
	
	public Program (VSymbol vars, Function funcs, Command init, Agent agts)
	{
		this.vars			= vars;
		this.funcs			= funcs;
		this.init			= init;
		this.agts			= agts;
	}
	

	/* Accessor methods */
	public final VSymbol 	vars () 				{ return vars; }
	public final Function 	funcs () 				{ return funcs; }
	public final Command 	init () 				{ return init; }
	public final Agent 		agts () 				{ return agts; }

	/* Instance methods */
	public int behcount ()
	{
		int				count;
		Agent			a;
		
		count = 0;
		a = agts;
		while (a != null)
		{
			count += a.behs ().count ();
			a = (Agent) a.next ();
		}
		return count;
	}
	
	public String[] behlabels ()
	{
		int					i;
		Agent				a;
		Behaviour			b;
		String[]				label;
		
		label	= new String [behcount ()];
		i 		= 0;
		a 		= agts;
		while (a != null)
		{
			b = a.behs ();
			while (b != null)
			{
				label[i] = b.name ();
				i ++;
				b = (Behaviour) b.next ();
			}
			a = (Agent) a.next ();
		}
		return label;
	}
	
	public String[] behlabels (Agent a)
	{
		int					i;
		Behaviour			b;
		String[]				label;
		
		i 		= 0;
		b 		= a.behs ();
		label	= new String [b.count ()];
		while (b != null)
		{
			label[i] = b.name ();
			i ++;
			b = (Behaviour) b.next ();
		}
		return label;
	}
	
	public Agent getAgent (String name)
	{
		Agent			p;
		
		p = agts;
		while (p != null)
		{
			if (p.name () == name) 
				return p;
			p = (Agent) p.next ();
		}
		return null;
	}
	
	public void fwrite (String name) 
	{
		File					file;
		BufferedOutputStream	output;
		VSymbol					vs;
		Agent					ag;
		Command					cs;
		Function				fn;
		
		file = new File (name);
		if (file.length () > 0)
		{
			System.out.println ("Creating backup file \"" + name + ".bak\"  ");
			file.renameTo (new File (name + ".bak"));
			file = new File (name);
		}

		System.out.println ("Writing program to file \"" + name + "\"  ");
		try 
		{
			output = new BufferedOutputStream (new FileOutputStream (file));
			
			// write global variables
			vs 	= vars;
			while (vs != null)
			{
				if (!vs.istmp ())
				{
					write (output, vs.toString ());
					write (output, "\n");
				}
				vs	= (VSymbol) vs.next ();
			}
			
			// write functions
			fn	= funcs;
			while (fn != null)
			{
				write (output, fn.toString ());
				write (output, "\n");
				fn	= (Function) fn.next ();
			}
			
			// write initialization block
			if (init != null)
			{
				write (output, "initialization \n{\n");
				cs 	= init;
				while (cs != null)
				{
					write (output, "\t\t" + cs.toString () + "\n");
					cs = (Command) cs.next ();
				}
				write (output, "}\n\n");
			}
		
			// write agents
			ag	= agts;
			while (ag != null)
			{
				write (output, ag.toString ());
				write (output, "\n");
				ag	= (Agent) ag.next ();
			}
			
			output.flush ();
			output.close (); 
		} catch (Exception e) 
		{
			BGParser.error ("Error writing in \"" + name + "\": " + e.toString ());
			return;
		}
		System.out.println ("Ok.");
	}
	
	private void write (BufferedOutputStream output, String str)
	{
		int				i;
		
		try
		{
			for (i = 0; i < str.length (); i++)
				output.write ((int) str.charAt (i));
				
			output.flush ();
		} catch (Exception e) 
		{
			BGParser.warning ("Error writing chars to file: " + e.toString ());
		}
	}
}
