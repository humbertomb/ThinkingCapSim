/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

public class Pairs extends java.lang.Object
{
	protected Pair[]			pair;
	protected int				n;
	protected double			alpha;
	private int				k;

	/* Constructors */
	private Pairs ()
	{
	}
	
	public Pairs (int n)
	{
		this.create (n);
	}
	
	/* Accessor methods */
	public final int	 		n () 					{ return n; }
	public final double	 	alpha () 				{ return alpha; }
	public final void	 	alpha (double alpha) 	{ this.alpha = alpha; }

	/* Instance methods */
	private void create (int n)
	{
		this.k		= 0;
		this.n		= n;
		this.pair		= new Pair [n];
	}
	
	public void add (Pair v)
	{
		if (k >= n) return;
		
		pair[k] = v;
		k++;
	}
	
	public void add (Store src, Store ptr)
	{
		add (new Pair (src, ptr));
	}
	
	public Pair at (int i)
	{
		if ((i < 0) || (i >= n)) return null;
		return pair[i];
	}
	
	public void at (int i, Pair v)
	{
		if ((i < 0) || (i >= n)) return;
		pair[i] = v;
	}

	public void update ()
	{
		Pair		p;
		int			i;
		
		for (i = 0; i < n; i++)
		{
			p = pair[i];
			if (p != null)
				p.update ();
		}
	}
}
