/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

public class SVar extends java.lang.Object
{
	protected String			name;
	protected double			min;
	protected double			max;
	protected double			steps;

	/* Constructors */
	private SVar ()
	{
	}
	
	public SVar (String name, double min, double max, double steps)
	{
		this.create (name, min, max, steps);
	}
	
	/* Accessor methods */
	public final String	 	name () 				{ return name; }
	public final double	 	min () 					{ return min; }
	public final double 	max () 					{ return max;  }
	public final double 	steps () 				{ return steps;  }

	/* Instance methods */
	private void create (String name, double min, double max, double steps)
	{
		this.name		= name;
		this.min		= min;
		this.max		= max;
		this.steps		= steps;
	}
}
