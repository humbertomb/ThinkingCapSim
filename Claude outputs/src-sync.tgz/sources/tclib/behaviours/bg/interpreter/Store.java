/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

public class Store extends java.lang.Object
{
	protected double				value;

	/* Constructors */
	public Store ()
	{
		this.create (0.0);
	}
	
	public Store (double value)
	{
		this.create (value);
	}
	
	/* Accessor methods */
	public final double	 	value () 				{ return value; }
	public final void 		value (double value) 	{ this.value = value; }

	/* Instance methods */
	private void create (double value)
	{
		this.value		= value;
	}
}
