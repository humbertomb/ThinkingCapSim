/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

public class Fusion extends java.lang.Object
{
	protected Pairs[]			pairs;
	protected int				max;
	private int				n;

	/* Constructors */
	private Fusion ()
	{
	}
	
	public Fusion (int max)
	{
		this.create (max);
	}
	
	/* Accessor methods */
	public final int	 	n () 					{ return n; }

	/* Instance methods */
	private void create (int max)
	{
		this.n		= 0;
		this.max		= max;
		this.pairs		= new Pairs [max];
	}
	
	public void add (Pairs v)
	{
		if (n >= max) return;
		
		pairs[n] = v;
		n++;
	}
	
	public Pairs at (int i)
	{
		if ((i < 0) || (i >= max)) return null;
		return pairs[i];
	}
	
	protected void at (int i, Pairs v)
	{
		if ((i < 0) || (i >= max)) return;
		pairs[i] = v;
	}

	public void update ()
	{
		Pairs		p;
		int			i;
		
		for (i = 0; i < n; i++)
		{
			p = pairs[i];
			if (p != null)
				p.update ();
		}
	}

	public void fusion ()
	{

		int		i, j, k, l;
		int		vs;
		boolean		modi;
		double		sum, div;
		Pair		out;
	
		if (n == 0) return;
	
		/* Check how many different output variables we have */
		vs = 0;	
		for (i = 0; i < n; i++)
    		{
    		for (j = 0; j < pairs[i].n (); j++)
    		{
    			modi = false;
				for (k = 0; k < i; k++)
					for (l = 0; l < pairs[k].n (); l++)
						if (pairs[i].at (j).src () == pairs[k].at (l).src ())
						{
							pairs[i].at (j).hash (pairs[k].at (l).hash ());
							modi = true;
						}
				for (l = 0; l < j; l++)
					if (pairs[i].at (j).src () == pairs[i].at (l).src ())
					{
						pairs[i].at (j).hash (pairs[i].at (l).hash ());
						modi = true;
					}
				
				if (!modi)
				{
					pairs[i].at (j).hash (vs);
					vs ++;
				}
			}
		}
	
		/* Apply fusion to each different output variable */
		for (k = 0; k < vs; k++)
    		{
    			sum = 0.0;
    			div = 0.0;
    			out = null;
    			for (i = 0; i < n; i++)
			{
				for (j = 0; j < pairs[i].n (); j++)
    				{
    					if (pairs[i].at (j).hash () == k)
    					{
    						out = pairs[i].at (j);
    						sum += pairs[i].alpha () * pairs[i].at (j).ptr ().value ();
    						div += pairs[i].alpha ();
    					}
    				}
    			}
    	
    			if (div == 0.0)
    				out.src ().value (0.0);   	// No rule applies 
    			else 	
    				out.src ().value (sum / div);    	
		}
	}
}
