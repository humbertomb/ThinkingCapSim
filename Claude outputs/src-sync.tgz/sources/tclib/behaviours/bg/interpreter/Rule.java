/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

import tclib.utils.fuzzy.*;

public class Rule extends Object
{
	public static final int		NOHASH		= -1;
	
	protected int				hash;
	protected Store			sto;
	protected FSet				output;

	/* Constructors */
	private Rule ()
	{
	}
	
	public Rule (Store sto, FSet output)
	{
		this.create (sto, output);
	}
	
	/* Accessor methods */
	public final int	 		hash () 				{ return hash; }
	public final void 		hash (int hash) 		{ this.hash = hash; }
	public final Store	 	sto () 				{ return sto; }
	public final FSet 		output () 				{ return output;  }

	/* Instance methods */
	private void create (Store sto, FSet output)
	{
		this.hash		= NOHASH;
		this.sto		= sto;
		this.output	= output.dupset ();
	}
}
