/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

import java.util.*;

import tclib.behaviours.bg.*;
import tclib.utils.fuzzy.*;

import devices.pos.*;

public class Interpreter extends Object
{
	public static final int			MAXVARS			= 150;
	public static final int			MAXLOCS			= 100;
	public static final int			MAXSETS			= 75;
	public static final int			MAXFUNCS		= 75;
	public static final int			MAXSTATES		= 75;
	private static final int		VARSPERLINE		= 5;
	
	protected Hashtable<String, Store>	globals;
	protected Hashtable<String, FSet>	sets;
	protected Hashtable<String, Function>	funcs;
	protected Hashtable<String, String>	states;
	protected Stack<Hashtable<String, Store>>	env;
	protected boolean				finished		= false;			// Only for DEBUG mode
	protected boolean				debug			= false;			// Only for DEBUG mode
	protected boolean				verbose			= false;
	private Position				position;
	
	/* Constructors */
	public Interpreter ()
	{
		globals		= new Hashtable<String, Store> (MAXVARS);
		sets 		= new Hashtable<String, FSet> (MAXSETS);
		funcs 		= new Hashtable<String, Function> (MAXFUNCS);
		states 		= new Hashtable<String, String> (MAXSTATES);
		env			= new Stack<Hashtable<String, Store>> ();
		position	= new Position ();
	}
	
	/* Accessors */	
	public boolean 	finished ()			{ return finished; }
	
	/* Class methods */
	public static String[] getAgents (Program prg)
	{
		int				i, n;
		String[]			list;
		Agent			p;
		
		p = prg.agts ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			list[i] = p.name ();
			i ++;
			p = (Agent) p.next ();
		}
		return list;
	}

	public static String[] getFunctions (Program prg)
	{
		int				i, n;
		String[]			list;
		Function			p;
		
		p = prg.funcs ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			list[i] = p.name ();
			i ++;
			p = (Function) p.next ();
		}
		return list;
	}

	public static String[] getParams (String name, Program prg)
	{
		int				i, n;
		String[]			list;
		Function 			func;
		VSymbol			p;
		
		func = (Function) prg.funcs ().search (name);
		if (func == null)
			return new String [0];
			
		p = func.params ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			list[i] = p.name ();
			i ++;
			p = (VSymbol) p.next ();
		}
		return list;
	}

	public static String[] getVariables (Program prg)
	{
		int				i, n;
		String[]			list;
		VSymbol			p;
		
		p = prg.vars ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			if (p.type () == VSymbol.NUMBER)
			{
				list[i] = p.name ();
				i ++;
			}
			p = (VSymbol) p.next ();
		}
		return list;
	}

	public static String[] getSensors (Program prg)
	{
		int				i, n;
		String[]			list;
		VSymbol			p;
		
		if (prg.vars () == null)
			return new String [0];
			
		n = 0;
		p = prg.vars ();
		while (p != null)
		{
			if ((p.type () == VSymbol.NUMBER) && (p.subtype () == VSymbol.N_SENSOR))
				n ++;
			p = (VSymbol) p.next ();
		}
		
		list = new String [n];
		i = 0;
		p = prg.vars ();
		while (p != null)
		{
			if ((p.type () == VSymbol.NUMBER) && (p.subtype () == VSymbol.N_SENSOR))
			{
				list[i] = p.name ();
				i ++;
			}
			p = (VSymbol) p.next ();
		}
		
		return list;
	}

	public static String[] getBlackb (String name, Program prg)
	{
		int				i, n;
		String[]			list;
		Agent			agent;
		VSymbol			p;
		
		agent = (Agent) prg.agts ().search (name);
		if (agent == null)
			return new String [0];
			
		p = agent.black ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			list[i] = p.ptr ().name ();
			i ++;
			p = (VSymbol) p.next ();
		}
		return list;
	}

	public static String[] getBehaviours (String name, Program prg)
	{
		int				i, n;
		String[]			list;
		Agent			agent;
		Behaviour		p;
		
		agent = (Agent) prg.agts ().search (name);
		if (agent == null)
			return new String [0];
			
		p = agent.behs ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			list[i] = p.name ();
			i ++;
			p = (Behaviour) p.next ();
		}
		return list;
	}

	public static String[] getFusion (String aname, String bname, Program prg)
	{
		int				i, n;
		String[]			list;
		Agent			agent;
		Behaviour		beh;
		VSymbol			p;
		
		agent = (Agent) prg.agts ().search (aname);
		if (agent == null)
			return new String [0];
			
		beh = (Behaviour) agent.behs ().search (bname);
		if (beh == null)
			return new String [0];
			
		p = beh.out ();
		if (p == null)
			return new String [0];
			
		n = p.count ();
		list = new String [n];
		i = 0;
		while (p != null)
		{
			list[i] = p.name ();
			i ++;
			p = (VSymbol) p.next ();
		}
		return list;
	}

	/* Instance methods */
	public void reset ()
	{
		// Initialize states
		states 		= new Hashtable<String, String> (MAXSTATES);
	}
	
	public void fusion (Program prg, double[] buffer)
	{
		int			i;
		Agent		a;
		Behaviour	b;
		
		i = 0;
		a = prg.agts ();		
		while (a != null)
		{
			b = a.behs ();
			while (b != null)
			{
				buffer[i] = access (b.name ());
				i ++;
				b = (Behaviour) b.next ();
			}
			a = (Agent) a.next ();
		}
	}

	protected void symbols (VSymbol ids, Function fs)
	{
		VSymbol 		p;
		Function		f;
	
		// Add up global variables and sets definitions
		p = ids;
		while (p != null)
		{
			if (debug) BGParser.debug ("Variable <" + p.name () + ">");
			
			switch (p.type ())
			{
			case VSymbol.NUMBER:
				switch (p.subtype ())
				{
				case VSymbol.N_VAR:
				case VSymbol.N_EFFECTOR:
				case VSymbol.N_STATUS:
					globals.put (p.name (), new Store (p.number ().doubleValue ()));
					break;
				case VSymbol.N_EXTERNAL:
				case VSymbol.N_SENSOR:
					globals.put (p.name (), new Store ());
					break;
				default:
					/* Do nothing */;
				}
				break;
			case VSymbol.SET:
				addset (p);
				break;
			case VSymbol.TUPLE:
				if (!isglobal (ids, p.set ()))
					addset (p.set ());
				break;
			default:
				/* Do nothing */;
			}
			p = (VSymbol) p.next ();
		}
	
		// Add up function names
		f = fs;
		while (f != null)
		{
			funcs.put (f.name (), f);
			f = (Function) f.next ();
		}
	}
	
	protected String sensors (VSymbol ids)
	{
		VSymbol 		p;
		String			out;
		
		out	= "(";
		p	= ids;
		while (p != null)
		{
			if (p.type () == VSymbol.NUMBER)
			{
				switch (p.subtype ())
				{
				case VSymbol.N_STATUS:
				case VSymbol.N_SENSOR:
					out += "(" + p.name () + " 0)";
					break;
				default:
					/* Do nothing */;
				}
			}
			p = (VSymbol) p.next ();
		}
		out	+= ")";
		return out;
	}

	protected String effectors (VSymbol ids)
	{
		VSymbol 		p;
		String			out;
		
		out	= "(";
		p	= ids;
		while (p != null)
		{
			if (p.type () == VSymbol.NUMBER)
			{
				switch (p.subtype ())
				{
				case VSymbol.N_STATUS:
				case VSymbol.N_EFFECTOR:
					out += "(" + p.name () + " " + access (p.name (), null) + ")";
					break;
				default:
					/* Do nothing */;
				}
			}
			p = (VSymbol) p.next ();
		}
		out	+= ")";
		return out;
	}

	protected double expresion (Expresion exp, int env, VSymbol out, Hashtable<String, Store> locals) throws InterpreterException
	{
		VSymbol			id;
		FSet				set;
	
		if (exp == null)
		{
//			BGParser.error ("Empty expresion");
			return 0.0;
		}

		if (debug) BGParser.debug ("       Expresion <ari=" + exp.arity () + "/type=" + exp.type () + ">");
			
		switch (exp.arity ())
		{
		case Expresion.TERMINAL:
			switch (exp.type ())
			{
			case Expresion.SYMBOL:
				id = exp.id ();
				if (debug) VSymbol.dump (id);
				switch (id.type ())
				{
				case VSymbol.NUMBER:
					switch (id.subtype ())
					{
					case VSymbol.N_CONSTANT:
						return id.number ().doubleValue ();
					default:
						return access (isout(out, id.name ()), locals);
					}
				case VSymbol.TUPLE:
					if (id.set ().type () == VSymbol.NUMBER)
						addset (id.set ());
					set = set (id.set ().name ());
					return set.dmember (access (isout(out, id.source ()), locals));
				default:
					/* Do Nothing */
				}
				break;
			case Expresion.FUNCTION:
				return function (function (exp.com ().name ()), exp.com ().params (), out, locals);
			default:
				/* Do Nothing */
			}
			break;
		case Expresion.UNARY:
			switch (exp.type ())
			{
			case Expresion.NOT:
				if (env == Command.FRULE)
					return FSet.not (expresion (exp.exp1 (), env, out, locals));
				else
					return FSet.not (expresion (exp.exp1 (), env, out, locals));
			default:
				/* Do Nothing */
			}
			break;
		case Expresion.BINARY:
			switch (exp.type ())
			{
			case Expresion.AND:
				if (env == Command.FRULE)
					return FSet.tnorm (expresion (exp.exp1 (), env, out, locals), expresion (exp.exp2 (), env, out, locals));
				else
				{
					if (FSet.fif (expresion (exp.exp1 (), env, out, locals)) && FSet.fif (expresion (exp.exp2 (), env, out, locals)))
						return 1.0;
					else
						return 0.0;
				}
			case Expresion.OR:
				if (env == Command.FRULE)
					return FSet.tconorm (expresion (exp.exp1 (), env, out, locals), expresion (exp.exp2 (), env, out, locals));
				else
				{
					if (FSet.fif (expresion (exp.exp1 (), env, out, locals)) || FSet.fif (expresion (exp.exp2 (), env, out, locals)))
						return 1.0;
					else
						return 0.0;
				}
			case Expresion.EQUAL:
				if (expresion (exp.exp1 (), env, out, locals) == expresion (exp.exp2 (), env, out, locals))
					return 1.0;
				else
					return 0.0;
			case Expresion.NE:
				if (expresion (exp.exp1 (), env, out, locals) != expresion (exp.exp2 (), env, out, locals))
					return 1.0;
				else
					return 0.0;
			case Expresion.GT:
				if (expresion (exp.exp1 (), env, out, locals) > expresion (exp.exp2 (), env, out, locals))
					return 1.0;
				else
					return 0.0;
			case Expresion.GE:
				if (expresion (exp.exp1 (), env, out, locals) != expresion (exp.exp2 (), env, out, locals))
					return 1.0;
				else
					return 0.0;
			case Expresion.LT:
				if (expresion (exp.exp1 (), env, out, locals) < expresion (exp.exp2 (), env, out, locals))
					return 1.0;
				else
					return 0.0;
			case Expresion.LE:
				if (expresion (exp.exp1 (), env, out, locals) <= expresion (exp.exp2 (), env, out, locals))
					return 1.0;
				else
					return 0.0;
			case Expresion.PLUS:
				return expresion (exp.exp1 (), env, out, locals) + expresion (exp.exp2 (), env, out, locals);
			case Expresion.MINUS:
				return expresion (exp.exp1 (), env, out, locals) - expresion (exp.exp2 (), env, out, locals);
			case Expresion.TIMES:
				return expresion (exp.exp1 (), env, out, locals) * expresion (exp.exp2 (), env, out, locals);
			case Expresion.DIV:
				return expresion (exp.exp1 (), env, out, locals) / expresion (exp.exp2 (), env, out, locals);
			case Expresion.IS:
				id = exp.exp2 ().id ();
				if ((id != null) && (id.type () == VSymbol.SET))
				{
					set = set (id.name ());
					return set.dmember (expresion (exp.exp1 (), env, out, locals));
				}
				else if ((id != null) && (id.type () == VSymbol.NUMBER))
				{
					addset (id);
					set = set (id.name ());
					return set.dmember (expresion (exp.exp1 (), env, out, locals));
				}
				else
					BGParser.error ("Second operand of IS must be a fuzzy set or crisp value");
				return 0.0;
			default:
				/* Do Nothing */
			}
			break;
		default:
			/* Do nothing */;
		}
		
		BGParser.error ("Malformed expresion");
		return 0.0;
	}
	
	protected double function (Function func, VSymbol params, VSymbol out, Hashtable<String, Store> locals) throws InterpreterException
	{
		VSymbol			s, t;
		Command			c;
		Hashtable<String, Store>	ltemp;
		double			ret;		
		int			f, a;
		
		if (verbose) BGParser.debug ("       Function <" + func.name () + ">");
		
		f = func.params ().count ();
		a = params.count ();
		if (a < f)
			BGParser.error ("Different number of actual=" + a + "/formal=" + f + " parameters in function <" + func.name () + ">");

		try
		{
			env.push (locals);							// Create a new execution environment
		} catch (Exception e)
		{
			BGParser.error ("Too many recursion levels in function <" + func.name () + ">");
		}
		ltemp = new Hashtable<String, Store> (MAXLOCS);
		s = func.params ();
		t = params;
		while ((s != null) && (t != null))
		{
			ltemp.put (s.name (), new Store (access (isout (out, t.name ()), locals)));
			s = (VSymbol) s.next ();
			t = (VSymbol) t.next ();
		}
		locals = ltemp;
		locals.put ("return", new Store (0.0));
		s = func.loc ();
		while (s != null)
		{
			if (s.type () == VSymbol.NUMBER)
				locals.put (s.name (), new Store (s.number ().doubleValue ()));
			else
				BGParser.error ("Wrong <" + s.name () + "> type for local variable");
			s = (VSymbol) s.next ();
		}
		
		if (verbose) dumplocals (locals);
		c = func.com ();
		while ((c = nextfsm (c)) != null)
		{
			if (!states.containsKey (c.uniq ()))
				states.put (c.uniq (), c.name ());
			c = (Command) c.next ();
		}

		try { commands (func.com (), null, locals); }
		catch (StateException e) { }
		catch (ReturnException e) { }
		
		ret = access ("return", locals);
		locals = env.pop ();				// Restore execution environment
		
		if (verbose) BGParser.debug ("       End Function <" + func.name () + ">");
		return ret;
	}

	protected void commands (Command coms, VSymbol out, Hashtable<String, Store> locals) throws InterpreterException
	{
		Command		p, t;
			
		p = coms;
		while (p != null)
		{
			if (debug) BGParser.debug ("     Command <" + p.type () + ">");
			
			try
			{
				switch (p.type ())
				{
				case Command.ASSIGN:
					if (debug) VSymbol.dump (p.id ());

					access (isout (out, p.id ().name ()), expresion (p.exp (), Command.ASSIGN, out, locals), locals);
					break;
				case Command.PRINTF:
					System.out.println ("<" + p.id ().name () + "> = " + access (isout (out, p.id ().name ()), locals));
					break;
				case Command.HALT:
					throw new HaltException ("Halting program");
				case Command.IFTHEN:
					if (FSet.fif (expresion (p.exp (), Command.IFTHEN, out, locals)))
						commands (p.block (), out, locals);
					break;
				case Command.IFELSE:
					if (FSet.fif (expresion (p.exp (), Command.IFELSE, out, locals)))
						commands (p.block (), out, locals);
					else
						commands (p.other (), out, locals);
					break;
				case Command.FSM:
//System.out.println ("  [Intpr] Executing STATE=" + state (p.uniq ()));

					t = slookup (p.block (), state (p.uniq ()));
					if (t != null)
						commands (t.block (), out, locals);
					else
						BGParser.error ("No state to go with in <FSM> command");
					break;
				case Command.RULES:
					Rules		rs;
				
					rs = new Rules (p.block ().count ());
					fcommands (p.block (), out, rs, locals);
					rs.inference ();
					break;
				case Command.SHIFT:
					t = p.parent (). parent ();
					state (t.uniq (), p.name ());
					throw new StateException ("Shift to new state");
				case Command.STATE:
					BGParser.warning ("Execution should not reach a <STATE> command");
					break;
				case Command.CALL:
					function (function (p.name ()), p.params (), out, locals);
					break;
				case Command.RETURN:
					access ("return", expresion (p.exp (), Command.RETURN, out, locals), locals);
					throw new ReturnException ("Return from function");
				default:
					/* Do nothing */;
				}
			}
			catch (NullPointerException e)
			{
				if (debug) BGParser.debug (" Exception in command <" + p.type () + ">");
				throw new AbortException ("Aborting program");
			}

			p = (Command) p.next ();
		}
	}

	protected void fcommands (Command coms, VSymbol out, Rules rs, Hashtable<String, Store> locals) throws InterpreterException
	{
		Command		p;
		FSet			output, cut;
		Store		sto;
		double		alpha;

		p = coms;
		while (p != null)
		{
			if (debug) BGParser.debug ("     Command <" + p.type () + ">");

			switch (p.type ())
			{
			case Command.FRULE:
			case Command.FBKG:
				if (p.id ().type () == VSymbol.TUPLE)
				{
					if (p.id ().set ().type () == VSymbol.NUMBER)
						addset (p.id ().set ());
					output = set (p.id ().set ().name ());
					alpha = expresion (p.exp (), p.type (), out, locals);
					cut = output.alphacut (alpha);
					sto = pointer (isout (out, p.id ().source ()), locals);
					rs.add (new Rule (sto, cut));
				}
				else
					BGParser.error ("Wrong <" + p.id ().name () + "> type for rule postcondition");
				break;
			default:
				/* Do nothing */
			}
			p = (Command) p.next ();
		}
	}

	protected void behaviours (Behaviour behs, Hashtable<String, Store> locals) throws InterpreterException
	{
		Fusion			fus;
		Pairs			prs;
		Behaviour		p;
		Command			c;
		VSymbol			s;
		String			name;
	
		locals.clear ();			// Initialize local non-static variables
		fus = new Fusion (behs.count ());
		p = behs;
		while (p != null)
		{
			if (verbose) BGParser.debug ("   Behaviour <" + p.name () + ">");
			
			s = p.loc ();
			while (s != null)
			{
				if (s.type () == VSymbol.NUMBER)
					locals.put (s.name (), new Store (s.number ().doubleValue ()));
				else
					BGParser.error ("Wrong <" + s.name () + "> type for local variable");
				s = (VSymbol) s.next ();
			}
			s = p.out ();
			while (s != null)
			{
				name = "_" + s.name ();
				if (s.type () == VSymbol.REF)
					locals.put (name, new Store (access (s.name (), locals)));
				else
					BGParser.error ("Wrong <" + name + "> type for fusion variable");
				s = (VSymbol) s.next ();
			}

			c = p.com ();
			while ((c = nextfsm (c)) != null)
			{
				if (!states.containsKey (c.uniq ()))
					states.put (c.uniq (), c.name ());
				c = (Command) c.next ();
			}

			if (verbose) dumplocals (locals);

			try { commands (p.com (), p.out (), locals); }
			catch (StateException e) { }
			catch (ReturnException e) { }
			
			if (p.out () != null)
			{
				prs = new Pairs (p.out ().count ());
				prs.alpha (p.pri ().doubleValue () * access (p.name (), locals));
				s = p.out ();
				while (s != null)
				{
					prs.add (pointer (s.ptr ().name (), locals), pointer ("_" + s.ptr ().name (), locals));
					s = (VSymbol) s.next ();
				}
				fus.add (prs);
			}

			if (verbose) BGParser.debug ("   End Behaviour <" + p.name () + ">");
			p = (Behaviour) p.next ();
		}
		fus.fusion ();
	}
	
	protected void common (Common com, Hashtable<String, Store> locals) throws InterpreterException
	{
		Common			p;
		Command		c;
		VSymbol			s;
	
		locals.clear ();			// Initialize local non-static variables
		p = com;
		if (p != null)
		{
			if (verbose) BGParser.debug ("   Common Block");
			
			s = p.loc ();
			while (s != null)
			{
				if (s.type () == VSymbol.NUMBER)
					locals.put (s.name (), new Store (s.number ().doubleValue ()));
				else
					BGParser.error ("Wrong <" + s.name () + "> type for local variable");
				s = (VSymbol) s.next ();
			}

			c = p.com ();
			while ((c = nextfsm (c)) != null)
			{
				if (!states.containsKey (c.uniq ()))
					states.put (c.uniq (), c.name ());
				c = (Command) c.next ();
			}

			try { commands (p.com (), null, locals); }			
			catch (StateException e) { }
			catch (ReturnException e) { }

			if (verbose) BGParser.debug ("   End Common Block");
		}
	}

	protected void blender (Blender blend, Hashtable<String, Store> locals) throws InterpreterException
	{
		Blender			p;
		Command			c;
		VSymbol			s;
	
		locals.clear ();			// Initialize local non-static variables
		p = blend;
		if (p != null)
		{
			if (verbose) BGParser.debug ("   Blender");
			
			s = p.loc ();
			while (s != null)
			{
				if (s.type () == VSymbol.NUMBER)
					locals.put (s.name (), new Store (s.number ().doubleValue ()));
				else
					BGParser.error ("Wrong <" + s.name () + "> type for local variable");
				s = (VSymbol) s.next ();
			}

			c = p.com ();
			while ((c = nextfsm (c)) != null)
			{
				if (!states.containsKey (c.uniq ()))
					states.put (c.uniq (), c.name ());
				c = (Command) c.next ();
			}
			
			try { commands (p.com (), null, locals); } 
			catch (StateException e) { }
			catch (ReturnException e) { }

			if (verbose) BGParser.debug ("   End Blender");
		}
	}

	protected void initialize (Command com)
	{
		Command			c;
		Hashtable<String, Store>	locals;
	
		if (com == null) return;
		
		if (verbose) BGParser.debug ("   Initialization Block");
		
		locals	= new Hashtable<String, Store> (MAXLOCS);
		c = com;	
		while ((c = nextfsm (c)) != null)
		{
			if (!states.containsKey (c.uniq ()))
				states.put (c.uniq (), c.name ());
			c = (Command) c.next ();
		}

		try { commands (com, null, locals); }			
		catch (InterpreterException e) { }

		if (verbose) BGParser.debug ("   End Initialization Block");
	}

	public void agents (Program prg)
	{
		Agent			p;
		Hashtable<String, Store>	locals;
	
		locals	= new Hashtable<String, Store> (MAXLOCS);

		p = prg.agts ();
		while ((p != null) && !finished)
		{
			if (verbose) BGParser.debug (" Agent <" + p.name () + ">");
			
			try
			{
				common (p.com (), locals);
				blender (p.blend (), locals);
				behaviours (p.behs (), locals);
			}
			catch (HaltException e)
			{
				finished = true;
				break;
			}
			catch (InterpreterException e) { }

			if (verbose) BGParser.debug (" End Agent <" + p.name () + ">");
			
			p = (Agent) p.next ();
		}
	}

	public void initialize (Program prg)
	{
		symbols (prg.vars (), prg.funcs ());
		initialize (prg.init ());
//		input 	= sensors (prg.vars ());
	}

	/* ------------------------------------- */
	/* A U X I L I A R Y   F U N C T I O N S */
	/* ------------------------------------- */

	protected void dumplocals (Hashtable<String, Store> locals)
	{
		Enumeration<String>	keys;
		String			name;
		double			value;
		
		System.out.println ("             Variables Table");
		System.out.println ("             ===============");
		for (keys = locals.keys (); keys.hasMoreElements (); ) 
		{
			System.out.print ("       ");
			name = keys.nextElement ();
			value = access (name, locals);
			System.out.println (name + " = " + value);
		}
		System.out.println ("             ---------------------");
	}
	
	protected double access (String name, Hashtable<String, Store> locals)
	{
		double			value;
		Store			sto 		= null;
		
		if (locals != null) sto = locals.get (name);
		if (sto == null)
		{
			sto = globals.get (name);
			if (sto == null)
			{
				BGParser.error ("Variable <" + name + "> not found");
				return 0.0;
			}
		}
		value = sto.value ();
		if (verbose) BGParser.debug ("          Variable <" + name + "> ==> [" + value + "]");
		return value;
	}
	
	public double access (String name)
	{
		double			value;
		Store			sto 		= null;
		
		sto = globals.get (name);
		if (sto == null)
		{
			BGParser.error ("Global variable <" + name + "> not found");
			return 0.0;
		}
		value = sto.value ();
		if (verbose) BGParser.debug ("          Variable <" + name + "> ==> [" + value + "]");
		return value;
	}
	
	protected void access (String name, double value, Hashtable<String, Store> locals)
	{
		Store			sto		= null;
		
		if (locals != null) sto = locals.get (name);
		if (sto == null)
		{
			sto = globals.get (name);
			if (sto == null)
			{
				BGParser.error ("Variable <" + name + "> not found");
				return;
			}
		}
		sto.value (value);
		if (verbose) BGParser.debug ("          Variable <" + name + "> <== [" + value + "]");
	}
	
	public void access (String name, double value)
	{
		Store			sto		= null;
		
		sto = globals.get (name);
		if (sto == null)
		{
			if (verbose) BGParser.warning ("Global variable <" + name + "> not found");
			return;
		}
		sto.value (value);
		if (verbose) BGParser.debug ("          Variable <" + name + "> <== [" + value + "]");
	}
	
	private Store pointer (String name, Hashtable<String, Store> locals)
	{
		Store			sto		= null;
		
		if (locals != null) sto = locals.get (name);
		if (sto == null)
		{
			sto = globals.get (name);
			if (sto == null)
			{
				BGParser.error ("Pointer to variable <" + name + "> not found");
				return new Store ();		// This is Just-In-Case
			}
		}
		if (verbose) BGParser.debug ("          Pointer to <" + name + ">     [" + sto.value () + "]");
		return sto;
	}
	
	private FSet set (String name)
	{
		FSet			set;
		
		set = sets.get (name);
		if (set == null)
		{
			BGParser.error ("FSet <" + name + "> not found");
			return new Trapezoid ();
		}
		return set;
	}
	
	private Function function (String name)
	{
		Function		fun;
		
		fun = funcs.get (name);
		if (fun == null)
		{
			BGParser.error ("Function <" + name + "> not found");
			return null;
		}
		return fun;
	}
	
	protected String state (String name)
	{
		String			ret;
		
		ret = states.get (name);
		if (ret == null)
		{
			BGParser.error ("FSM State <" + name + "> not found");
			return new String ();
		}
		if (verbose) BGParser.debug ("          FSM State <" + name + "> ==> [" + ret + "]");
		return ret;
	}
	
	protected void state (String name, String value)
	{
		if (!states.containsKey (name))
		{
			BGParser.error ("FSM State <" + name + "> not found");
			return;
		}
		states.put (name, value);
		if (verbose) BGParser.debug ("          FSM State <" + name + "> <== [" + value + "]");
	}
	
	private boolean isglobal (VSymbol ids, VSymbol s)
	{
		VSymbol 			p;
	
		p = ids;
		while (p != null)
		{
			if (p == s)
				return true;
			p = (VSymbol) p.next ();
		}
		return false;
	}

	private String isout (VSymbol sym, String name)
	{
		VSymbol 			p;
	
		p = sym;
		while (p != null)
		{
			if (name.equals (p.name ()))
				return "_" + name;
			p = (VSymbol) p.next ();
		}
		return name;
	}

	private void addset (VSymbol id)
	{
		FSet				set;
	
		if (sets.get (id.name ()) != null)		return;

		if (id.type () == VSymbol.NUMBER)
			set = new Crisp (id.number ().doubleValue ());		
		else
		{
			switch (id.subtype ())
			{
			case VSymbol.S_TRAPEZOID:
				set = new Trapezoid ((id.fuzzy ())[0], (id.fuzzy ())[1], (id.fuzzy ())[2], (id.fuzzy ())[3]);
				break;
			case VSymbol.S_SIGMOID:
				set = new Sigmoid ((id.fuzzy ())[0], (id.fuzzy ())[1]);
				break;
			case VSymbol.S_BELL:
				set = new Bell ((id.fuzzy ())[0], (id.fuzzy ())[1], (id.fuzzy ())[2]);
				break;
			case VSymbol.S_TRIANGLE:
				set = new Triangle ((id.fuzzy ())[0], (id.fuzzy ())[1], (id.fuzzy ())[2]);
				break;
			case VSymbol.S_CRISP:
				set = new Crisp ((id.fuzzy ())[0]);
				break;
			case VSymbol.S_TSK:
				set = new TSK (this, id.vars (), id.fuzzy ());
				break;
			default:
				BGParser.error ("Wrong <" + id.name () + "> shape for fuzzy set");
				set = new Trapezoid ();
			}
		}
		sets.put (id.name (), set);
	}

	private Command slookup (Command com, String name)
	{
		Command		p;
	
		p = com;
		while (p != null)
		{
			if (name.equals (p.name ()))
				return p;
			p = (Command) p.next ();
		}
			
		return null;
	}

	private Command nextfsm (Command com)
	{
		Command		p;
	
		p = com;
		while (p != null)
		{
			if (p.type () == Command.FSM)
				return p;
			p = (Command) p.next ();
		}
			
		return null;
	}
}
