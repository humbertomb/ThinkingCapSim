/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

public class SVars extends java.lang.Object
{
	protected SVar[]			sv;
	protected int				n;
	private int					k;

	/* Constructors */
	private SVars ()
	{
	}
	
	public SVars (int n)
	{
		this.create (n);
	}
	
	/* Accessor methods */
	public final int	 	n () 					{ return n; }

	/* Instance methods */
	private void create (int n)
	{
		this.k		= 0;
		this.n		= n;
		this.sv		= new SVar [n];
	}
	
	public void add (SVar v)
	{
		if (k >= n) return;
		
		sv[k] = v;
		k++;
	}
	
	public void add (String name, double min, double max, double steps)
	{
		add (new SVar (name, min, max, steps));
	}
	
	public void add (String name)
	{
		add (new SVar (name, 0.0, 0.0, 0.0));
	}
	
	public SVar at (int i)
	{
		if ((i < 0) || (i >= n)) return null;
		return sv[i];
	}
	
	public void at (int i, SVar v)
	{
		if ((i < 0) || (i >= n)) return;
		sv[i] = v;
	}
}
