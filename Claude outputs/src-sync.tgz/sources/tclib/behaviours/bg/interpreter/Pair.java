/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

public class Pair extends java.lang.Object
{
	protected int				hash		= -1;
	protected Store				src;
	protected Store				ptr;

	/* Constructors */
	private Pair ()
	{
	}
	
	public Pair (Store src, Store ptr)
	{
		this.create (src, ptr);
	}
	
	/* Accessor methods */
	public final int	 	hash () 				{ return hash; }
	public final void	 	hash (int hash) 		{ this.hash = hash; }
	public final Store	 	src () 					{ return src; }
	public final Store	 	ptr () 					{ return ptr; }

	/* Instance methods */
	private void create (Store src, Store ptr)
	{
		this.src		= src;
		this.ptr		= ptr;
	}
	
	public void update ()
	{
		src.value (ptr.value ());
	}
}
