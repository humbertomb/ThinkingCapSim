/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg.interpreter;

import java.util.*;
import java.io.*;

import tclib.behaviours.bg.*;
import tclib.utils.fuzzy.*;

public class RuleInterpreter extends Interpreter
{
	static public final String			SUFFIX		= ".fuzzy";
	static public final String			HEADER		= "Fuzzy Rule Base Parameters";

	private Hashtable<String, Store>	locals;
	protected Command					fuzzy;
	protected double					output[];
	protected int						n;
	protected int						ni;
	protected int						no;
	
	/* Constructors */
	public RuleInterpreter (String name)
	{
		super ();
		
		locals	= new Hashtable<String, Store> (MAXLOCS);
		load (name);
	}
	
	/* Accessor methods */
	public final int				rules () 			{ return n; }
	public final int				input () 			{ return ni; }
	public final int				output () 			{ return no; }

	/* Instance methods */
	protected void load (String name)
	{ 
		Properties			props;
		File				file;
		FileInputStream		stream;
		StringTokenizer		st;
		int					i, j, k;
		String				buff;
		String[]			vars;
		double[]			set;
		VSymbol[]			inp;
		VSymbol[]			out;
		VSymbol[]			iset, oset;
		VSymbol				tuples, tuple;
		Command				rules, rule;
		Expresion			exp, exps;
		
		props			= new Properties ();
		try 
		{
			file 			= new File (name);
			stream 		= new FileInputStream (file);
			props.load (stream);
			stream.close ();
		} catch (Exception e) { }

		// Read rule base parameters
		try { n 			= Integer.valueOf (props.getProperty ("RULES")).intValue (); } catch (Exception e) 		{ n			= 0; }
		try { ni 			= Integer.valueOf (props.getProperty ("INPUT")).intValue (); } catch (Exception e) 		{ ni			= 1; }
		try { no 			= Integer.valueOf (props.getProperty ("OUTPUT")).intValue (); } catch (Exception e) 		{ no			= 1; }

		// Declare genereal structures
		output 	= new double[no];
		vars		= new String[ni];
		
		// Update global symbol list
		inp		= new VSymbol[ni];
		for (i = 0; i < ni; i++)
		{
			inp[i]		= new VSymbol ().number ("input" + i, 0.0);			symbols (inp[i], null);
			vars[i]		= "input" + i;
		}
		out		= new VSymbol[no];
		for (i = 0; i < no; i++)
		{
			out[i]		= new VSymbol ().number ("output" + i, 0.0);			symbols (out[i], null);
		}

		// Read rules
   		iset		= new VSymbol[ni];
   		oset		= new VSymbol[no];
   		rules	= null;
		for(i = 0; i < n; i++)
		{
			buff		= props.getProperty ("R" + i);
   			st		= new StringTokenizer (buff, ",");
   			
   			// Input sets
   			exps		= null;
    			for (j = 0; j < ni; j++)
    			{
    				st.nextToken ();		// It MUST be a bell function set "b"
   				set		= new double[VSymbol.elem[VSymbol.S_BELL]];
    				for (k = 0; k < VSymbol.elem[VSymbol.S_BELL]; k++)
					try { set[k] 			= Double.valueOf (st.nextToken ()).doubleValue (); } catch (Exception e) 		{ set[k]		= 0.0; }
				iset[j]	= new VSymbol ().bell (set);
				symbols (iset[j], null);				
		
				// Create expresion list
				exp		= new Expresion ().binary (Expresion.IS, new Expresion ().terminal (inp[j]), new Expresion ().terminal (iset[j]));
				if (exps == null)
					exps 	= exp;
				else
					exps	= new Expresion ().binary (Expresion.AND, exps, exp);
			} 
			
   			// Output sets
   			tuples	= null;
    			for (j = 0; j < no; j++)
    			{
    				buff 		= st.nextToken ();		// It MUST be a crisp set "c" or a TSK consequent "t"
    				if (buff.charAt (0) == 't')
    				{
    					set		= new double[ni + 1];
    					for (k = 0; k < ni + 1; k++)
						try { set[k] 			= Double.valueOf (st.nextToken ()).doubleValue (); } catch (Exception e) 		{ set[k]		= 0.0; }
						oset[j]	= new VSymbol ().tsk (vars, set);
						symbols (oset[j], null);			
					}	
   					else /* buff[0] == 'c' */
    				{
   						set		= new double[VSymbol.elem[VSymbol.S_CRISP]];
    					for (k = 0; k < VSymbol.elem[VSymbol.S_CRISP]; k++)
						try { set[k] 			= Double.valueOf (st.nextToken ()).doubleValue (); } catch (Exception e) 		{ set[k]		= 0.0; }
						oset[j]	= new VSymbol ().crisp (set);
						symbols (oset[j], null);				
				}

				// Create consecuents list
				tuple	= new VSymbol ().vtuple (out[j], oset[j]);
				if (tuples == null)
					tuples = tuple;
				else
				{
					tuple.next (tuples);	
					tuples = tuple;
				}		
			}

			// Create rule
			rule		= new Command ().frule (tuples, exps);

			// Add rule to the list
			if (rules == null)
				rules = rule;
			else
			{
				rule.next (rules);	
				rules = rule;
			}		
		}
		// Rule block
		fuzzy	= new Command ().rules (rules);
//System.out.println (fuzzy.toString ());
	}

	public void save (String name)
	{
		Properties			props;
		File				file;
		FileOutputStream	stream;
		
		props			= new Properties ();
		
		props.put ("RULES", 		Integer.valueOf (n).toString ());
		props.put ("INPUT", 		Integer.valueOf (ni).toString ());
		props.put ("OUTPUT", 		Integer.valueOf (no).toString ());
		
		try 
		{
			file 		= new File (name);
			stream 		= new FileOutputStream (file);
			props.store (stream, HEADER);
			stream.close ();
		} catch (Exception e) { }
	}

	public double[] evaluate (double[] input)
	{
		int			i;
		
		for (i = 0; i < ni; i++)
			access ("input" + i, input[i], locals);
			
FSet.set_tnorm (FSet.T_PROD);												// OJO, HORROR, esto produce efectos secundarios (en otros Threads)
		try { commands (fuzzy, null, locals); } catch (Exception e) { }
FSet.set_tnorm (FSet.T_MIN);
		
		for (i = 0; i < no; i++)
			output[i] = access ("output" + i, locals);

		return output;
	}
	
	public double evaluate (double input)
	{
		access ("input", input, locals);
			
FSet.set_tnorm (FSet.T_PROD);												// OJO, HORROR, esto produce efectos secundarios (en otros Threads)
		try { commands (fuzzy, null, locals); } catch (Exception e) { }
FSet.set_tnorm (FSet.T_MIN);
		
		return access ("output", locals);
	}
}
