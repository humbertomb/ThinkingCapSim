/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class Function extends List
{
	protected VSymbol		params;
	protected VSymbol		loc;
	protected Command		coms;
	
	/* Constructors */
	public Function ()
	{
	}
	
	public Function (String name, VSymbol params, VSymbol loc, Command coms)
	{
		this.create (name, params, loc, coms);
	}
	

	/* Accessor methods */
	public final VSymbol 	params () 				{ return params; }
	public final VSymbol 	loc () 					{ return loc; }
	public final Command 	com () 					{ return coms; }

	/* Instance methods */
	protected void create (String name, VSymbol params, VSymbol loc, Command coms)
	{
		this.name			= name;
		this.params		= params;
		this.loc			= loc;
		this.coms			= coms;
	}

	public Function dup ()
	{
		Function		f;
		
		f = new Function (name, params, loc, coms);
		f.next (null);
		return f;
	}
	
	public Function find (String name)
	{
		return (Function) super.search (name);
	}
	
	public String toString ()
	{
		String		str;
		String		ps;
		VSymbol		vs;
		Command		cs;
		
		vs 	= params;
		ps	= " ";
		while (vs != null)
		{
			ps += vs.name ();
			if (vs.next () != null)
				ps += ", ";
			vs = (VSymbol) vs.next ();
		}
		str 	= "function " + name + " (" + ps + " )\n{\n";
		vs 	= loc;
		while (vs != null)
		{
			str += "\t" + vs.toString () + "\n";
			vs = (VSymbol) vs.next ();
		}
		cs 	= coms;
		while (cs != null)
		{
			str += "\t" + cs.toString () + "\n";
			cs = (Command) cs.next ();
		}
				
		return str + "}\n\n";
	}
}
