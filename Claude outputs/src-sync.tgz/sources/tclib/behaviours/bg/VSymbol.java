/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

import java.util.Hashtable;

public class VSymbol extends List
{
	public static final double		MINVALUE		= 1.0E-3;
	public static final int			MAXPOINTS		= 4;
	public static final int			MAXSYMBOLS		= 3000;
	public static final String		ROOT			= "vtemp";
	
	public static final int			NUMBER			= 0;
	public static final int			TUPLE			= 1;
	public static final int			SET				= 2;
	public static final int			STATE			= 3;
	public static final int			REF				= 4;
	
	public static final int			N_VAR			= 0;
	public static final int			N_CONSTANT		= 1;
	public static final int			N_EXTERNAL		= 2;
	public static final int			N_BLACKB		= 3;
	public static final int			N_PARAM			= 4;
	public static final int			N_SENSOR		= 5;
	public static final int			N_EFFECTOR		= 6;
	public static final int			N_STATUS		= 7;

	public static final int			S_TRAPEZOID		= 0;
	public static final int			S_SIGMOID		= 1;
	public static final int			S_BELL			= 2;
	public static final int			S_TRIANGLE		= 3;
	public static final int			S_CRISP			= 4;
	public static final int			S_TSK			= 5;

	protected static int			serial			= 0;
	public static int[]				elem			= { 4, 2, 3, 3, 1, -1 };
	protected static String[]		elems			= { "trapezoid", "sigmoid", "bell", "triangle", "crisp", "tsk" };
	protected static String[]		floats			= { "float", "** Constant", "** External", "blackboard", "** Function Parameter", "sensor float", "effector float", "status float" };
	protected static String[]		subtypes		= { "Global", "Constant", "External", "Blackboard", "Function Parameter", "Sensor", "Effector" };
	protected static String[]		types			= { "Number", "Tuple", "Set", "State", "Reference" };

	protected String				source;
	protected int					type;
	protected int					subtype;
	
	protected Double				number;
	protected Double				min;
	protected Double				max;
	protected double[]				fuzzy;
	protected String[]				vars;
	protected VSymbol				set;
	protected VSymbol				ptr;
	
	/* Constructors */
	public VSymbol ()
	{
	}
	
	/* Class methods */
	public static String newid ()
	{
		serial ++;
		return ROOT + (Integer.valueOf (serial)).toString ();
	}

	public static void dump (VSymbol s)
	{
		if (s != null)
			s.dump ();
		else
			System.out.println ("***       NULL Symbol");
	}

	public static void dumplist (VSymbol s, String name)
	{
		VSymbol		p;

		System.out.println ("--- Dumping list <" + name + ">");
		p = s;
		while (p != null)
		{
			dump (p);
			p = (VSymbol) p.next ();
		}
		System.out.println ("---");
	}
	
	/* Accessor methods */
	public final String 		source () 				{ return source; }
	public final int 			type () 				{ return type; }
	public final int 			subtype () 				{ return subtype; }
	public final Double 		number () 				{ return number; }
	public final Double 		min () 					{ return min; }
	public final Double 		max () 					{ return max; }
	public final double[] 		fuzzy () 				{ return fuzzy; }
	public final VSymbol 		set () 					{ return set; }
	public final VSymbol 		ptr () 					{ return ptr; }
	public final String[]	 	vars () 				{ return vars; }

	/* Instance methods */
	public boolean istmp ()
	{
		return name.startsWith (ROOT);
	}
	
	protected void fuzzy (NList fuzzy)
	{
		int				i, n;
		NList 			p;
		
		if (subtype == S_TSK)
		{
			n		= fuzzy.count ();
			this.fuzzy = new double [n];
			p 		= fuzzy;
			for (i = 0; (i < n) && (p != null); i ++)
			{
				this.fuzzy[i] = p.number ();
				p = (NList) p.next ();
			}
		}
		else
		{
			this.fuzzy = new double [MAXPOINTS];
			p 		= fuzzy;
			for (i = 0; (i < elem[subtype]) && (p != null); i ++)
			{
				this.fuzzy[i] = p.number ();
				p = (NList) p.next ();
			}
			if ((i < elem[subtype]) || (p != null))
				BGParser.error ("A " + elems[subtype] + " fuzzy set MUST have " + elem[subtype] + " points");
			switch (this.subtype)
			{
			case S_TRAPEZOID:
				for (i = 1; i < elem[subtype]; i ++)
					if (this.fuzzy[i] < this.fuzzy[i-1])
						BGParser.error ("Points in a " + elems[subtype] + " fuzzy set MUST grow monotonically");
				break;
			default:
				/* Do nothing */;
			}
		}
	}
	
	public VSymbol number (String name, int subtype, Double number)
	{
		this.type 			= NUMBER;
		this.name			= name;
		this.number			= number;
		this.subtype		= subtype;
		
		return this;
	}

	public VSymbol number (String name, Integer subtype, Double number)
	{
		return number (name, subtype.intValue (), number);
	}

	public VSymbol number (String name, Integer subtype, double number)
	{
		return number (name, subtype.intValue (), Double.valueOf (number));
	}

	public VSymbol number (String name, int subtype, double number)
	{
		return number (name, subtype, Double.valueOf (number));
	}

	public VSymbol number (String name, double number)
	{
		return number (name, N_VAR, Double.valueOf (number));
	}

	public VSymbol number (String name, Double number)
	{
		return number (name, N_VAR, number);
	}
	
	public VSymbol number (double number)
	{
		return number (newid (), N_CONSTANT, Double.valueOf (number));
	}
	
	public VSymbol number (Double number)
	{
		return number (newid (), N_CONSTANT, number);
	}
	
	public VSymbol set (String name, Integer subtype, NList fuzzy)
	{
		this.type			= SET;
		this.subtype		= subtype.intValue ();
		this.name			= name;
		this.fuzzy (fuzzy);
		
		return this;
	}
	
	public VSymbol set (Integer subtype, NList fuzzy)
	{
		this.type			= SET;
		this.subtype		= subtype.intValue ();
		this.name			= newid ();
		this.fuzzy (fuzzy);
		
		return this;
	}
	
	public VSymbol trapezoid (double[] points)
	{
		int			i;
		
		if (points.length != elem[S_TRAPEZOID])
		{
			BGParser.error ("A Trapezoid fuzzy set MUST have " + elem[S_TRAPEZOID] + " points");
			return null;
		}
		this.type			= SET;
		this.subtype		= S_TRAPEZOID;
		this.name			= newid ();
		this.fuzzy 			= new double [elem[S_TRAPEZOID]];
		
		for (i = 0; i < elem[S_TRAPEZOID]; i++)
			this.fuzzy[i] = points[i];
			
		return this;
	}
	
	public VSymbol triangle (double[] points)
	{
		int			i;
		
		if (points.length != elem[S_TRIANGLE])
		{
			BGParser.error ("A Triangle fuzzy set MUST have " + elem[S_TRIANGLE] + " points");
			return null;
		}
		this.type			= SET;
		this.subtype		= S_TRIANGLE;
		this.name			= newid ();
		this.fuzzy 			= new double [elem[S_TRIANGLE]];
		
		for (i = 0; i < elem[S_TRIANGLE]; i++)
			this.fuzzy[i] = points[i];
			
		return this;
	}
	
	public VSymbol bell (double[] points)
	{
		int			i;
		
		if (points.length != elem[S_BELL])
		{
			BGParser.error ("A Bell fuzzy set MUST have " + elem[S_BELL] + " points");
			return null;
		}
		this.type			= SET;
		this.subtype		= S_BELL;
		this.name			= newid ();
		this.fuzzy 			= new double [elem[S_BELL]];
		
		for (i = 0; i < elem[S_BELL]; i++)
			this.fuzzy[i] = points[i];
			
		return this;
	}
	
	public VSymbol crisp (double[] points)
	{
		int			i;
		
		if (points.length != elem[S_CRISP])
		{
			BGParser.error ("A Crisp fuzzy set MUST have " + elem[S_CRISP] + " points");
			return null;
		}
		this.type			= SET;
		this.subtype		= S_CRISP;
		this.name			= newid ();
		this.fuzzy 			= new double [elem[S_CRISP]];
		
		for (i = 0; i < elem[S_CRISP]; i++)
			this.fuzzy[i] = points[i];
			
		return this;
	}
	
	public VSymbol tsk (String[] vars, double[] points)
	{
		int			i;
		int			np, nv;
		
		np				= points.length;
		nv				= vars.length;
		if (np != nv + 1)
		{
			BGParser.error ("A TSK fuzzy consequent MUST have one coefficient for each input variable");
			return null;
		}
		this.type			= SET;
		this.subtype		= S_TSK;
		this.name			= newid ();
		this.fuzzy 			= new double [np];
		this.vars 			= new String [nv];
		
		for (i = 0; i < np; i++)
			this.fuzzy[i] = points[i];
			
		for (i = 0; i < nv; i++)
			this.vars[i] = vars[i];
			
		return this;
	}
	
	public VSymbol tuple (String name, String source, VSymbol set)
	{
		this.type 			= TUPLE;
		this.name 			= name;
		this.source			= source;
		this.set			= set;
		
		return this;
	}
	
	public VSymbol tuple (String name, String source, Integer subtype, NList fuzzy)
	{
		VSymbol			set;
		
		set = (new VSymbol ()).set (newid (), subtype, fuzzy);
		return tuple (name, source, set);	
	}
	
	public VSymbol tuple (String name, String source, String set, VSymbol list)
	{
		VSymbol			tmp;
		
		tmp = list.find (set);
		if (tmp == null)
			BGParser.error ("Reference <" + set + "> not resolved");
		return tuple (name, source, tmp);	
	}
	
	public VSymbol vtuple (VSymbol asg, VSymbol set)
	{
		return tuple (newid (), asg.name (), set);	
	}
	
	public VSymbol ref (VSymbol ref)
	{
		this.type		= REF;
		this.name 		= ref.name ();
		this.ptr		= ref;	
		return this;
	}

	public VSymbol ref (VSymbol ref, Double min, Double max)
	{
		ref (ref);
		if (this.ptr.min == null)	this.ptr.min	= min;
		if (this.ptr.max == null)	this.ptr.max	= max;	
		return this;
	}

	public VSymbol find (String name)
	{
		return (VSymbol) super.search (name);
	}
	
	public boolean contains (String name)
	{
		if (this.find (name) != null)
			return true;
		return false;
	}

	public String label ()
	{
		if ((type == NUMBER) && (subtype  == N_CONSTANT))
			return number.toString ();
		if ((type != SET) || (!istmp ())) return name;
				
		return toString (false);
	}
	
	protected VSymbol deepclone (Hashtable<VSymbol, VSymbol> table) 
	{
		VSymbol		clon;
		VSymbol		tset;
		VSymbol		tptr;
		VSymbol		ttnext;
		List		tnext;

		if (table.containsKey (this))
		{
//System.out.println ("Linking to  VSymbol node " + name);		
			return table.get (this);
		}
			
		tnext	= null;
		if (next () != null)
		{
			ttnext	= (VSymbol) next ();
			tnext 	= ttnext.deepclone (table);
		}

		tset	= null;
		if (set != null)
			tset 	= (VSymbol) set.deepclone (table);

		tptr	= null;
		if (ptr != null)
			tptr 	= (VSymbol) ptr.deepclone (table);
		
//System.out.println ("Cloning VSymbol node " + name);		
		clon 			= new VSymbol ();
		clon.next (tnext);
		clon.name 		= name;
		clon.source 	= source;
		clon.type 		= type;
		clon.subtype 	= subtype;
		clon.number	 	= number;
		clon.fuzzy 		= fuzzy;
		clon.vars	 	= vars;
		clon.set 		= tset;
		clon.ptr	 	= tptr;
		
		table.put (this, clon);
		
		return  clon;
	}
		
	public Object clone () 
	{
		Hashtable<VSymbol, VSymbol>	table;
		
		table = new Hashtable<VSymbol, VSymbol> (MAXSYMBOLS);
		return deepclone (table);
	}
		
	public String toString ()
	{
		return toString (true);
	}
	
	public String toString (boolean header)
	{
		String		str;
		String		fset, val;
		double		dbl;
		int			i;
		
		switch (type)
		{
		case NUMBER:
			val = " ";
			if (number.doubleValue () != 0.0)
				val = " = " + number;
			str = floats[subtype] + "\t\t" + name + val + ";";
			break;
		case SET:
			fset = " ";
			if (subtype == S_TSK)
			{
				dbl	= fuzzy[0];
				if ((dbl > -MINVALUE) && (dbl < MINVALUE))
					dbl = 0.0;
				fset = dbl + ", ";
				for (i = 1; i < fuzzy.length - 1; i++)
				{	
					dbl	= fuzzy[i];
					if ((dbl > -MINVALUE) && (dbl < MINVALUE))
						dbl = 0.0;
					fset += dbl + " (" + vars[i - 1] + "), ";
				}
				dbl	= fuzzy[i];
				if ((dbl > -MINVALUE) && (dbl < MINVALUE))
					dbl = 0.0;
				fset += dbl + " (" + vars[i - 1] + ")";
			}
			else
			{
				for (i = 0; i < elem[subtype] - 1; i++)
				{	
					dbl	= fuzzy[i];
					if ((dbl > -MINVALUE) && (dbl < MINVALUE))
						dbl = 0.0;
					fset += dbl + ", ";
				}
				dbl	= fuzzy[i];
				if ((dbl > -MINVALUE) && (dbl < MINVALUE))
					dbl = 0.0;
				fset += dbl;
			}

			if (header)
				str = "set " + name + " \t= " + elems[subtype] + " { " + fset + " };";
			else
				str = elems[subtype] + " { " + fset + " }";
			break;
		case TUPLE:
			str = source + " is <" + set.toString () + ">";
			break;
		case REF:
			str = "fusion " + name + ";";
			break;
		default:
			str = " ";
		}
		
		return str;
	}

	private void dump ()
	{
		System.out.println ("***       Symbol <" + name + "> of class <" + types[type] + ">");
		switch (type)
		{
		case NUMBER:
			System.out.println ("***              Subtype <" + subtypes[subtype] + ">");
			break;
		case SET:
			System.out.println ("***              Subtype <" + elems[subtype] + ">");
			break;
		case REF:
			System.out.println ("***              Pointer to <" + ptr.name () + ">");
			break;
		default:
			/* Do nothing */
		}
	}
}
