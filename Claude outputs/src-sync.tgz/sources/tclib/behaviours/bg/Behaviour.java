/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class Behaviour extends List
{
	protected Double		pri;
	protected VSymbol		out;
	protected VSymbol		loc;
	protected Command	com;
		
	/* Constructors */
	protected Behaviour ()
	{
		
	}

	public Behaviour (String name, double pri, VSymbol out, VSymbol loc, Command com)
	{
		this.create (name, Double.valueOf (pri), out, loc, com);
	}
	
	public Behaviour (String name, Double pri, VSymbol out, VSymbol loc, Command com)
	{
		this.create (name, pri, out, loc, com);
	}
	
	/* Accessor methods */
	public final Double 		pri () 					{ return pri; }
	public final VSymbol 	out () 					{ return out; }
	public final VSymbol 	loc () 					{ return loc; }
	public final Command 	com () 					{ return com; }

	/* Instance methods */
	protected void create (String name, Double pri, VSymbol out, VSymbol loc, Command com)
	{
		this.name			= name;
		this.pri			= pri;
		this.out			= out;
		this.loc			= loc;
		this.com			= com;
	}

	public Behaviour dup ()
	{
		Behaviour		b;
		
		b = new Behaviour (name, pri, out, loc, com);
		b.next (null);
		return b;
	}

	public String toString ()
	{
		String		str;
		String		list;
		VSymbol		vs;
		Command		cs;
		
		str 	= "\tbehaviour " + name + " priority " + pri + "\n\t{\n";

		list = " ";
		vs 	= out;
		while (vs != null)
		{
			list += vs.label ();
			if (vs.next () != null)
				list += ", ";
			vs = (VSymbol) vs.next ();
		}
		if (list.length () > 1)
			str += "\t\tfusion " + list + ";\n";
		
		list = " ";
		vs 	= loc;
		while (vs != null)
		{
			list += vs.label ();
			if (vs.next () != null)
				list += ", ";
			vs = (VSymbol) vs.next ();
		}
		if (list.length () > 1)
			str += "\t\tfloat " + list + ";\n";

		cs 	= com;
		while (cs != null)
		{
			str += "\t\t" + cs.toString () + "\n";
			cs = (Command) cs.next ();
		}
				
		return str + "\t}\n\n";
	}
}
