/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

import java.io.*;

import tclib.behaviours.bg.runtime.*;

public class BGParser extends Object
{
	public static final String					VERSION			= "BG v2.0a";
	public static final String					ISUFFIX			= ".b";
	
	protected static BufferedInputStream		input_file;
	protected static Program					program			= null;
	protected static Symbol						parse_tree 		= null;
	protected static boolean					debug			= true;

	/* Don't allow class instances */
	protected BGParser ()
	{
	}

	// Accessors
	public static Program	program ()					{ return program; }
	
	// Class methods
	public static void parse (String name, boolean debug) 
	{
		bg_par			parser_obj;
		File			file;
		
		program = null;
		console (VERSION + " Robot Controller Language Parser");
		
		console ("Parsing file \"" + name + "\" ...");
		file = new File (name);
		try 
		{
			input_file = new BufferedInputStream (new FileInputStream (file));
		} catch (Exception e) 
		{
			error ("Can't open \"" + name + "\" for input");
			return;
		}
		
		try 
		{
			parser_obj = new bg_par ();
			if  (debug)
				parse_tree = parser_obj.debug_parse ();
			else
				parse_tree = parser_obj.parse ();
		} catch (Exception e) 
		{
			parse_tree = null;
		}
		if (parse_tree != null) program = (Program) parse_tree.value;
		
		try { input_file.close (); } catch (Exception e) { }
		console ("Ok.");
	}
	
	public static boolean isparsed ()
	{
		return (program != null);
	}
		
	/** Read a character for the current input stream.
	*/
	public static int read () throws IOException
	{
		return input_file.read ();
	}
	
	public static void error (String str)
	{
		System.out.println ("  FATAL: " + str);
	}

	public static void warning (String str)
	{
		System.out.println ("  WARNING: " + str);
	}

	public static void console (String str)
	{
		System.out.println ("# " + str);
	}

	public static void dump (String str)
	{
		if (debug)
			System.out.println ("# " + str);
	}

	public static void debug (String str)
	{
		System.out.println (str);
	}
}

