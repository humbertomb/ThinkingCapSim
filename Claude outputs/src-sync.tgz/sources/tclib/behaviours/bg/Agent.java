/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class Agent extends List
{
	protected VSymbol			black;
	protected Common			com;
	protected Behaviour			behs;
	protected Blender			blend;
	
	/* Constructors */
	public Agent ()
	{
	}
	
	public Agent (String name, VSymbol black, Common com, Behaviour behs, Blender blend)
	{
		this.name			= name;
		this.black			= black;
		this.com			= com;
		this.behs			= behs;
		this.blend			= blend;
	}
	

	/* Accessor methods */
	public final VSymbol 	black () 				{ return black; }
	public final Common 	com () 					{ return com; }
	public final Behaviour 	behs () 				{ return behs; }
	public final Blender 	blend () 				{ return blend; }
	public final void 		blend (Blender blend) 	{ this.blend = blend; }

	/* Instance methods */
	public Agent dup ()
	{
		Agent		a;
		
		a = new Agent (name, black, com, behs, blend);
		a.next (null);
		return a;
	}

	public String toString ()
	{
		String		str;
		String 		list;
		VSymbol		vs;
		Behaviour	bs;
		
		str 	= "agent " + name + " \n{\n";
		
		list = " ";
		vs 	= black;
		while (vs != null)
		{
			list += vs.label () + " range (" + vs.ptr ().min () + ", " + vs.ptr ().max () + ")";
			if (vs.next () != null)
				list += ", ";
			vs = (VSymbol) vs.next ();
		}
		if (list.length () > 1)
			str += "\tblending " + list + ";\n";

		if (com != null) str += com.toString ();
		bs 	= behs;
		while (bs != null)
		{
			str += bs.toString ();
			bs = (Behaviour) bs.next ();
		}
		if (blend != null) str += blend.toString ();
				
		return str + "}\n\n";
	}
}
