/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class NList extends List
{
	protected double		number;

	/* Constructors */
	protected NList ()
	{
	}
	
	public NList(double number, List next)
	{
		this.number = number;
		this.next (next);
	}
	
	public NList(Double number, List next)
	{
		this (number.doubleValue (), next);
	}
	
	public NList(double number)
	{
		this (number, null);
	}
	
	public NList(Double number)
	{
		this (number.doubleValue (), null);
	}
	
	/* Accessor methods */
	public final double 		number () 				{ return number; }
	public final void 		number (double number) 	{ this.number = number; }
	public final void 		number (Double number) 	{ this.number = number.doubleValue (); }
}
