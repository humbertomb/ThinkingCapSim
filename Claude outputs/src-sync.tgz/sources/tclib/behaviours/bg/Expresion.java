/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class Expresion extends List
{
	public static final int		UNARY		= 0;
	public static final int		BINARY		= 1;
	public static final int		TERNARY		= 2;
	public static final int		TERMINAL		= 3;

	public static final int		NOT			= 0;
	public static final int		AND			= 1;
	public static final int		OR			= 2;
	public static final int		EQUAL		= 3;
	public static final int		NE			= 4;
	public static final int		GT			= 5;
	public static final int		GE			= 6;
	public static final int		LT			= 7;
	public static final int		LE			= 8;
	public static final int		PLUS			= 9;
	public static final int		MINUS		= 10;
	public static final int		TIMES		= 11;
	public static final int		DIV			= 12;
	public static final int		IS			= 13;
	
	public static final int		SYMBOL		= 0;
	public static final int		FUNCTION		= 1;
	
	protected static final String	opers[]		= { "!", "&&", "||", "==", "!=", ">", ">=", "<", "<=", "+", "-", "*", "/", "is" };
	
	protected int				arity;
	protected int				type;
	
	protected Expresion		exp1;
	protected Expresion		exp2;
	protected Expresion		exp3;
	protected VSymbol			id;
	protected Command		com;
	
	/* Constructors */
	public Expresion ()
	{
	}
	
	/* Accessor methods */
	public final int 			arity () 				{ return arity; }
	public final int 			type () 				{ return type; }
	public final Expresion 	exp1 () 				{ return exp1; }
	public final Expresion 	exp2 () 				{ return exp2; }
	public final Expresion 	exp3 () 				{ return exp3; }
	public final Command 	com () 				{ return com; }
	public final VSymbol 	id () 					{ return id; }

	/* Instance methods */
	public Expresion unary (int type, Expresion exp)
	{
		this.arity 		= UNARY;
		this.type		= type;
		this.exp1		= exp;
		
		return this;
	}
	
	public Expresion binary (int type, Expresion exp1, Expresion exp2)
	{
		this.arity 		= BINARY;
		this.type		= type;
		this.exp1		= exp1;
		this.exp2		= exp2;
		
		return this;
	}
	
	public Expresion ternary (int type, Expresion exp1, Expresion exp2, Expresion exp3)
	{
		this.arity 		= TERNARY;
		this.type		= type;
		this.exp1		= exp1;
		this.exp2		= exp2;
		this.exp3		= exp3;
		
		return this;
	}
	
	public Expresion terminal (VSymbol id)
	{
		this.arity 		= TERMINAL;
		this.type		= SYMBOL;
		this.id		= id;
		
		return this;
	}
	
	public Expresion terminal (Command com)
	{
		this.arity 		= TERMINAL;
		this.type		= FUNCTION;
		this.com		= com;
		
		return this;
	}

	public String toString ()
	{
		String		str = " ";
		
		switch (arity)
		{
		case UNARY:
			str = opers[type] + "(" + exp1.toString () + ")";
			break;
		case BINARY:
			str = "(" + exp1.toString () + " " + opers[type] + " " + exp2.toString () + ")";
			break;
		case TERMINAL:
			switch (type)
			{
			case SYMBOL:
				str = id.label ();
				break;
			case FUNCTION:
				str = com.toString ();
				break;
			default:
				// Do nothing
			}
			break;
		default:
			// Do nothing
		}
		
		return str;
	}
}
