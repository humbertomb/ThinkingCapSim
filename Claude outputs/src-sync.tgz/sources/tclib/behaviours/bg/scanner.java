/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

import java.util.*;

import tclib.behaviours.bg.runtime.*;

public class scanner
{
	/*-----------------------------------------------------------*/
	/*--- Constructor(s) ----------------------------------------*/
	/*-----------------------------------------------------------*/

	/** The only constructor is private, so no instances can be created. */
	private scanner () 
	{ 
	}

  /*-----------------------------------------------------------*/
  /*--- Static (Class<?>) Variables ------------------------------*/
  /*-----------------------------------------------------------*/

	protected static int 			next_char; 
	protected static int 			next_char2;
	protected static int 			next_char3;
  	protected static int 			next_char4;
	protected static final int 		EOF_CHAR 			= -1;

	/** Table of keywords.  Keywords are initially treated as identifiers.
	 *  Just before they are returned we look them up in this table to see if
	 *  they match one of the keywords.  The string of the name is the key here,
	 *  which indexes Integer objects holding the symbol number. 
	 */
	protected static Hashtable<String, Integer>		keywords 		= new Hashtable<String, Integer>(60);

	/** Table of single character symbols.  For ease of implementation, we 
	 *  store all unambiguous single character Symbols in this table of Integer
	 *  objects keyed by Integer objects with the numerical value of the 
	 *  appropriate char (currently Character objects have a bug which precludes
	 *  their use in tables).
	 */
	protected static Hashtable<Integer, Integer>	char_symbols 	= new Hashtable<Integer, Integer>(20);

	protected static int			current_line		= 1;
	protected static int 			current_position	= 1;
	protected static int 			absolute_position	= 1;
	public static int 				error_count			= 0;
	public static int 				warning_count		= 0;
	public static boolean			debug				= false;

	public static int 				line () 			{ return current_line; }
	
	/*-----------------------------------------------------------*/
	/*--- Static Methods ----------------------------------------*/
	/*-----------------------------------------------------------*/
	
	/** Initialize the scanner.  This sets up the keywords and char_symbols
	 * tables and reads the first two characters of lookahead.  
	 */
	public static void init () throws java.io.IOException
	{
		/* set up the keyword table */
		keywords.put("tuple",    		Integer.valueOf (bg_sym.TUPLE));
		keywords.put("extern",			Integer.valueOf (bg_sym.EXTERN));
		keywords.put("sensor",			Integer.valueOf (bg_sym.SENSOR));
		keywords.put("effector",		Integer.valueOf (bg_sym.EFFECTOR));
		keywords.put("status",			Integer.valueOf (bg_sym.STATUS));
		keywords.put("initialization",	Integer.valueOf (bg_sym.INITIALIZATION));
		keywords.put("agent",			Integer.valueOf (bg_sym.AGENT));
		keywords.put("function",		Integer.valueOf (bg_sym.FUNCTION));
		keywords.put("return",			Integer.valueOf (bg_sym.RETURN));
		keywords.put("common",     		Integer.valueOf (bg_sym.COMMON));
		keywords.put("behaviour",     	Integer.valueOf (bg_sym.BEHAVIOUR));
		keywords.put("blender",     	Integer.valueOf (bg_sym.BLENDER));
		keywords.put("blending",     	Integer.valueOf (bg_sym.BLENDING));
		keywords.put("range",     		Integer.valueOf (bg_sym.RANGE));
		keywords.put("priority",		Integer.valueOf (bg_sym.PRIORITY));
		keywords.put("rules",			Integer.valueOf (bg_sym.RULES));
		keywords.put("if",				Integer.valueOf (bg_sym.IF));
		keywords.put("else",			Integer.valueOf (bg_sym.ELSE));
		keywords.put("set",				Integer.valueOf (bg_sym.SET));
		keywords.put("float",			Integer.valueOf (bg_sym.FLOAT));
		keywords.put("fsm",				Integer.valueOf (bg_sym.FSM));
		keywords.put("start",			Integer.valueOf (bg_sym.START));
		keywords.put("state",			Integer.valueOf (bg_sym.STATE));
		keywords.put("shift",			Integer.valueOf (bg_sym.SHIFT));
		keywords.put("background",		Integer.valueOf (bg_sym.BACKGROUND));
		keywords.put("fusion",			Integer.valueOf (bg_sym.FUSION));
		keywords.put("trapezoid",		Integer.valueOf (bg_sym.TRAPEZOID));
		keywords.put("sigmoid",			Integer.valueOf (bg_sym.SIGMOID));
		keywords.put("bell",			Integer.valueOf (bg_sym.BELL));
		keywords.put("triangle",		Integer.valueOf (bg_sym.TRIANGLE));
		keywords.put("crisp",			Integer.valueOf (bg_sym.CRISP));
		keywords.put("tsk",				Integer.valueOf (bg_sym.TSK));
		keywords.put("printf",			Integer.valueOf (bg_sym.PRINTF));
		keywords.put("halt",			Integer.valueOf (bg_sym.HALT));
		keywords.put("is",				Integer.valueOf (bg_sym.IS));
		keywords.put("==",				Integer.valueOf (bg_sym.EQUAL));
		keywords.put("!=",				Integer.valueOf (bg_sym.NE));
		keywords.put("<=",				Integer.valueOf (bg_sym.LE));
		keywords.put(">=",				Integer.valueOf (bg_sym.GE));
		keywords.put("<",				Integer.valueOf (bg_sym.LT));
		keywords.put(">",				Integer.valueOf (bg_sym.GT));
		keywords.put("=",				Integer.valueOf (bg_sym.ASSIGN));
		keywords.put("!",				Integer.valueOf (bg_sym.NOT));
		keywords.put("&&",				Integer.valueOf (bg_sym.AND));
		keywords.put("||",				Integer.valueOf (bg_sym.OR));

		/* set up the table of single character symbols */
		char_symbols.put(Integer.valueOf ('{'), Integer.valueOf (bg_sym.BBEGIN));
		char_symbols.put(Integer.valueOf ('}'), Integer.valueOf (bg_sym.BEND));
		char_symbols.put(Integer.valueOf (';'), Integer.valueOf (bg_sym.COLON));
		char_symbols.put(Integer.valueOf (':'), Integer.valueOf (bg_sym.BSTATE));
		char_symbols.put(Integer.valueOf ('('), Integer.valueOf (bg_sym.SEXP));
		char_symbols.put(Integer.valueOf (')'), Integer.valueOf (bg_sym.EEXP));
		char_symbols.put(Integer.valueOf (','), Integer.valueOf (bg_sym.SCOLON));
		char_symbols.put(Integer.valueOf ('+'), Integer.valueOf (bg_sym.PLUS));
		char_symbols.put(Integer.valueOf ('-'), Integer.valueOf (bg_sym.MINUS));
		char_symbols.put(Integer.valueOf ('*'), Integer.valueOf (bg_sym.TIMES));
		char_symbols.put(Integer.valueOf ('/'), Integer.valueOf (bg_sym.DIV));

		next_char = BGParser.read ();
		if (next_char == EOF_CHAR) 
		{
			next_char2 = EOF_CHAR;
			next_char3 = EOF_CHAR;
			next_char4 = EOF_CHAR;
		} 
		else 
		{
			next_char2 = BGParser.read();
			if (next_char2 == EOF_CHAR) 
			{
				next_char3 = EOF_CHAR;
				next_char4 = EOF_CHAR;
			} 
			else 
			{
				next_char3 = BGParser.read();
	 			if (next_char3 == EOF_CHAR) 
					next_char4 = EOF_CHAR;
				else 
					next_char4 = BGParser.read();
			}
		}
		current_line		= 1;
		current_position	= 1;
		absolute_position	= 1;
		error_count			= 0;
		warning_count		= 0;
	}

	public static boolean isEOL (int ch)
	{
		return (ch == '\n' ||  ch == '\r' ||  ch == '\f');		
	}
	
	/** Advance the scanner one character in the input stream.  This moves
	 * next_char2 to next_char and then reads a new next_char2.  
	 */
	protected static void advance () throws java.io.IOException
	{
		int			old_char;

		old_char = next_char;
		next_char = next_char2;
		if (next_char == EOF_CHAR) 
		{
			next_char2 = EOF_CHAR;
 			next_char3 = EOF_CHAR;
			next_char4 = EOF_CHAR;
		} 
		else 
		{
			next_char2 = next_char3;
			if (next_char2 == EOF_CHAR) 
			{
				next_char3 = EOF_CHAR;
				next_char4 = EOF_CHAR;
			} 
			else 
			{
				next_char3 = next_char4;
				if (next_char3 == EOF_CHAR) 
					next_char4 = EOF_CHAR;
				else 
					next_char4 = BGParser.read();
			}
		}

		/* count this */
		absolute_position++;
		current_position++;
		if (isEOL (old_char))
		{
			current_line++;
			current_position = 1;
		}
	}


	/** Emit an error message.  The message will be marked with both the 
	 *  current line number and the position in the line.  Error messages
	 *  are printed on standard error (System.err).
	 */
	public static void emit_error (String message)
	{
		System.err.println("Error at " + current_line + "(" + current_position + "): " + message);
		error_count++;
	}

	/** Emit a warning message.  The message will be marked with both the 
	 *  current line number and the position in the line.  Messages are 
	 *  printed on standard error (System.err).
	 */
	public static void emit_warn (String message)
	{
		System.err.println("Warning at " + current_line + "(" + current_position + "): " + message);
		warning_count++;
	}

	/** Determine if a character is ok to start an id. 
	 */
	protected static boolean id_start_char (int ch)
	{
		return (ch >= 'a' &&  ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch == '_');
	}

	/** Determine if a character is ok for the middle of an id.
	 */
	protected static boolean id_char (int ch)
	{
		return id_start_char(ch) || (ch >= '0' && ch <= '9');
	}

	/** Determine if a character is ok to start a number. 
	 */
	protected static boolean number_start_char (int ch)
	{
		return (ch >= '0' &&  ch <= '9');
	}

	/** Determine if a character is ok for the middle of a number.
	 */
	protected static boolean number_char (int ch)
	{
		return number_start_char(ch) || ch == '.';
	}

	/** Determine if a character is ok to start a multi-char operator. 
	 */
	protected static boolean oper_start_char (int ch)
	{
		return (ch == '=') || (ch == '!') || (ch == '<') || (ch == '>') || (ch == '&') || (ch == '|');
	}

	/** Determine if a character is ok for the middle of a multi-char operator.
	 */
	protected static boolean oper_char (int ch)
	{
		return (ch == '=') || (ch == '<') || (ch == '>') || (ch == '&') || (ch == '|');
	}

	/** Try to look up a single character symbol, returns -1 for not found. 
	 */
	protected static int find_single_char (int ch)
	{
		Integer result;

		result = char_symbols.get (Integer.valueOf ((char)ch));
		if (result == null) 
			return -1;
		else
			return result.intValue();
	}

	/** Handle swallowing up a comment.  Both old style C and new style C++
	 *  comments are handled.
	 */
	protected static void swallow_comment () throws java.io.IOException
	{
		/* next_char == '/' at this point */

		/* is it a traditional comment */
		if (next_char2 == '*')
		{
			/* swallow the opener */
			advance (); 
			advance ();

			/* swallow the comment until end of comment or EOF */
			for (;;)
			{
				/* if its EOF we have an error */
				if (next_char == EOF_CHAR)
				{
					emit_error ("Source file ends inside a comment");
					return;
				}

				/* if we can see the closer we are done */
				if (next_char == '*' && next_char2 == '/')
				{
					advance ();
					advance ();
					return;
				}

				/* otherwise swallow char and move on */
				advance ();
			}
		}

		/* is its a new style comment */
		if (next_char2 == '/')
		{
			/* swallow the opener */
			advance (); 
			advance ();

			/* swallow to EOL or EOF */ 
			while (!isEOL (next_char) && next_char != EOF_CHAR)
				advance ();
			return;
		}

		/* shouldn't get here, but... if we get here we have an error */
		emit_error ("Malformed comment in source file -- ignored");
		advance ();
	}

	/** Process an identifier.  Identifiers begin with a letter, underscore,
	 *  or dollar sign, which is followed by zero or more letters, numbers,
	 *  underscores or dollar signs.  This routine returns a String suitable
	 *  for return by the scanner.
	 */
	protected static Symbol do_id () throws java.io.IOException
	{
		StringBuffer result			= new StringBuffer();
		String       result_str;
		Integer      keyword_num;
		char         buffer[]		= new char[1];

		/* next_char holds first character of id */
		buffer[0] = (char) next_char;
		result.append (buffer,0,1);
		advance ();

		/* collect up characters while they fit in id */ 
		while (id_char (next_char))
		{
			buffer[0] = (char) next_char;
			result.append (buffer,0,1);
			advance ();
		}

		/* extract a string and try to look it up as a keyword */
		result_str = result.toString ();
		keyword_num = keywords.get (result_str);

		/* if we found something, return that keyword */
		if (keyword_num != null)
			return new Symbol (keyword_num.intValue());

		/* otherwise build and return an id Symbol with an attached string */
		return new Symbol (bg_sym.ID, result_str);
	}

	protected static Symbol do_number () throws java.io.IOException
	{
		StringBuffer	result			= new StringBuffer();
		String			result_str;
		Double			number;
		char			buffer[]		= new char[1];

		/* next_char holds first digit of number */
		buffer[0] = (char) next_char;
		result.append (buffer,0,1);
		advance ();

		/* collect up digit while they fit in id */ 
		while (number_char (next_char))
		{
			buffer[0] = (char) next_char;
			result.append (buffer,0,1);
			advance ();
		}

		/* build and return a number Symbol with an attached string */
		result_str = result.toString ();
		try
		{
			number = Double.valueOf (result_str);
		} catch (Exception e)
		{
			emit_warn ("Incorrect floating point number [" + result_str + "]");
			number = Double.valueOf (0.0);
		}
		return new Symbol (bg_sym.DOUBLE, number);
	}

	protected static Symbol do_oper () throws java.io.IOException
	{
		StringBuffer	result			= new StringBuffer();
		String			result_str;
		Integer      	keyword_num;
		char			buffer[]		= new char[1];

		/* next_char holds first symbol of multi-char operator */
		buffer[0] = (char) next_char;
		result.append (buffer, 0, 1);
		advance ();

		/* collect up digit while they fit in id */ 
		while (oper_char (next_char))
		{
			buffer[0] = (char) next_char;
			result.append (buffer, 0, 1);
			advance ();
		}

		/* extract a string and try to look it up as a keyword */
		result_str = result.toString ();
		keyword_num = keywords.get (result_str);

		/* if we found something, return that keyword */
		if (keyword_num != null)
			return new Symbol (keyword_num.intValue());

		emit_warn ("Invalid operator '" + result_str + "' -- ignored");
		return new Symbol (bg_sym.ID, result_str);
	}

	/** Return one Symbol.  This is the main external interface to the scanner.
	 *  It consumes sufficient characters to determine the next input Symbol
	 *  and returns it.
	 */
	public static Symbol next_token () throws java.io.IOException
	{
		Symbol				result; 
		
		result = real_next_token ();
		if (debug)
			System.out.println("# next_Symbol() => " + result.sym);
		return result;
	}

	/** The actual routine to return one Symbol.  
	 */
	 protected static Symbol real_next_token () throws java.io.IOException
	{
		int sym_num;

		for (;;)
		{
			/* look for white space */
			if (Character.isWhitespace ((char) next_char))
			{
				/* advance past it and try the next character */
				advance ();
				continue;
			}

			/* look for a comment */
			if (next_char == '/' && (next_char2 == '*' || next_char2 == '/'))
			{
				/* swallow then continue the scan */
				swallow_comment ();
				continue;
			}

			/* look for a single character symbol */
			sym_num = find_single_char (next_char);
			if (sym_num != -1)
			{
				/* found one -- advance past it and return a Symbol for it */
				advance ();
				return new Symbol (sym_num);
			}

			/* look for a number */
			if (number_start_char (next_char)) return do_number ();
			
			/* look for a multi-char operator */
			if (oper_start_char (next_char)) return do_oper ();
			
			/* look for an id or keyword */
			if (id_start_char (next_char)) return do_id ();

			/* look for EOF */
			if (next_char == EOF_CHAR) return new Symbol (bg_sym.EOF);

			/* if we get here, we have an unrecognized character */
			emit_warn ("Unrecognized character '" + Character.valueOf ((char) next_char) + "'(" + next_char + ") -- ignored");
			advance ();
		}
	}
}

