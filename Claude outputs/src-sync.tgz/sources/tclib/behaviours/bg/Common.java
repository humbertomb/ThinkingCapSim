/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class Common extends List
{
	protected VSymbol		loc; 
	protected Command		com;
		
	/* Constructors */
	protected Common ()
	{		
	}

	public Common (VSymbol loc, Command com)
	{
		this.create (loc, com);
	}
	
	/* Accessor methods */
	public final VSymbol 	loc () 					{ return loc; }
	public final Command 	com () 					{ return com; }

	/* Instance methods */
	protected void create (VSymbol loc, Command com)
	{
		this.loc			= loc;
		this.com			= com;
	}

	public String toString ()
	{
		String		str;
		String		list;
		VSymbol		vs;
		Command		cs;
		
		str 	= "\tcommon\n\t{\n";
		
		list = " ";
		vs 	= loc;
		while (vs != null)
		{
			list += vs.label ();
			if (vs.next () != null)
				list += ", ";
			vs = (VSymbol) vs.next ();
		}
		if (list.length () > 1)
			str += "\t\tfloat " + list + ";\n";

		cs 	= com;
		while (cs != null)
		{
			str += "\t\t" + cs.toString () + "\n";
			cs = (Command) cs.next ();
		}
				
		return str + "\t}\n\n";
	}
}
