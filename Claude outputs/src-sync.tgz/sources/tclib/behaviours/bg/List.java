/*
 * (c) 1997-2001 Humberto Martinez
 */
 
package tclib.behaviours.bg;

public class List extends Object
{
	private List			next;
	protected String		name;
	
	/* Constructors */
	public List (String name, List next)
	{
		this.next = next;
		this.name = name;
	}
	
	public List (List next)
	{
		this (new String (), next);
	}
	
	public List()
	{
		this (new String (), null);
	}
	
	/* Accessor methods */
	public final List 		next () 				{ return next; }
	public final void 		next (List next)			{ this.next = next; }
	public final String		name () 				{ return name; }
	public final void 		name (String name)		{ this.name = name; }
	
	/* Instance methods */
	public List addlast (List t)
	{
		List	plist;
		
		plist = this;
		while (plist.next () != null)
		{
			plist = plist.next ();
		}
		plist.next (t);
		return this;
	}
	
	public List addfirst (List t)
	{
		t.next (this);
		return t;
	}

	public int count ()
	{
		List			plist;
		int			count;
		
		count = 0;
		plist = this;
		while (plist != null)
		{
			count ++;
			plist = plist.next ();
		}
		return count;
	}

	public List search (String name)
	{
		List			plist;
		
		plist = this;
		while (plist != null)
		{
			if ((plist.name ()).equals (name))
				return plist; 
			plist = plist.next ();
		}
		return null;
	}
	
/*	public Object clone ()
	{
		List		clon;
		List		tnext;
		
System.out.println ("Cloning List node " + name);
//		clon	= (List) clone ();
//		clon.next	= (List) next.clone ();

		tnext	= null;
		if (next != null)
			tnext = (List) next.clone ();
		clon	= new List (name, tnext);
		
		return clon;
	}
*/
}
