/*
 * @(#)RasmusControl.java		1.0 2004/01/24
 * 
 * (c) 2004 Denis Remondini
 * (c) 2004 Humberto Martinez
 *
 */
package tclib.behaviours.fhb;

import tc.runtime.thread.ModuleConfig;
import java.util.*;

import tc.modules.*;
import tc.shared.linda.*;
import tc.shared.lps.lpo.*;
import tclib.behaviours.fhb.exceptions.*;
import tclib.planning.sequence.*;

import devices.pos.*;
import wucore.utils.logs.*;
import wucore.utils.math.*;

/**
 * This class implements the controller.
 *  
 * @version	1.0		24 Jan 2004
 * @author Denis Remondini
 */
public class FHBController extends Controller
{
	static public final String		PREFFIX			= "CNTL_";
		
	// Controller debug
	protected LogPlot				c_plot;
	protected LogFile				c_dump;
	protected double[]				c_buffer;
	protected String[]				c_labels;
	
	// Behaviour fusion debug
	private LogPlot					b_plot;
	private LogFile					b_dump;
	private double[]				b_buffer;
	
	/* Goal and task related variables */
	protected boolean				new_goal;					// New goal received
	protected long					new_id;						// New task ID received
	protected Task					new_plan;					// New task received
	
	protected boolean				gotgoal;					// Is there a goal point?
	protected Task					plan;						// Current goal task
	protected long					idtask;						// Current task ID
	
	/* Current robot to desired path distance */				
	protected Path					path;						// Desired robot path
	protected Position				pos;						// Current robot location
	protected Position				looka;						// Current look-ahead point
	protected double				looka_dst;					// Current look-ahead distance (m)
	protected double				path_dst;					// Current robot to desired path distance (m)
		
	/* Linda items */
	protected ItemBehInfo 			bItem;
	protected Tuple 				bTuple;
	
	/* FHB executor parameters */
	protected String				behMain;					// Main behaviour class name
	
	/* It stores the result of the main behaviour execution */
	private ControlVariables 		output;
	/* The list of parameters used by the behaviours */
	private HashMap<String, Object> 				param;
	/* The main behaviour */
	private Behaviour 				beh;
	/* The information about a behaviour */
	private BehaviourInfo 			behInfo;
	/* The behaviour of which the debug window has requested information */
	private Behaviour 				behReq;
	/* 
	 * The path that has to be followed to reach the behaviour 
	 * requested by the debug window 
	 */
	private ArrayList<String> 		behReqPath;
	
	/* FHB state flags */
	private boolean 				behReload;					// Is a behaviour reload need?
	private boolean 				behSendInfo;				// Is behaviour info needed?
	
	/**
	 * Creates and initializes a new controller
	 */
	public FHBController (ModuleConfig cfg, Linda linda)
	{
		super (cfg, linda);
		super.initialise (cfg); 
	}
	
	/*
	 * Initializes the controller
	 * 
	 * @see tc.runtime.thread.StdThread#initialise(java.util.Properties)
	 */
	protected void initialise (ModuleConfig cfg)
	{		
		// Initialise local structures
		looka		= new Position ();
		pos			= new Position ();
		plan		= new Task ();
		
		new_plan	= new Task ();
		new_goal	= false;
		new_id		= 0;
		
		gotgoal		= false;
		idtask		= 0;
		looka_dst	= 0.75;
		
		// Initialise debug modules
		c_buffer	= new double[2];
		c_labels	= new String[4];
		c_labels[0]	= "speed";
		c_labels[1]	= "turn";
		c_dump		= new LogFile (PREFFIX, ".log");
		c_plot		= new LogPlot ("Controller Output", "step", "values");
		
		b_dump		= new LogFile (PREFFIX, ".beh");
		b_plot		= new LogPlot ("Behaviour Fusion", "step", "DoA");
		b_plot.setImpulses (true);
		b_plot.setYRange (0.0, 1.0);		
		
		/* creates the linda item and tuple about the behaviour information */
		bItem 		= new ItemBehInfo ();
		bTuple 		= new Tuple (Tuple.BEHINFO, bItem);
	
		/* variables initialization */
		param = new HashMap<String, Object> ();
		behReq 		= null;
		behReqPath	= null;
		behReload	= false;
		behSendInfo = false;
		
		// Read factory and behaviours configuration
		BehaviourFactory.loadConfiguration (cfg.get ("FACT"));
		behMain		= cfg.get ("BEH");
		beh			= BehaviourFactory.createBehaviour (behMain);
	}
	
	protected int inGoal ()
	{
		double			dx, dy;
		double			dist, delta;

		// Check whether we received a goal point
		if (!gotgoal)		return ItemBehResult.T_NOTYET;
		
		// Check if goal position has been reached
		dx		= plan.tpos.x () - pos.x ();
		dy		= plan.tpos.y () - pos.y ();
		dist		= Math.sqrt (dx * dx + dy * dy);										// [m]
		delta	= Math.abs (Angles.radnorm_180 (plan.tpos.alpha () - pos.alpha ()));	// [rad]	

		if ((dist < plan.tol_pos) && (delta < plan.tol_head))		
			return ItemBehResult.T_FINISHED;
		
		return ItemBehResult.T_NOTYET;
	}
	
	protected void controller () 
	{
		int					i;
		int					result;
		LPOSensorRange		virtual;
		LPOSensorGroup		group;
		LPO[]				lpos;
		LPO					l_looka;
		double				speed, turn;

		// Compute look-ahead point
		pos.set (lps.cur);
		looka.set (pos);
		looka.valid (false);
		if (!new_goal && (path != null))
		{
			path.check_lookahead (pos, looka_dst);
			if (path.lookahead () != null)
			{
				path_dst	= path.distance ();
				looka.set (path.lookahead ());
				looka.valid (true);
			}
		}

		// Update LPS
		l_looka		= lps.find ("Looka");
		if (l_looka != null)
		{
			l_looka.locate (looka.x () - pos.x (), looka.y () - pos.y (), pos.alpha ());
			l_looka.active (looka.valid ());
		}

		// Put percepts into FHB executor (read all LPOs)
		lpos	= lps.lpos ();
		for (i = 0; i < lps.lpos_n (); i++)
			beh.setParam (lpos[i].label (), lpos[i]);
					
//		beh.setParam ("crossSpeed",Double.valueOf (0.1));
//		beh.setParam ("wanderSpeed",Double.valueOf (0.4));
//		beh.setParam ("followSpeed",Double.valueOf (0.2));

		virtual	= (LPOSensorRange) lps.find ("Virtual");
		for (i = 0; i < fdesc.MAXVIRTU; i++)
			beh.setParam ("Virtu"+i, Double.valueOf (virtual.range[i]));

		group	= (LPOSensorGroup) lps.find ("Group");
		beh.setParam ("Groups", Double.valueOf (fdesc.MAXGROUP));
		for (i = 0; i < fdesc.MAXGROUP; i++)
			beh.setParam ("Group"+i, Double.valueOf (group.range[i]));

		beh.setParam ("x", Double.valueOf (pos.x ()));
		beh.setParam ("y", Double.valueOf (pos.y ()));
		beh.setParam ("alpha", Double.valueOf (pos.alpha ()));
		beh.setParam ("heading", Double.valueOf (Math.atan2 ((looka.y () - pos.y ()), (looka.x () - pos.x ()))));

		// Invoke the FHB executor		
		try { output = beh.exec (); }
		catch (RuleException e)
		{
			System.out.println ("--[FHB] "+e.toString());
		}
		output.defuzzify();
		
		// Read the specified action from FHB executor
		speed	= output.getCrispValue(ControlVariables.SPEED);
		turn	= output.getCrispValue(ControlVariables.ROTATION) * Angles.DTOR;

		// Set action
		result	= inGoal ();
		switch (result)
		{
		case ItemBehResult.T_FINISHED:
			speed 	= 0.0;
			turn	= 0.0;
			
			// Notify Linda Space the task has been finished
			setResult (result, ItemBehResult.F_OK, idtask);
			break;
			
		case ItemBehResult.T_FAILED:
			speed 	= 0.0;
			turn	= 0.0;
			
			// Notify Linda Space the task has failed
			setResult (result, ItemBehResult.F_BEHIND, idtask);			// or ItemBehResult.F_SIDE
			break;
			
		case ItemBehResult.T_NOTYET:
		default:
			if (!looka.valid ())
			{
				speed 	= 0.0;
				turn	= 0.0;
			}
		}
		setMotion (speed, turn);

		// Plot current control commands
		if (debug)
		{
			c_buffer[0] 	= Math.max (Math.min (speed / rdesc.model.Vmax, 1.0), -1.0);
			c_buffer[1] 	= Math.max (Math.min (turn / rdesc.model.Rmax, 1.0), -1.0);

			if (localgfx)
				c_plot.draw (c_buffer);	
			else
				c_dump.write (c_buffer);
		}
	}
	
	/**
	 * This method is called every control cycle and it represent the core of the controller
	 */
	protected void close_gfx ()
	{
		if (c_plot != null)		c_plot.close ();
		if (b_plot != null)		b_plot.close ();
	}

	public void step (long ctime) 
	{
		int				i;
		BehaviourInfo	info;
		
		if (state != RUN)											return;
		
		// Reloads the main behaviour if it is requested
		if (behReload) 
		{
			beh = BehaviourFactory.createBehaviour (behMain);
			findBehRequested (behReqPath);
			behReload = false;
		}

		if (!auto || (beh == null) || (lps == null))		return;	
		if (!gotgoal)									return;
		
		// Set last goal received as the current one
		if (idtask != new_id)
		{
			idtask		= new_id;
			plan.set (new_plan);
				
			if (debug)		System.out.println ("  [FHB] Working with task [" + plan + "] and ID: " + idtask);
		}
					
		// Run the FHB behaviours
		controller ();

		// Updates the behaviour information in the Linda space
		if (behSendInfo)
			sendBehInformation ();

		// Update behaviour fusion information 
		if (debug)
		{
			System.out.println ("  [FHB] Control cycle: " + (System.currentTimeMillis () - ctime) + " ms");

			info 		= setBehInfo (beh);
			b_buffer	= new double[info.getRulesNumber ()];
			
			for (i = 0; i < info.getRulesNumber (); i ++)
				b_buffer[i]		= info.getRuleAntecedentValue (i);

			if (localgfx)
				b_plot.draw (b_buffer);	
			else if (!localgfx)
				b_dump.write (b_buffer);
		}
	}
	
	/*
	 * Writes the behaviour information to the linda space 
	 */
	private void sendBehInformation() 
	{
		if (behReq == null)
			behInfo = setBehInfo(beh);
		else 
			behInfo = setBehInfo(behReq);
		
		bItem.set(behInfo);		 	
		linda.write(bTuple);	
	}
	
	/*
	 * Finds the behaviour requested. The list contains the path to reach the behaviour.
	 */
	private void findBehRequested(ArrayList<String> list) {
		RuleSet rules;
		ArrayList<String> rulesNames;
		Behaviour currentBeh;
		
		if ((list == null) || (list.isEmpty()))
			behReq = null;
		else {
			currentBeh = beh;
			for (int i = 0; i < list.size(); i++) {
				String ruleName = list.get(i);
				int j = 0;
				rules = currentBeh.getRuleSet();
				rulesNames = rules.getRulesNames();
				while ((j < rulesNames.size()) && (!ruleName.equals(rulesNames.get(j))))
					j++;
				if (j == rulesNames.size())
					break;
				currentBeh = rules.getRule(ruleName).getSubBehaviour();
			}
			behReq = currentBeh;
		}
	}
	
	/*
	 * Sets the information about a behaviour 
	 */
	private BehaviourInfo setBehInfo(Behaviour b) {
		
		BehaviourInfo behInfo = new BehaviourInfo(b.getName());
		behInfo.setAntecedentPredicates(b.getAntecedentValues());
		RuleSet behRules = b.getRuleSet();
		setRulesInformation(behInfo,behRules);
		behInfo.setOutputFSets(b.getOutputFSets());
		behInfo.setValuesSentToRobot(output.getCrispValues());

		return behInfo;
	}

	/*
	 * Sets the information about the rules of a behaviour
	 */
	private void setRulesInformation(BehaviourInfo behInfo, RuleSet rules) {
		Rule currentRule;
		Behaviour beh;
		ArrayList<String> rulesNames = rules.getRulesNames();
		for (int i = 0; i < rulesNames.size(); i++) {
			currentRule = rules.getRule(rulesNames.get(i));

			beh = currentRule.getSubBehaviour();			
			if (beh != null)
				behInfo.addRule(rulesNames.get(i),currentRule.getAntecedentValue(),currentRule.getOutputFSets(),beh.getName(),beh.getParameters());
			else 
				behInfo.addRule(rulesNames.get(i),currentRule.getAntecedentValue(),currentRule.getOutputFSets(),null,null);
		}
	}
	
	/**
	 * This method is called when the BehDebug item is written to the linda space
	 * @param item the BehDebug item written to the linda space
	 */
	public void notify_beh_debug(String space, ItemBehDebug item) {
		if (item.getCommand() == ItemBehDebug.START) {
			behSendInfo = true;
		} else {
			behSendInfo = false;
		}
		behReq = null;
		behReqPath = null;
	}
	
	/**
	 * This method is called when the BehName item is written to the linda space
	 * @param item the BehName item written to the linda space 
	 */
	public void notify_beh_name(String space, ItemBehName item) {
		BehaviourFactory.createBehaviour(item.get(),true);
		behReload = true;
	}
	
	/**
	 * This method is called by monitor to tell what is the behaviour requested by the
	 * debug information window
	 */
	public void notify_beh_rules(String space, ItemBehRules item) {
		behReqPath = item.get();
		findBehRequested(behReqPath);	
		sendBehInformation();	
	}
	
	public void notify_execution (String space, ItemExecution item)
	{
		String[]			labels = null;

		super.notify_execution (space, item);
	    	    
		if (debug)
		{
			if (beh != null)
			{
				int					i;
				ArrayList<String>	names;

				names	= beh.getRuleSet ().getRulesNames ();
				labels	= new String [names.size ()];
				for (i = 0; i < names.size (); i++)
					labels[i]	= names.get (i);
			}
		
			if (localgfx)
			{
				if (labels != null)		
					b_plot.open (labels);
				c_plot.open (c_labels);
			}
			else
			{
				if (labels != null)		
					b_dump.open (labels);
				c_dump.open (c_labels);
			}
		}
		else
		{
			b_dump.close ();
			c_dump.close ();
		}
	}
	
	public void notify_config (String space, ItemConfig item) 
	{
		super.notify_config (space, item);
	}
	
	public void notify_goal (String space, ItemGoal goal) 
	{
		LPOPoint			l_goal;
	
		// Update LPS
		l_goal		= (LPOPoint) lps.find ("Goal");
		if (l_goal != null)
		{
			l_goal.update (pos, goal.task.tpos);
			l_goal.active (true);
		}
			
		new_plan.set (goal.task);		
		new_id		= goal.timestamp.longValue ();
		
		new_goal		= true;
		gotgoal		= true;
	}
	
	public void notify_path (String space, ItemPath item)
	{
		path		= item.path;	
		
		new_goal	= false;
	}	
}
