/***************************************************************
 *
 *  LPOFSegment.java
 *
 *	Manages a fuzzy line segment.
 *
 *  (c) 1998 Jorge Gasos & Alessandro Saffiotti
 *  (c) 2000 Humberto Martinez
 *  (c) 2003 Humberto Martinez
 ***************************************************************/

package tclib.navigation.mapbuilding.lpo;

import java.io.*;
//import java.awt.*;

import tc.shared.lps.lpo.*;

import devices.pos.*;
import wucore.widgets.*;
import wucore.utils.math.*;
import wucore.utils.color.*;

public class LPOFSegment extends LPO implements Serializable
{
	public static final double			EPSILON			= 0.0001;
	
	// Parameters for segments fusion
	public static final double			PHI_MATCH		= 0.0001;	/* Degree of matching in "phi" required to combine two segments */
	public static final double			RHO_MATCH		= 0.005;	/* Degree of matching in "rho" required to combine two segments */

	public static final double			LINE_K1			= 0.0005;	// Tolerances for detecting coincidence in segments
	public static final double			LINE_K2			= 0.0010;
	public static final double			LINE_K3			= 0.0015;

	protected int						count;
	protected double					xi;
	protected double					yi;
	protected double					xf;
	protected double					yf;
	protected double					len;
	protected double					v0_phi;
	protected double					v0_rho;
	protected double					v1_phi;
	protected double					v1_rho;
	
	// Visual representation
	protected WColor				color2;
	
	// Constructor
	public LPOFSegment ()
	{
		active	= true;
		
		color	= WColor.CYAN;
		color2	= WColor.BLUE;
	}
	
	// Accessors
	public final double			xi ()				{ return xi; }
	public final double			yi ()				{ return yi; }
	public final double			xf ()				{ return xf; }
	public final double			yf ()				{ return yf; }
	
	public final double			v0_phi ()			{ return v0_phi; }
	public final double			v0_rho ()			{ return v0_rho; }
	public final double			v1_phi ()			{ return v1_phi; }
	public final double			v1_rho ()			{ return v1_rho; }
	
	public final int			count ()			{ return count; }
	public final double			len ()				{ return len; }
	
	public final void			setColor (WColor color, WColor color2)		{ this.color = color; this.color2 = color2; }

	// Class methods
	static public double dist (double xi, double yi, double xf, double yf)
	{
		return Math.sqrt ((xi - xf) * (xi - xf) + (yi - yf) * (yi - yf));
	}
	
	static public double hypot (double x, double y)
	{
		return Math.sqrt (x * x + y * y);
	}
	
	/* Returns the degree of matching between two fuzzy sets (phi, alfa)
	 * that are defined by their central point (the fuzzy sets are symmetric
	 * with respect to this point) and by the length of their alpha-cuts in 1
	 * and 0. To reduce computations, in some cases (see notes) it approximates
	 * the result. 
	 */
	static public double matching (double phi, double v1_phi, double v0_phi, double alfa, double v1_alfa, double v0_alfa)
	{
		double		inters0, inters1, aux1, aux2;

		aux1 = 0.5*v0_phi;    
		aux2 = 0.5*v0_alfa;
		inters0 = Math.min(phi+aux1,alfa+aux2) - Math.max(phi-aux1,alfa-aux2);
		if (inters0 < EPSILON)		return 0.0;
		
		aux1 = 0.5*v1_phi;    
		aux2 = 0.5*v1_alfa;
		inters1 = Math.min(phi+aux1,alfa+aux2) - Math.max(phi-aux1,alfa-aux2);
		if (inters1 > 0.0)  
			aux1 = 0.5*(inters1+inters0);
		else  
			aux1 = inters0*inters0/(v0_phi-v1_phi+v0_alfa-v1_alfa);
		
		return(aux1*(1.0/(v0_phi+v1_phi) + 1.0/(v0_alfa+v1_alfa)));
	}

	/* Returns in m[1..4] the limit values of the translations that match alfa to phi,
	 * where m1 and m4 are the translations of alfa that generate a degree of matching
	 * md with phi. Note: FORTRAN style array, with cell m[0] not used.
	 */
	static public void inverse_match (double phi, double v1_phi, double v0_phi, double alfa, double v1_alfa, double v0_alfa, double md, double[] m)
	{
		double		area1, area2, aux1, aux2, aux3, aux4, aux5, aux6;

		area1 = 0.5*(v1_phi+v0_phi);
		area2 = 0.5*(v1_alfa+v0_alfa);
		aux1 = 2.*md*area1*area2/(area1+area2);
		aux2 = v0_phi + v0_alfa;
		aux3 = v1_phi + v1_alfa;
		aux4 = aux2 - aux3;
		aux5 = 0.25*(aux2+aux3) - aux1;
		aux6 = phi - alfa;

		/* The matching of the fuzzy sets cannot reach the value md */
		if (aux5 < 0.)  
			m[1] = m[4] = aux6;
		else if (aux1 > (0.25*aux4)) 
		{
			/* The solution overlaps the areas of maximum membership of the fuzzy sets */
			m[1] = aux6 - aux5;
			m[4] = aux6 + aux5;
		}
		else 
		{
			aux5 = 0.5*aux2 - Math.sqrt(aux1*aux4);
			if (aux5 > 0.) 
			{
				/* The solution does not overlap the areas of maximum membership */
				m[1] = aux6 - aux5;
				m[4] = aux6 + aux5;
			}
			else  
				m[1] = m[4] = aux6;
		}
	}

	/* Returns in m[1..4] a fuzzy set of translations that match alfa to phi.
	 * m1 and m4 are the translations of alfa that generate a degree of matching md1
	 * with phi. m2 and m3 are the translations of alfa that generate a degree of
	 * matching md2 with phi. Note: FORTRAN style array, with cell m[0] not used.
	 */
	static public void inverse_set (double phi, double v1_phi, double v0_phi, double alfa, double v1_alfa, double v0_alfa, double md1, double md2, double m[])
	{
		double		area1, area2, aux, aux1, aux2, aux3, aux4, aux5, aux6, aux7;

		area1 = 0.5*(v1_phi+v0_phi);       
		area2 = 0.5*(v1_alfa+v0_alfa);
		aux  = 2.*area1*area2/(area1+area2);
		aux1 = md1*aux;
		aux2 = v0_phi + v0_alfa;           
		aux3 = v1_phi + v1_alfa;
		aux4 = aux2 - aux3;
		aux5 = 0.25*(aux2+aux3);
		aux6 = aux5 - aux1;
		aux7 = phi - alfa;

		/* The matching of the fuzzy sets cannot reach the value md1 */
		if (aux6 < 0.) 
			m[1] = m[4] = aux7;
		else if (aux1 > (0.25*aux4)) 
		{
			/* The solution overlaps the areas of maximum membership of the fuzzy sets */
			m[1] = aux7 - aux6;      
			m[4] = aux7 + aux6;
		}
		else 
		{
			aux6 = 0.5*aux2 - Math.sqrt(aux1*aux4);
			if (aux6 > 0.) 
			{
				/* The solution does not overlap the areas of maximum membership */
				m[1] = aux7 - aux6;        
				m[4] = aux7 + aux6;
			}
			else  
				m[1] = m[4] = aux7;
		}
		
		aux1 = md2*aux;
		aux6 = aux5 - aux1;

		/* The matching of the fuzzy sets cannot reach the value md2 */
		if (aux6 < 0.)  
			m[2] = m[3] = aux7;
		else if (aux1 > (0.25*aux4)) 
		{
			/* The solution overlaps the areas of maximum membership of the fuzzy sets */
			m[2] = aux7 - aux6;      
			m[3] = aux7 + aux6;
		}
		else 
		{
			aux6 = 0.5*aux2 - Math.sqrt(aux1*aux4);
			if (aux6 > 0.) 
			{
				/* The solution does not overlap the areas of maximum membership */
				m[2] = aux7 - aux6;        
				m[3] = aux7 + aux6;
			}
			else  
				m[2] = m[3] = aux7;
		}
	}

	/* Returns the degree of membership of 'x' to the trapezoidal fuzzy set
	 * defined by (m1,m2,m3,m4) 
	 */
	static public double membership (double x, double m1, double m2, double m3, double m4)
	{
		if ((x<=m1) || (x>=m4))		return 0.0;
		if (x < m2)					return ((x-m1)/(m2-m1));
		if (x<=m3)					return 1.0;
		return ((m4-x)/(m4-m3));
	}

	// Instance methods
	public void set (LPOFSegment other)
	{
		set (other.rho, other.phi, other.v0_rho, other.v0_phi, other.v1_rho, other.v1_phi, other.count, other.len);
		set_limits (other.xi, other.yi, other.xf, other.yf);
	}
	
	public void set (double rho, double phi, double v0_rho, double v0_phi, double v1_rho, double v1_phi, int count, double len)
	{
		this.rho	= rho;
		this.phi	= phi;
		
		this.v0_rho	= v0_rho;
		this.v0_phi	= v0_phi;
		this.v1_rho	= v1_rho;
		this.v1_phi	= v1_phi;
		
		this.count	= count;
		this.len	= len;
	}
	
	public void set_limits (double xi, double yi, double xf, double yf)
	{
		this.xi		= xi;
		this.yi		= yi;
		this.xf		= xf;
		this.yf		= yf;
	}
	
	public void set_origin (Position pos)
	{
		double		lrho, lphi;
		
		// Compute first limit (xi, yi)
		lrho	= Math.sqrt (xi * xi + yi * yi);
		lphi	= Math.atan2 (yi, xi);
		
		xi		= pos.x () + lrho * Math.cos (lphi + pos.alpha ());
		yi		= pos.y () + lrho * Math.sin (lphi + pos.alpha ());
		
		// Compute last limit (xf, yf)
		lrho	= Math.sqrt (xf * xf + yf * yf);
		lphi	= Math.atan2 (yf, xf);

		xf		= pos.x () + lrho * Math.cos (lphi + pos.alpha ());
		yf		= pos.y () + lrho * Math.sin (lphi + pos.alpha ());

		// Compute segment (phi, rho) parameters: x*cos(phi) + y*sin(phi) = rho
		if ((yi - yf) == 0.0)
		{
			if (xf >= xi)
				phi		= 0.0;
			else
				phi		= Math.PI;
		}
		else if ((xi - xf) == 0.0)
		{
			if (yf >= yi)
				phi		= Angles.PI05;
			else
				phi		= Angles.PI05 * 3.0;
		}
		else
			phi		= Math.atan ((xf - xi) / (yi - yf));		// <= Is it correct?
			
		phi		= Angles.radnorm_180 (phi);
		rho		= xf * Math.cos (phi) + yf * Math.sin (phi);
		
		// Mantain LPO basic properties
		x		= rho * Math.cos (phi);
		y		= rho * Math.sin (phi);
	}
	
	/* Checks if two segments correspond to the same boundary of an object in
	 * which case it combines them in this segment.
	 * Two segments are combined when their matching in "phi" is larger than
	 * PHI_MATCH, their matching in "rho" is larger than RHO_MATCH, and they also
	 * have intersection. 
	 */
	public boolean group (LPOFSegment s1, LPOFSegment s2)
	{
		double		d, temp, aux1, aux2, aux3;
		double		xi1, yi1, xf1, yf1, xi2, yi2, xf2, yf2;
		double		minx, miny, maxx, maxy;
		double		s1_phi, s2_phi, s2_rho;

		/* We have to avoid problems due to: 1) the universe of discourse of
		 * orientations is circular (-180 == 180); 2) two segments with values of
		 * 'rho' close to zero and Math.abs (phi1-phi2)==180 might correspond to the same
		 * object; y 3) the representation of segments in terms of (rho,phi) is
		 * dependent on the location of the origin of coordinates.
		 * We rotate the origin of coordinates before comparing the segments, the
		 * new orientation being the mean of the orientations (solves 1). Case 2 is
		 * considered every time that we operate on the segments. Case 3 is solved
		 * when computing the new value of 'rho' 
		 */
		
		// Store segments parameters to avoid changing them in the original segments!!
		s1_phi	= s1.phi;
		s2_phi	= s2.phi;
		s2_rho	= s2.rho;
		
		/* Rotation of the origin of coordinates */
		aux1 = Math.abs (s1_phi - s2_phi);
		if ((aux1 > Angles.PI05) && (aux1 < Angles.PI15))					// Case 2
		{
			if (s2_phi < 0.0)  
				s2_phi += Math.PI;
			else 
				s2_phi -= Math.PI;
			s2_rho = -s2_rho;
			aux1 = Math.abs (s1_phi - s2_phi);
		}
		if (aux1 > Angles.PI15)
		{
			if (s1_phi < 0.0)  
				s1_phi += Angles.PI2;
			else 
				s2_phi += Angles.PI2;
		}
		
		count	= s1.count + s2.count;
		phi		= Angles.radnorm_180 ((s1.count*s1_phi + s2.count*s2_phi)/count);
		s1_phi	= Angles.radnorm_180 (s1_phi - phi);
		s2_phi	= Angles.radnorm_180 (s2_phi - phi);
		if (matching (s1_phi, s1.v1_phi, s1.v0_phi, s2_phi, s2.v1_phi, s2.v0_phi) < PHI_MATCH)
			return false;

		/* Checks if the segments have intersection. It studies their projection on
		 * the Y axis of the rotated coordinate system. 
		 */
		aux2 = Math.cos (phi);
		aux3 = Math.sin (phi);
		xi1 = s1.xi*aux2 + s1.yi*aux3;
		yi1 = s1.yi*aux2 - s1.xi*aux3;
		xf1 = s1.xf*aux2 + s1.yf*aux3;
		yf1 = s1.yf*aux2 - s1.xf*aux3;
		xi2 = s2.xi*aux2 + s2.yi*aux3;
		yi2 = s2.yi*aux2 - s2.xi*aux3;
		xf2 = s2.xf*aux2 + s2.yf*aux3;
		yf2 = s2.yf*aux2 - s2.xf*aux3;
		if (yi1 > yf1) 
		{
			temp = yi1;    yi1 = yf1;    yf1 = temp;
			temp = xi1;    xi1 = xf1;    xf1 = temp;
		}
		if (yi2 > yf2) 
		{
			temp = yi2;    yi2 = yf2;    yf2 = temp;
			temp = xi2;    xi2 = xf2;    xf2 = temp;
		}
		if ((yi2>yf1) || (yi1>yf2))
			return false;

		/* To check their matching in 'ro' it rotates the segments around their
		 * central point until they are parallel to the orientation of the new
		 * segment and it then compares their values of 'ro'. This is equivalent
		 * to compare the values of X of the central points of the segments in
		 * the rotated coordinate system.
		 */
		if (matching(0.5*(xi1+xf1), s1.v1_rho, s1.v0_rho, 0.5*(xi2+xf2), s2.v1_rho, s2.v0_rho) < RHO_MATCH)
			return false;

		/* Rho of the new segment with respect to the original coordinate system: */
		rho = 0.5*(s1.count*(xi1+xf1) + s2.count*(xi2+xf2))/count;
		if (rho < 0.0) 
		{
			rho = -rho;
			if (phi < 0.0)  
				phi += Math.PI;
			else  
				phi -= Math.PI;   
			xi1 = -xi1;    yi1 = -yi1;    xf1 = -xf1;    yf1 = -yf1;
			xi2 = -xi2;    yi2 = -yi2;    xf2 = -xf2;    yf2 = -yf2;
			if (yi1 > yf1)
			{
				temp = yi1;    yi1 = yf1;    yf1 = temp;
				temp = xi1;    xi1 = xf1;    xf1 = temp;
			}
			if (yi2 > yf2) 
			{
				temp = yi2;    yi2 = yf2;    yf2 = temp;
				temp = xi2;    xi2 = xf2;    xf2 = temp;
			}
		}

		/* Position of the limits of the new segment. */
		aux2 = Math.cos (phi);
		aux3 = Math.sin (phi);
		miny = Math.min(yi1,yi2);
		maxy = Math.max(yf1,yf2);
		minx = maxx = rho;
		xi = minx*aux2 - miny*aux3;
		yi = miny*aux2 + minx*aux3;
		xf = maxx*aux2 - maxy*aux3;
		yf = maxy*aux2 + maxx*aux3;
		len = dist (xi,yi,xf,yf);

		/* See 'Combining Coincident Segments' in the documentation. */
		d		= 0.5*Math.abs (xi1+xf1-xi2-xf2);
		aux3	= Math.max(0, Math.min(s1.v1_rho,s2.v1_rho)- Math.max(0,0.5*(s1.v1_rho+s2.v1_rho)-d));
		v1_rho	= (s1.count*s1.v1_rho+s2.count*s2.v1_rho+Math.min(s1.count,s2.count)*aux3)/count;
		aux3	= Math.max(0,Math.min(s1.v0_rho,s2.v0_rho)-Math.max(0,0.5*(s1.v0_rho+s2.v0_rho)-d));
		v0_rho 	= (s1.count*s1.v0_rho+s2.count*s2.v0_rho+Math.min(s1.count,s2.count)*aux3)/count;
		v1_phi 	= 2.0 * Math.atan(v1_rho/len);
		v0_phi 	= 2.0 * Math.atan(v0_rho/len);

		/* This line avoids that the counter of sensor readings increases without
		 * limit. Thus, new segments will have some influence even if obtained
		 * after long runs of the robot in the same environment. 
		 */
		if (count > 100)  count = 100;
		
		return true;
	}

	/* Checks if two segments are very close in order to merge them. This is to avoid
	 * that, when the robot moves for a long time in a given environment, we get small
	 * segments that overlap large ones but that due to their difference in orientation
	 * they are not merged.
	 * Two segments are combined when one of them overlaps the other and the distance
	 * between its extremes and the second segment is shorter than the fuzziness of the
	 * segments.
	 */
	public boolean clean (LPOFSegment s1, LPOFSegment s2)
	{
		boolean		merge;
		double		d, temp, aux1, aux2, aux3;
		double		xi1=0.0, yi1=0.0, xf1=0.0, yf1=0.0, xi2=0.0, yi2=0.0, xf2=0.0, yf2=0.0;
		double		minx, miny, maxx, maxy;
		double		s1_phi, s2_phi, s2_rho;

		/* We have to avoid problems due to: 1) the universe of discourse of
		 * orientations is circular (-180 == 180); 2) two segments with values of
		 * 'ro' close to zero and Math.abs (phi1-phi2)==180 might correspond to the same
		 * object; y 3) the representation of segments in terms of (ro,phi) is
		 * dependent on the location of the origin of coordinates.
		 * We rotate the origin of coordinates before comparing the segments, the
		 * new orientation being the mean of the orientations (solves 1). Case 2 is
		 * considered every time that we operate on the segments. Case 3 is solved
		 * when computing the new value of 'ro'
		 */
		merge = true;

		// Store segments parameters to avoid changing them in the original segments!!
		s1_phi	= s1.phi;
		s2_phi	= s2.phi;
		s2_rho	= s2.rho;
		
		/* Rotation of the origin of coordinates */
		aux1 = Math.abs (s1_phi - s2_phi);
		if ((aux1 > Angles.PI05) && (aux1 < Angles.PI15))					// Case 2
		{
			if (s2_phi < 0.0)  
				s2_phi += Math.PI;
			else 
				s2_phi -= Math.PI;
			s2_rho = -s2_rho;
			aux1 = Math.abs (s1_phi - s2_phi);
		}
		if (aux1 > Angles.PI15)
		{
			if (s1_phi < 0.0)  
				s1_phi += Angles.PI2;
			else 
				s2_phi += Angles.PI2;
		}
		
		count	= s1.count + s2.count;
		phi		= Angles.radnorm_180 ((s1.count*s1_phi + s2.count*s2_phi)/count);
		s1_phi	= Angles.radnorm_180 (s1_phi - phi);
		s2_phi	= Angles.radnorm_180 (s2_phi - phi);

		if (Math.abs (s2_phi - s1_phi) > Angles.PI025) 
			merge = false;
		else
		{
			/* Checks if the segments have intersection. It studies their projection on
			 * the Y axis of the rotated coordinate system.
			 */
			aux2 = Math.cos (phi);
			aux3 = Math.sin (phi);
			xi1 = s1.xi*aux2 + s1.yi*aux3;		
			yi1 = s1.yi*aux2 - s1.xi*aux3;
			xf1 = s1.xf*aux2 + s1.yf*aux3;		
			yf1 = s1.yf*aux2 - s1.xf*aux3;
			xi2 = s2.xi*aux2 + s2.yi*aux3;		
			yi2 = s2.yi*aux2 - s2.xi*aux3;
			xf2 = s2.xf*aux2 + s2.yf*aux3;		
			yf2 = s2.yf*aux2 - s2.xf*aux3;
			if (yi1 > yf1)
			{
				temp = yi1;    yi1 = yf1;    yf1 = temp;
				temp = xi1;    xi1 = xf1;    xf1 = temp;
			}
			if (yi2 > yf2)
			{
				temp = yi2;    yi2 = yf2;    yf2 = temp;
				temp = xi2;    xi2 = xf2;    xf2 = temp;
			}

			/* Two segments are combined when one of them overlaps the other, is "contained"
			 * in the other and the distance between its extremes and the second segment is
			 * shorter than the fuzziness of the segments.
			 */
			if ((yi1>(yi2-LINE_K1) && yf1<(yf2+LINE_K1)) || (yi1>(yi2-LINE_K3) && yf1<(yf2+LINE_K3) &&
					(yf1>(yi2+LINE_K3) || yi1<(yf2-LINE_K3))))
			{
				aux1 = (xf2-xi2)/(yf2-yi2);
				d = Math.abs (xi2+aux1*(yf1-yi2)-xf1);
				aux2 = 0.5*(s1.v0_rho+s2.v0_rho);
				if (d > aux2)			merge = false;
				d = Math.abs (xi2+aux1*(yi1-yi2)-xi1);
				if (d > aux2)			merge = false;
			}
			else if ((yi2>(yi1-LINE_K1) && yf2<(yf1+LINE_K1)) || (yi2>(yi1-LINE_K2) && yf2<(yf1+LINE_K2) &&
					(yf2>(yi1+LINE_K2) || yi2<(yf1-LINE_K2))))
			{
				aux1 = (xf1-xi1)/(yf1-yi1);
				d = Math.abs (xi1+aux1*(yf2-yi1)-xf2);
				aux2 = 0.5*(s1.v0_rho+s2.v0_rho);
				if (d > aux2)			merge = false;
				d = Math.abs (xi1+aux1*(yi2-yi1)-xi2);
				if (d > aux2)			merge = false;
			}
			else
				merge = false;
		}

		if (merge)
		{
			/* Ro of the new segment with respect to the original coordinate system: */
			rho = 0.5*(s1.count*(xi1+xf1) + s2.count*(xi2+xf2))/count;
			if (rho < 0.0)
			{
				rho = -rho;
				if (phi < 0.0)
					phi += Math.PI;
				else 
					phi -= Math.PI;
					
				xi1 = -xi1;    yi1 = -yi1;    xf1 = -xf1;    yf1 = -yf1;
				xi2 = -xi2;    yi2 = -yi2;    xf2 = -xf2;    yf2 = -yf2;

				if (yi1 > yf1)
				{
					temp = yi1;    yi1 = yf1;    yf1 = temp;
					temp = xi1;    xi1 = xf1;    xf1 = temp;
				}
				if (yi2 > yf2)
				{
					temp = yi2;    yi2 = yf2;    yf2 = temp;
					temp = xi2;    xi2 = xf2;    xf2 = temp;
				}
			}

			/* Position of the limits of the new segment. */
			aux2 = Math.cos (phi);
			aux3 = Math.sin (phi);
			miny = Math.min (yi1,yi2); 			
			maxy = Math.max (yf1,yf2);
			minx = maxx = rho;
			xi = minx*aux2 - miny*aux3;		
			yi = miny*aux2 + minx*aux3;
			xf = maxx*aux2 - maxy*aux3;		
			yf = maxy*aux2 + maxx*aux3;
			len = dist (xi,yi,xf,yf);

			/* See 'Combining Coincident Segments' in the documentation. */
			d 		= 0.5*Math.abs (xi1+xf1-xi2-xf2);
			aux3 	= Math.max (0.0, Math.min (s1.v1_rho, s2.v1_rho) - Math.max (0.0, 0.5*(s1.v1_rho+s2.v1_rho)-d));
			v1_rho	= (s1.count*s1.v1_rho+s2.count*s2.v1_rho + Math.min (s1.count,s2.count)*aux3)/count;
			aux3	= Math.max (0.0 , Math.min (s1.v0_rho,s2.v0_rho) - Math.max (0.0, 0.5*(s1.v0_rho+s2.v0_rho)-d));
			v0_rho	= (s1.count*s1.v0_rho+s2.count*s2.v0_rho + Math.min (s1.count,s2.count)*aux3)/count;
			v1_phi	= 2.0 * Math.atan(v1_rho/len);
			v0_phi	= 2.0 * Math.atan(v0_rho/len);

			/* This line avoids that the counter of sensor readings increases without
			 * limit. Thus, new segments will have some influence even if obtained
			 * after long runs of the robot in the same environment.
			 */
			if (count > 100)  count = 100;
		}
		
		return merge;
	}

	public void clamp (Matrix3D rm)
	{
		double		xt, yt;
		
		if (!active)	return;
		
		// Update polar coordinates (just in case)
		x		= rho * Math.cos (phi);
		y		= rho * Math.sin (phi);
		
		super.clamp (rm);
		
		// Initial segment point
		xt		= xi;
		yt		= yi;
		xi		= (rm.mat[0][0] * xt) + (rm.mat[0][1] * yt) + rm.mat[0][2];
		yi		= (rm.mat[1][0] * xt) + (rm.mat[1][1] * yt) + rm.mat[1][2];	
		
		// Final segment point
		xt		= xf;
		yt		= yf;
		xf		= (rm.mat[0][0] * xt) + (rm.mat[0][1] * yt) + rm.mat[0][2];
		yf		= (rm.mat[1][0] * xt) + (rm.mat[1][1] * yt) + rm.mat[1][2];	
    }

	public void draw (Model2D model, LPOView view)
	{
		if (!active)	return;

		//model.addRawRotSegment (xi, yi, xf, yf, v1_rho, view.rotation, color);
		//model.addRawRotSegment (xi, yi, xf, yf, v0_rho, view.rotation, color2);
		
		model.addRawRotSegment (xi, yi, xf, yf, v1_rho, view.rotation, ColorTool.fromWColorToColor(color));
		model.addRawRotSegment (xi, yi, xf, yf, v0_rho, view.rotation, ColorTool.fromWColorToColor(color2));
	}

	public String toString ()
	{
		return "LPOFSegment phi="+phi+", rho="+rho+", v0[phi="+v0_phi+",rho="+v0_rho+"], v1[phi="+v1_phi+",rho="+v1_rho+"]\n"
				+ "         xi="+xi+", yi="+yi+", xf="+xf+",yf="+yf+", len="+len;
	}
}
