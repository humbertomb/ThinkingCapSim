/***************************************************************
 *
 *  LPOFSegments.java
 *
 *	Manages a vector of fuzzy line segments.
 *  =======================================
 *
 *
 * Contains the routines that detect if a sequence of consecutive measurements
 * of the same sensor are collinear, in which case, it approximates them to a
 * line while representing the uncertainty in the knowledge of its real position.
 * 
 * It receives consecutive positions of the robot and the corresponding sensor
 * readings. The objective is to perform a preprocessing/filtering of the data
 * (for each sensor independently) and to group in 'basic segments' those
 * consecutive measurements that are aligned.
 * The points detected by a given sensor are grouped in the same segment as long
 * as the differences in orientation of the lines connecting consecutive readings
 * keep below a certain threshold. This approach allows to group in a segment all
 * those consecutive measurements that are approximately aligned. Since to
 * generate a segment at least four readings are required, the approach
 * eliminates isolated incorrect readings. Furthermore, when a sensor (due to its
 * orientation with respect to the objects) returns low quality readings, it will
 * generate few and short segments having, hence, small influence on the final
 * map. When there is a significant change in the orientation of an object (i.e.,
 * a corner) the orientation of the lines connecting the new sensor readings will
 * be significantly different than the previous orientations, thus generating a
 * new segment that will be aligned with the new orientation of the object.
 * Once a group of points that belong to the same segments has been found, they
 * are approximated by a straight line using the eigenvector line fitting (Duda &
 * Hart, 332). The routine computes the parameters of this line:
 * x*cos(phi) + y*sen(phi) - ro = 0; obtains the projections on it of the first
 * and last points of the segment (that define the limits of the segment), it
 * estimates the uncertainty on the real location of the segment using the
 * dispersion of the observations with respect to a line, the distance between
 * sensor and object, and the uncertainty on the robot position due to the
 * odometry system. Finally, the routine also returns the number of readings that
 * were used to build the segment (the larger the number of readings the larger
 * should be the influence of the segment on the final map).
 *
 *  (c) 1998 Jorge Gasos & Alessandro Saffiotti
 *  (c) 2000 Humberto Martinez
 *  (c) 2002 Humberto Martinez, David Herrero Perez
 *  (c) 2003 Humberto Martinez
 ***************************************************************/

package tclib.navigation.mapbuilding.lpo;

import java.io.*;
//import java.awt.*;

import tc.shared.lps.lpo.*;

import wucore.widgets.*;
import wucore.utils.math.*;
import wucore.utils.math.stat.*;
import wucore.utils.math.jama.*;
import wucore.utils.color.*;

public class LPOFSegments extends LPO implements Serializable
{
	public static final int				MAXDATA			= 362;					/* Maximum consecutive sensor readings in one segment */
	public static final int				MAXGAP			= 10;					/* Maximum outliers inside a segment */

	public static final double			DIF_ANG			= 15.0 * Angles.DTOR;	/* Maximum difference (in absolute value) between the
																				 * orientation of the lines connecting consecutive
																				 * readings that belong to a segment. */
	public static final double			DIF_DST			= 0.350;				/* Maximum distance between two consecutive points in a segment (m) */

	// Parameters for segment creation
	public static final double			MIN_SEG_LENGTH	= 0.300;				/* Minimum length of a segment (m) */
	public static final double			MIN_SEG_SHAPE	= 2.0;					/* Minimum relation between v0_rho and len */
	public static final double			MAX_SEG_PHI		= 30.0 * Angles.DTOR;	/* Maximum value of "phi" for a segment (rad) */
	public static final double			MAX_SEG_RHO		= 0.30;					/* Maximum value of "rho" for a segment (m)*/

	// Parameters for segment fusion
	public static final int				MIN_POINTS		= 5;					/* Minimum number of points in a segment */
	public static final double			MIN_SEG_FLENGTH	= 0.300;				/* Minimum length of a fused segment (m) */
	
	// Segment creation states																 
	public static final int				ST_FIRST		= 1;
	public static final int				ST_SECOND		= 2;
	public static final int				ST_THIRD		= 3;
	public static final int				ST_FOURTH		= 4;
	
	// Values of RIEPFA
	private int n_point_riepfa;
	private double max_dist_riepfa;
	private double max_breakpoint_riepfa;
	
	// Attributes
	protected LPOFSegment[]				segment;
	protected int						numseg;

	// Tempory data
	protected LPOFSegment				seg;
	private double[][]					sg_data;
	
	// Visual representation
	protected WColor				color2;
	
	// Constructors
	public LPOFSegments (int nsegs)
	{
		segment		= new LPOFSegment[nsegs];
		seg			= new LPOFSegment ();
		sg_data		= new double [MAXDATA][2];
		
		color		= WColor.CYAN;
		color2		= WColor.BLUE;
		
		n_point_riepfa			= 6;
		max_dist_riepfa			= 0.3;
		max_breakpoint_riepfa	= 1.5;
		
		reset ();
	}
		
	// Class methods
	static protected double zero (double value)
	{
		if ( (value < 0.0000001) && (value > -0.0000001) )
			return Math.abs (value);
		else		
			return value;
	}	
	
	// Accessors
	public final int			numseg ()							{ return numseg; }
	public final void			numseg (int numseg)					{ this.numseg = numseg; }
	public final LPOFSegment	segment (int i)						{ return segment[i]; }
	public final void			segment (int i, LPOFSegment seg)	{ segment[i] = seg; }
	
	public final void			setColor (WColor color, WColor color2)		{ this.color = color; this.color2 = color2; }
	
	// Accessors to riefa config parameters
	public final int getNPointRiepfa()			{ return n_point_riepfa; }
	public final double getMaxDistRiepfa()		{ return max_dist_riepfa; }
	public final double getMaxBreakPointRiepfa()	{ return max_breakpoint_riepfa; }
	
	public final void setNPointRiepfa(int n_point_riepfa)
	{
		this.n_point_riepfa = n_point_riepfa;
	}
	public final void setMaxDistRiepfa(double max_dist_riepfa)
	{
		this.max_dist_riepfa = max_dist_riepfa;
	}
	public final void setMaxBreakPointRiepfa(double max_breakpoint_riepfa)
	{
		this.max_breakpoint_riepfa = max_breakpoint_riepfa;
	}
	
	// Instance methods
	public void reset ()
	{
		numseg = 0;
	}
		
	public void	add (LPOFSegment fseg)
	{		
		if (numseg >= segment.length)				return;

		if (segment[numseg] == null)	
			segment[numseg] = new LPOFSegment ();

		segment[numseg].set (fseg);
			
		numseg ++;
	} 
	
	public void	at (int i, LPOFSegment fseg)
	{		
		if ((i < 0) || (i >= segment.length))		return;

		if (segment[i] == null)	
			segment[numseg] = new LPOFSegment ();

		segment[i].set (fseg);
	}

	public void group (LPOFSegments other)
	{
		int			i, j, k;
		boolean		grouped;
		
		reset ();
		
		/* Group segments that are similar */
		for (i = 0; i < other.numseg; i++)
		{
			grouped = false;
			
			for (j = (i+1); j < other.numseg; j++)
				if (seg.group (other.segment[i], other.segment[j]))
				{
					grouped = true;
					add (seg);

					for (k = (j+1); k < other.numseg; k++)
						other.segment[k-1].set (other.segment[k]);
					
					other.numseg --;
				}
			
			if (!grouped)
				add (other.segment[i]);
		}
	}

	public void group ()
	{
		int			i, j, k;

		/* Group segments that are similar */
		for (i = 0; i < numseg; i++)
			for (j = (i+1); j < numseg; j++)
			{
				if (seg.group (segment[i], segment[j]))
				{
					segment[i].set (seg);
					
					for (k = (j+1); k < numseg; k++)
						segment[k-1].set (segment[k]);
						
					numseg --;
					i --;
					j = numseg;
				}
			}
	}
	
	public void clean ()
	{
		int			i, j, k;

		/* Merge segments that are very close */
		for (i = 0; i < numseg; i++)
			for (j = (i+1); j < numseg; j++)
			{
				if (seg.clean (segment[i], segment[j]))
				{
					segment[i].set (seg);
					
					for (k = (j+1); k < numseg; k++)
						segment[k-1].set (segment[k]);
						
					numseg --;
					i --;
					j = numseg;
				}
			}
		
		/* Eliminate those segments with a few sensor readings or a very short length. */
		i = 0;
		while (i < numseg)
		{
			if ((segment[i].count () >= MIN_POINTS) && (segment[i].len () >= MIN_SEG_FLENGTH)
					&& (2.0 * segment[i].v0_rho () * MIN_SEG_SHAPE < segment[i].len ()))
				i ++;
			else
			{
				for (j = (i+1); j < numseg; j++)
					segment[j-1].set (segment[j]);
				numseg --;
			}
		}
	}
	
	/* Once a set of consecutive aligned readings has been detected this routine
	 * builds a segment, represents the uncertainty on its real position, and adds
	 * the new segment to the list.
	 */
	protected void fitline (double[][] datos, double cont, double meand, Matrix P)
	{
		int			i;
		double		standx, standy, x2, y2, xy;
		double		aux1, aux2, aux3, aux4, aux5, aux6;
		double		minx, maxx, miny, maxy, meanx, meany;
		double		xi, yi, xf, yf;
		double		k, phi, ro, len, sigma, v0_rho, v1_rho, v1_phi, v0_phi;
		double[]	pointsi = new double[2], pointsf = new double[2];

		double 		meano;
		Matrix		P2 	= new Matrix (2, 2, 1.0);
		Matrix		Gx 	= new Matrix (1, 2);
		Matrix		U 	= new Matrix (1, 1);

		/* Looks for the mean values in X and Y, and the points with minimum and
		 * maximum value in X (limits of the segment)
		 */
		minx = maxx = meanx = datos[0][0];
		miny = maxy = meany = datos[0][1];
		for (i = 1; i < cont; i++)
		{
			if (datos[i][0] < minx)
			{
				minx = datos[i][0];
				miny = datos[i][1];
			}
			else if (datos[i][0] > maxx) 
			{
				maxx = datos[i][0];
				maxy = datos[i][1];
			}
			meanx += datos[i][0];
			meany += datos[i][1];
		}
		meanx /= cont;
		meany /= cont;
		
		/* Given a set of points with zero mean, both in X and Y, the dispersion
		 * matrix 'S' is obtained from the values of sqr(x), sqr(y) and x*y 
		 */
		x2 = 0.0;    
		y2 = 0.0;    
		xy = 0.0;
		for (i = 0; i < cont; i++)
		{
			standx = datos[i][0] - meanx;
			standy = datos[i][1] - meany;
			x2 += standx*standx;
			y2 += standy*standy;
			xy += standx*standy;
		}

		x2 /= cont-1;
		y2 /= cont-1;
		xy /= cont-1;

		aux1 = y2-x2;
		aux2 = x2-y2;
		aux3 = Math.sqrt(aux2*aux2 + 4.*xy*xy);
		k = (2.*xy)/(aux1 + aux3);

		if (Math.abs (k) < 0.1)
		{
			//  Line of the type:  x = meanx
			/* Looks for the points with minimum and maximum values in Y */
			
			miny = maxy = datos[0][1];
			
			for (i = 1; i < cont; i++)
				if (datos[i][1] < miny)
					miny = datos[i][1];
				else if (datos[i][1] > maxy)  
					maxy = datos[i][1];
					
			xi = meanx;    
			yi = miny;
			xf = meanx;    
			yf = maxy;
				
			if (meanx > 0)
				phi = 0.0;
			else  
				phi = Math.PI;
					
			ro = Math.abs (meanx);    
			sigma = Math.sqrt(x2/cont);
		}else if(Math.abs (k) > 10)
		{
			//  Line of the type:  y = meany
			xi = minx;    
			yi = meany;
			xf = maxx;    
			yf = meany;
				
			if (meany > 0)
				phi = Angles.PI05;
			else
				phi = -Angles.PI05;
					
			ro = Math.abs (meany);   
			sigma = Math.sqrt(y2/cont);
		} else
		{
			//  Line of the type:  x*cos(phi) + y*sen(phi) = ro.  See notes.

			aux4 = Math.sqrt(1.+k*k); 
			aux5 = meanx - k * meany;
			phi = Math.atan(-k);
			ro  = aux5/aux4;

			if (ro<0.){
				ro = Math.abs (ro);
				phi = phi - Math.PI;
			}
			phi		= Angles.radnorm_360 (phi);		

			pointsi[0]	= minx;
			pointsi[1]	= miny;
			pointsf[0]	= maxx;
			pointsf[1]	= maxy;
			
			pointsi 	= intersection_point (ro, phi, pointsi);
			pointsf 	= intersection_point (ro, phi, pointsf);

			xi			= pointsi[0];
			yi			= pointsi[1];
			xf			= pointsf[0];
			yf			= pointsf[1];

			/* The dispersion of the points with respect to the line is computed as
			 * the smaller eigenvalue divided by n 
		 	*/
			 
			aux6 = (x2+y2-aux3)/2;
			sigma = Math.sqrt (Math.abs(aux6)/cont);		
		}
		
		phi		= Angles.radnorm_180 (phi);
		
		/* The uncertainty on the real position of the obtained segment depends on
		 * the dispersion, the distance between sensor and object, and the uncertainty
		 * on the robot odometry. 
		 */
		
 		Gx.set (0, 0, zero((-1.) * Math.cos (phi)));
 		Gx.set (0, 1, zero((-1.) * Math.sin (phi)));
 		
		P 		= P.arrayTimes(P2);	
 		U		= Gx.times (P).times (Gx.transpose ());

 		meano 	= Math.sqrt(U.get(0,0));
		
		if (meand > 0.909)
			meand = 0.080;
		else
			meand = 0.088 * meand;	
		
		v0_rho = 2 * StatFunctions.pValue_pt(0.975,cont-1) * sigma + 2 * meand + 2 * meano;
		v1_rho = 2 * StatFunctions.pValue_pt(0.84,cont-1) * sigma + meand + meano;	
			
		/* The uncertainty on the orientation of the obtained segment depends on the
		 * len of the segment and on the uncertainty on the position that was
		 * previously computed.
		 */
		len = LPOFSegment.dist (xi,yi,xf,yf);
		if ((len > MIN_SEG_LENGTH) && (numseg < segment.length))
		{
			v1_phi = Math.atan (2.0 * v1_rho / len);
			v0_phi = Math.atan (2.0 * v0_rho / len);
			
			if ((cont > 5) || ((v1_phi < MAX_SEG_PHI) && (v0_rho < MAX_SEG_RHO)))
			{
				if (segment[numseg] == null)		segment[numseg]	= new LPOFSegment ();
				
				segment[numseg].set (rho, phi, v0_rho, Math.min (20.0 * Angles.DTOR, v0_phi), v1_rho, Math.min (10.0 * Angles.DTOR, v1_phi), (int) cont, len);
				segment[numseg].set_limits (xi, yi, xf, yf);
				numseg ++;
			}
		}
	}

  	protected void fitline (double[][] datos, double cont, Matrix P)
	{
		int			i;
		double		standx, standy, x2, y2, xy;
		double		aux1, aux2, aux3, aux4, aux5, aux6;
		double		minx, maxx, miny, maxy, meanx, meany;
		double		xi, yi, xf, yf;
		double		k, phi, ro, len, sigma, v0_rho, v1_rho, v1_phi, v0_phi;
		double[]	pointsi = new double[2], pointsf = new double[2];	
		
//		double 		meano;
		Matrix		P2 	= new Matrix (2, 2, 1.0);
		Matrix		Gx 	= new Matrix (1, 2);
//		Matrix		U 	= new Matrix (1, 1);

		/* Looks for the mean values in X and Y, and the points with minimum and
		 * maximum value in X (limits of the segment)
		 */
		minx = maxx = meanx = datos[0][0];
		miny = maxy = meany = datos[0][1];
		for (i = 1; i < cont; i++)
		{
			if (datos[i][0] < minx)
			{
				minx = datos[i][0];
				miny = datos[i][1];
			}
			else if (datos[i][0] > maxx) 
			{
				maxx = datos[i][0];
				maxy = datos[i][1];
			}
			meanx += datos[i][0];
			meany += datos[i][1];
		}
		meanx /= cont;
		meany /= cont;
		
		/* Given a set of points with zero mean, both in X and Y, the dispersion
		 * matrix 'S' is obtained from the values of sqr(x), sqr(y) and x*y 
		 */
		x2 = 0.0;    
		y2 = 0.0;    
		xy = 0.0;
		for (i = 0; i < cont; i++)
		{
			standx = datos[i][0] - meanx;
			standy = datos[i][1] - meany;
			x2 += standx*standx;
			y2 += standy*standy;
			xy += standx*standy;
		}
		
		x2 /= cont-1;
		y2 /= cont-1;
		xy /= cont-1;

		aux1 = y2-x2;
		aux2 = x2-y2;
		aux3 = Math.sqrt(aux2*aux2 + 4.*xy*xy);
		k = (2.*xy)/(aux1 + aux3);

		if (Math.abs (k) < 0.1)
		{
			//  Line of the type:  x = meanx
			/* Looks for the points with minimum and maximum values in Y */
			
			miny = maxy = datos[0][1];
			
			for (i = 1; i < cont; i++)
				if (datos[i][1] < miny)
					miny = datos[i][1];
				else if (datos[i][1] > maxy)  
					maxy = datos[i][1];
					
			xi = meanx;    
			yi = miny;
			xf = meanx;    
			yf = maxy;
				
			if (meanx > 0)
				phi = 0.0;
			else  
				phi = Math.PI;
					
			ro = Math.abs (meanx);    
			sigma = Math.sqrt(x2/cont);
		}else if(Math.abs (k) > 10)
		{
			//  Line of the type:  y = meany
			xi = minx;    
			yi = meany;
			xf = maxx;    
			yf = meany;
				
			if (meany > 0)
				phi = Angles.PI05;
			else
				phi = -Angles.PI05;
					
			ro = Math.abs (meany);   
			sigma = Math.sqrt(y2/cont);
		} else
		{
			//  Line of the type:  x*cos(phi) + y*sen(phi) = ro.  See notes.

			aux4 = Math.sqrt(1.+k*k); 
			aux5 = meanx - k * meany;
			phi = Math.atan(-k);
			ro  = aux5/aux4;

			if (ro<0.){
				ro = Math.abs (ro);
				phi = phi - Math.PI;
			}
			phi		= Angles.radnorm_360 (phi);		
//System.out.println(" ro "+ro+" phi "+phi);			
			pointsi[0]	= minx;
			pointsi[1]	= miny;
			pointsf[0]	= maxx;
			pointsf[1]	= maxy;
			
			pointsi 	= intersection_point (ro, phi, pointsi);
			pointsf 	= intersection_point (ro, phi, pointsf);

			xi			= pointsi[0];
			yi			= pointsi[1];
			xf			= pointsf[0];
			yf			= pointsf[1];

			/* The dispersion of the points with respect to the line is computed as
			 * the smaller eigenvalue divided by n 
		 	*/
			 
			aux6 = (x2+y2-aux3)/2;
			sigma = Math.sqrt (Math.abs(aux6)/cont);		
		}
		
		phi		= Angles.radnorm_180 (phi);
		
		/* The uncertainty on the real position of the obtained segment depends on
		 * the dispersion and the uncertainty on the robot odometry. 
		 */
 
 		Gx.set (0, 0, zero((-1.) * Math.cos (phi)));
 		Gx.set (0, 1, zero((-1.) * Math.sin (phi)));
 		
 		
 		P = P.arrayTimes(P2);
 //		U		= Gx.times (P).times (Gx.transpose ());

 //		meano 	= Math.sqrt(U.get(0,0));
 		
 		/*
		v0_rho 	= 2 * StatFunctions.pValue_pt(0.975,cont-1) * sigma + 2 * meano;
		v1_rho 	= 2 * StatFunctions.pValue_pt(0.84,cont-1) * sigma + meano;
		*/
 		
 		v0_rho 	= 2 * StatFunctions.pValue_pt(0.975,cont-1) * sigma;
		v1_rho 	= 2 * StatFunctions.pValue_pt(0.84,cont-1) * sigma;
 		
		/* The uncertainty on the orientation of the obtained segment depends on the
		 * len of the segment and on the uncertainty on the position that was
		 * previously computed. 
		 */
		 
		len = LPOFSegment.dist (xi,yi,xf,yf);

		if ((len > MIN_SEG_LENGTH) && (numseg < segment.length))
		{
			v1_phi = Math.atan (2.0 * v1_rho / len);
			v0_phi = Math.atan (2.0 * v0_rho / len);		
			
			if (segment[numseg] == null)		segment[numseg]	= new LPOFSegment ();
				
				segment[numseg].set (ro, phi, v0_rho, v0_phi, v1_rho, v1_phi, (int) cont, len);
				segment[numseg].set_limits (xi, yi, xf, yf);
			numseg ++;
		}
	}
	
	/* Receives a sensor signature of the full sensor set and checks them
	 * trying to find groups of at least four consecutive readings that are
	 * aligned. Whenever it happens, it calls the routine 'fitline()' to build
	 * a new segment and adds it to the temporary map.
	 */
	 
	 /* WARNING: the following statement should be checked and verified
	 
					sg_inid		+= datos.d[i].rho ();
					
		initially it was:
		
					sg_inid		+= datos.d[i].len ();
	*/
	public void build_segments (LPOSensorSignat datos, Matrix P)
	{
		int			i;
		int			sg_k = 0;
		int			sg_next = 0;
		int			sg_state;
		int			sg_cont;
		double		sg_ang1=0.0, sg_ang2=0.0, sg_ang3=0.0;
		double		aux1, dist;
		double		sg_inid = 0.0;							// Sensor uncertainty estimation
		
		sg_cont = 3;      
		sg_state = ST_FIRST;
		for (i = 0; i < datos.n (); i++)
			switch (sg_state)
			{
			case ST_FIRST:				
				// ***				
				// *** First point of the segment
				// ***				
				sg_data[0][0] = datos.d[i].x ();
				sg_data[0][1] = datos.d[i].y ();
				
				/* Set up initial values */
				sg_inid 	= datos.d[i].rho ();
				sg_cont 	= 3;
				sg_k 		= 0;
				sg_next 	= i + 1;
				sg_state	= ST_SECOND;
				break;

			case ST_SECOND:								
				// ***				
				// *** Second point of the segment
				// ***				
				sg_data[1][0] = datos.d[i].x ();
				sg_data[1][1] = datos.d[i].y ();
				
				/* Distance to the previous point */
				dist = Math.sqrt ((sg_data[1][0]-sg_data[0][0]) * (sg_data[1][0]-sg_data[0][0]) + (sg_data[1][1]-sg_data[0][1]) * (sg_data[1][1]-sg_data[0][1]));

				/* Orientation of the line connecting both points */
				if (sg_data[1][0] == sg_data[0][0])
					if ((sg_data[1][1]-sg_data[0][1]) > 0.0)  
						sg_ang1 = Angles.PI05;
					else  
						sg_ang1 = -Angles.PI05;
				else  
					sg_ang1 = Math.atan ((sg_data[1][1]-sg_data[0][1])/(sg_data[1][0]-sg_data[0][0]));
				
				if (dist > DIF_DST) 
				{
					sg_k ++;
					if (sg_k > MAXGAP)
					{
						i = sg_next;
						sg_state = ST_FIRST;
					}
				}
				else
				{
					sg_inid		+= datos.d[i].rho ();
					sg_state	= ST_THIRD;
				}
				break;

			case ST_THIRD:								
				// ***				
				// *** Third point of the segment
				// ***				
				sg_data[2][0] = datos.d[i].x ();
				sg_data[2][1] = datos.d[i].y ();

				/* Distance to the previous point */
				dist = Math.sqrt ((sg_data[2][0]-sg_data[1][0]) * (sg_data[2][0]-sg_data[1][0]) + (sg_data[2][1]-sg_data[1][1]) * (sg_data[2][1]-sg_data[1][1]));

				/* Orientation of the line connecting both points */
				if (sg_data[2][0] == sg_data[1][0])
					if ((sg_data[2][1]-sg_data[1][1]) > 0.0)  
						sg_ang2 = Angles.PI05;
					else  
						sg_ang2 = -Angles.PI05;
				else  
					sg_ang2 = Math.atan ((sg_data[2][1]-sg_data[1][1])/(sg_data[2][0]-sg_data[1][0]));
					
				/* If the angle between sensor and surface is not almost perpendicular,
				 * or the angle between the lines connecting consecutive readings is
				 * not approximately zero they do not belong to the same segment.
				 */
				if (Math.abs (Angles.radnorm_90(sg_ang1-sg_ang2))>DIF_ANG || dist > DIF_DST)
				{
					sg_k ++;
					if (sg_k > MAXGAP)
					{
						i = sg_next;
						sg_state = ST_FIRST;
					}
				}
				else
				{
					sg_inid		+= datos.d[i].rho ();
					sg_state	= ST_FOURTH;
				}
				break;

			case ST_FOURTH:								
				// ***				
				// *** Fourth point and the rest
				// ***				
				sg_data[sg_cont][0] = datos.d[i].x ();
				sg_data[sg_cont][1] = datos.d[i].y ();

				/* Distance to the previous point */
				dist = Math.sqrt ((sg_data[sg_cont][0]-sg_data[sg_cont-1][0]) * (sg_data[sg_cont][0]-sg_data[sg_cont-1][0]) + (sg_data[sg_cont][1]-sg_data[sg_cont-1][1]) * (sg_data[sg_cont][1]-sg_data[sg_cont-1][1]));

				/* Orientation of the line connecting both points */
				if (sg_data[sg_cont][0] == sg_data[sg_cont-1][0])
					if ((sg_data[sg_cont][1]-sg_data[sg_cont-1][1]) > 0.0)  
						sg_ang3 = Angles.PI05;
					else  
						sg_ang3 = -Angles.PI05;
				else  
					sg_ang3 = Math.atan ((sg_data[sg_cont][1]-sg_data[sg_cont-1][1])/(sg_data[sg_cont][0]-sg_data[sg_cont-1][0]));

				/* If the angle between sensor and surface is not almost perpendicular,
				 * or the angle between the lines connecting consecutive readings is
				 * not approximately zero they do not belong to the same segment.
				 */
				if (Math.abs (Angles.radnorm_90(sg_ang1-sg_ang3))>DIF_ANG ||
							Math.abs (Angles.radnorm_90(sg_ang2-sg_ang3))>DIF_ANG || dist > DIF_DST)
				{
					sg_k ++;
					if (sg_k > MAXGAP)
					{
						if (sg_cont > 3)  /* We have enough points to build the segment */
							fitline (sg_data, (double) sg_cont, sg_inid / (double) sg_cont, P);

						i = sg_next;
						sg_state = ST_FIRST;
					}
				}
				else 
				{
					/* The new reading belongs to the segment. */
					if (sg_cont == 3) 
					{
						aux1 = Math.min (sg_ang1, Math.min (sg_ang2, sg_ang3));
						sg_ang2 = Math.max (sg_ang1, Math.max (sg_ang2, sg_ang3));
						sg_ang1 = aux1;
					}
					else 
					{
						sg_ang1 = Math.min (sg_ang1, sg_ang3);
						sg_ang2 = Math.max (sg_ang2, sg_ang3);
					}
					sg_cont ++;
					sg_inid		+= datos.d[i].rho ();
					
					if (sg_cont >= MAXDATA)
					{
						/* We reached the maximum number of points that can be used to build
						 * a segment. This is very likely not to happen. */
						fitline (sg_data, (double) sg_cont, sg_inid / (double) sg_cont, P);

						sg_state = ST_FIRST;
					}
				}
				break;
			} 
			
		/* When there are no more sensor readings we check if the last ones can
		 * generate a segment. */
		if (sg_cont > 3)
			fitline (sg_data, (double) sg_cont, sg_inid / (double) sg_cont, P);
	}	

	/* Recursive Iterative End Point Fit Algorithm.
	 *
	 * Searchs for aligned points in the scanned data
	 */	
	public void build_segments_RIEPFA (LPOSensorSignat datos_LRF, Matrix P)
	{
		int		ini = 0, finals = datos_LRF.n () - 1, fin = finals;
	
		while( (finals-ini) > n_point_riepfa){
			fin 			= segments_LRF_RIEPFA_JUMP (ini, finals, datos_LRF);
			segments_LRF_RIEPFA_MET(ini, fin, datos_LRF, P);		
			ini 			= fin+1;
			fin 			= finals;			
		}	
	}
	
	// Split and Merge Algorithm
	public void build_segments_SAM (LPOSensorSignat datos_LRF, Matrix P, int[] initp, int[] endp, int num_boundaries)
	{
//		for(int j = 0; j < num_boundaries; j++)
//			System.out.println("Bound " + j + " <" + initp[j] + "," + endp[j] + ">");
//		System.out.println("");
		
		int bound_index;
		int init, end;
		int binit_index, bend_index;
		
		double fardistance;
		double[] test_fit;
		
		bound_index = 0;
		
		init = initp[bound_index];
		end = endp[bound_index];
		
		binit_index = bound_index;
		bend_index = bound_index;
		
		while(bound_index < num_boundaries)
		{
			bound_index++;
			
			// Test fit
			test_fit = segments_LRF_RIEPFA_TEST(datos_LRF, init, end);
			fardistance = test_fit[0];
			
			// Test Max Jump
			if(
				segments_LRF_Test_JUMP(init, end, datos_LRF) &&
				(fardistance < max_dist_riepfa)
			){
				// Try merge next set
				end = endp[bound_index];
				bend_index = bound_index;
			} else {
				if(binit_index != bend_index)
					segment_LRF_try_fit(initp[binit_index], endp[bend_index-1], datos_LRF, P);
				
				init = initp[bound_index];
				end = endp[bound_index];
				
				binit_index = bound_index;
				bend_index = bound_index;
			}
		}
	}
	
/* Devuelve el punto final a separar los conjuntos*/
	
	public int segments_LRF_RIEPFA_JUMP (int ini, int fin, LPOSensorSignat datos_LRF){
		int 		i;
		double 		aux, MAXJUMP = 0.0;
	
		for (i = ini + 1; i <= fin; i++){
 			aux			= LPOFSegment.dist(datos_LRF.d[i].x (),datos_LRF.d[i].y (),datos_LRF.d[i-1].x (), datos_LRF.d[i-1].y ());
			MAXJUMP		= Math.max(MAXJUMP,aux);
			if (MAXJUMP > max_breakpoint_riepfa)	
				break;			
		}	
			
		if (i == fin)
			return i;
		else
			return i - 1;	
	}
	
	public boolean segments_LRF_Test_JUMP (int ini, int fin, LPOSensorSignat datos_LRF)
	{
		int i;
		double dist, max_distance;
		
		max_distance = 0.0;
		
		for (i = ini; i < fin; i++)
		{
			dist			= LPOFSegment.dist(datos_LRF.d[i+1].x(), datos_LRF.d[i+1].y(), datos_LRF.d[i].x(), datos_LRF.d[i].y());
			max_distance	= Math.max(max_distance, dist);
			
			if (max_distance > max_breakpoint_riepfa)
				return false;
		}
		
		return true;
	}
	
	public void segments_LRF_RIEPFA_MET (int ini, int fin, LPOSensorSignat datos_LRF, Matrix P){
		int 		y, z;
		int 		finals 			= fin;
		double[]	test 			= new double[2];	
		int			farpoint;						
		double		fardistance;					
				
		while( (finals-ini) > n_point_riepfa){	
			if( (fin-ini) > n_point_riepfa){
				test 			= segments_LRF_RIEPFA_TEST (datos_LRF, ini, fin);

				fardistance  	= test[0];											// Distancia que se aleja
				farpoint 		= Double.valueOf (test[1]).intValue();					// Punto mas alejado

				if(fardistance < max_dist_riepfa){
				
					y=0;
									
					for(z = ini; z <= fin; z++){
						
						sg_data[y][0] 	= datos_LRF.d[z].x ();
						sg_data[y][1] 	= datos_LRF.d[z].y ();
 						 												
						y++;
					}
							
					y--;
					fitline (sg_data, y, P);

					ini = fin+1;
					fin = finals;
					
				} else
					fin = farpoint;
			} else{
				ini = fin+1;
				fin = finals;			
			}
		}
	}
	
	public void segment_LRF_try_fit(int ini, int fin, LPOSensorSignat datos_LRF,  Matrix P)
	{
		int y, z;
		
		if((fin-ini) > n_point_riepfa)
		{
			y=0;
			
			for(z = ini; z <= fin; z++)
			{
				sg_data[y][0] 	= datos_LRF.d[z].x ();
				sg_data[y][1] 	= datos_LRF.d[z].y ();
				
				y++;
			}
			y--;
			
			fitline (sg_data, y, P);
		}
	}
	
	public double[] segments_LRF_RIEPFA_TEST (LPOSensorSignat datos_LRF, int ini, int fin){
	
		int			i, MMAX=0; 
		double		ro, phi, rop, phip;
		double		X1,X2,Y1,Y2,X3,Y3,Xint,Yint;
		double 		dis, MAX = 0.0;	
		double[]	test = new double[2];
		double[][] 	a = new double[2][2], b = new double[2][1]; 

		Matrix		A, B, X;

		test[0] = 0.0;			// Distancia que se aleja
		test[1] = 0;			// Punto mas alejado

		X1		=	datos_LRF.d[ini].x ();
		Y1		=	datos_LRF.d[ini].y ();
		X2		=	datos_LRF.d[fin].x ();
		Y2		=	datos_LRF.d[fin].y ();
							
		phi		=	Math.atan((X2-X1)/(Y1-Y2));
		
		phi 	=	Angles.radnorm_360 (phi);

		if((X1 != 0.0) || (Y1 != 0.0))
			ro	=	X1 * Math.cos(phi) + Y1 * Math.sin(phi);
		else
			ro	=	X2 * Math.cos(phi) + Y2 * Math.sin(phi);

		if (ro<0.){
			ro 		= Math.abs (ro);
			phi 	= Angles.radnorm_360 (phi - Math.PI);
		}

		for (i = ini+1; i < fin-1; i++){
			X3 		= datos_LRF.d[i].x ();
			Y3 		= datos_LRF.d[i].y ();
			
			phip		=	Angles.radnorm_360 (phi + .5 * Math.PI);
			rop			=	X3 * Math.cos(phip) + Y3 * Math.sin(phip);
			
			if (rop<0.){
				rop 	= Math.abs (rop);
				phip 	= Angles.radnorm_360(phip - Math.PI);
			}
			
			a[0][0] = Math.cos(phip);
			a[0][1] = Math.sin(phip);	
			a[1][0] = Math.cos(phi);	
			a[1][1] = Math.sin(phi);
			b[0][0]	= rop;				
			b[1][0]	= ro;

			A 		= new Matrix(a);
			B		= new Matrix(b);
			X		= A.solve(B);
		
			Xint	= X.get(0,0);
			Yint	= X.get(1,0);
			dis		= LPOFSegment.dist(X3,Y3,Xint,Yint);
				
			if (dis>MAX){
				MAX 	= dis;
				MMAX 	= i;
			}
		}			

		test[0] = MAX;							// MAX
		test[1] = MMAX;							// MMAX
		
		return test;
	}

	public double[] intersection_point (double ro, double phi, double[] points){

		double		phip, rop;
		double[]	intpoints 	= new double[2];
		double[][] 	a			= new double[2][2], b = new double[2][1]; 

		Matrix		A, B, X;
		
		phip		=	Angles.radnorm_360 (phi + .5 * Math.PI);
		
		rop			=	points[0] * Math.cos(phip) + points[1] * Math.sin(phip);
		
		if (rop<0.){
			rop 	= Math.abs (rop);
			phip 	= Angles.radnorm_360 ( phip - Math.PI );
		}			

		a[0][0] = Math.cos(phip);
		a[0][1] = Math.sin(phip);	
		a[1][0] = Math.cos(phi);	
		a[1][1] = Math.sin(phi);
		b[0][0]	= rop;				
		b[1][0]	= ro;

		A 		= new Matrix(a);
		B		= new Matrix(b);
		X		= A.solve(B);
		
		intpoints[0]	= X.get(0,0);
		intpoints[1]	= X.get(1,0);	
		
		return intpoints;
	}

	public void clamp (Matrix3D rm)
	{
		int				i;
		
		for (i = 0; i < numseg; i++)
			segment[i].clamp (rm);
	}
	
	public void draw (Model2D model, LPOView view)
	{
		int				i;
		
		for (i = 0; i < numseg; i++)
		{
			segment[i].setColor (color, color2);
			segment[i].draw (model, view);
		}
	}
}