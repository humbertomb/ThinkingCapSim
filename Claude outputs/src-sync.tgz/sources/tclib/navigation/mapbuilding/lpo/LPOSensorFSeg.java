/*
 * (c) 2002 Humberto Martinez, David Herrero
 * (c) 2003 Humberto Martinez
 */
 
package tclib.navigation.mapbuilding.lpo;

import java.io.*;
//import java.awt.*;

import tc.vrobot.*;
import tc.shared.lps.lpo.*;
import wucore.utils.math.jama.*;

import wucore.widgets.*;
import wucore.utils.math.*;
import wucore.utils.color.*;

public class LPOSensorFSeg  extends LPO implements Serializable
{	
	static public final int				MAX_SEGS		= 25;			// Maximum number of segments per view

	// Segments generation mode
	static public final int				M_HEURISTIC		= 0;			// Generate segments using a simple heuristic method	
	static public final int				M_RIEFPA		= 1;			// Generate segments using the RIEFPA method	
	
	protected int						mode			= M_RIEFPA;

	// Fuzzy segments
	protected LPOFSegments				inview			= null;			// Curent in-view fuzzy segments (fused map)
	protected LPOFSegments				inviewSON		= null;			// Curent in-view fuzzy segments (sonar generated)
	protected LPOFSegments				inviewLRF		= null;			// Curent in-view fuzzy segments (laser generated)

	// Temporal sensor buffer for segment generation
	protected LPOSensorSignat			dataSON;	
	protected LPOSensorSignat 			dataLRF;
	
	// Debugging options
	private boolean						debug			= false;

	// Constructor
	public LPOSensorFSeg (int max_sonar, int max_laser, String label, int source)
	{			
		super (0.0, 0.0, 0.0, label, source);

		// Generate inview fuzzy segments
		inview			= new LPOFSegments (MAX_SEGS * 2);
		inviewSON		= new LPOFSegments (MAX_SEGS);
		inviewLRF		= new LPOFSegments (MAX_SEGS);

		// Initialise temporal sensor buffer
		dataSON			= new LPOSensorSignat (max_sonar);
		dataLRF			= new LPOSensorSignat (max_laser);		
	}
	
	// Accessors
	public final LPOFSegments		segs ()									{ return inview; }
	public final LPOFSegments		segsSON ()								{ return inviewSON; }
	public final LPOFSegments		segsLRF ()								{ return inviewLRF; }
	
	public final LPOSensorSignat	dataSON ()								{ return dataSON; }
	public final LPOSensorSignat	dataLRF ()								{ return dataLRF; }

	public void						reset_inview ()							{ inview.reset (); }	
	public void						update_inview (LPOFSegments segs)		{ inview	= segs; }
	public void						reset_inviewSON ()						{ inviewSON.reset (); }
	public void						update_inviewSON (LPOFSegments segs)	{ inviewSON	= segs; }
	public void						reset_inviewLRF ()						{ inviewLRF.reset (); }
	public void						update_inviewLRF (LPOFSegments segs)	{ inviewLRF	= segs; }
	
	// Instance methods	
	public void merge_inviews ()
	{
		int			i;
		
		// Reset current inview map
		reset_inview ();
		
		// Update inview with sonar generated segments
		for (i = 0; i < inviewSON.numseg (); i++)
			inview.add (inviewSON.segment (i));		
		
		// Update inview with laser generated segments
		for (i = 0; i < inviewLRF.numseg (); i++)
			inview.add (inviewLRF.segment (i));		
			
		// Merge and clean the detected segemnts
//		inview.group ();
//		inview.clean ();
// System.out.println ("\nPerceived segments SON: "+ inviewSON.numseg () + "   LRF: "+ inviewLRF.numseg () + " => Fused segments: " + inview.numseg ());
	}
	
	public void do_segments (LPOSensorScanner scan, Matrix P)
	{
		int			i;
		double		xx, yy;
		double		a, da;
		SensorPos	s;
			   				   						
		dataLRF.n (scan.size ());
		
		dataLRF.locate (0.0, 0.0, 0.0);
		dataLRF.active (true);
		
		s				= scan.senpos ();
		da				= scan.cone () / (dataLRF.n () - 1);
		
		for (i = 0, a = -scan.cone () * 0.5; i < dataLRF.n (); i++, a += da)
		{																											
			xx	= s.x () + scan.range[i] * Math.cos ((s.orientation () + a));
			yy	= s.y () + scan.range[i] * Math.sin ((s.orientation () + a));
		
			dataLRF.d[i].locate (xx, yy, 0.0, scan.range[i]);
		}

		/* Builds the segments from the sensor data and appends them to the list */
		switch (mode)
		{
		case M_RIEFPA:
			inviewLRF.build_segments_RIEPFA (dataLRF, P);
			break;
		case M_HEURISTIC:
		default:
			inviewLRF.build_segments (dataLRF, P);
		}
	}
		
	public void do_segments (LPORangeBuffer rbuffer, Matrix P)
	{
		int				n;
		int				i;
		LPORangePoint	point;
 

		dataSON.locate (0.0, 0.0, 0.0);
		dataSON.active (true);

		dataSON.n (rbuffer.ndx_n ());
		for (i = 0, n = 0; i < rbuffer.ndx_n (); i++)
		{
			point 	= rbuffer.buffer (i);

			if (point.sensor () == LPORangePoint.SONAR)		
			{	
				dataSON.d[n].locate (point.x (), point.y (), 0.0, point.len ());
				n ++;
			}
		}
		dataSON.n (n);
		
		/* Builds the segments from the sensor data and appends them to the list */
		inviewSON.build_segments (dataSON, P);
	}

	public void clamp (Matrix3D rm)
	{
		if (!active)	return;

		inview.clamp (rm);
		inviewSON.clamp (rm);
		inviewLRF.clamp (rm);
		
		dataSON.clamp (rm);
		dataLRF.clamp (rm);
	}
	
	public void draw (Model2D model, LPOView view)
	{
		if (!active)	return;

		inviewSON.setColor (WColor.GREEN, WColor.GREEN.darker());
		inviewLRF.setColor (WColor.ORANGE, WColor.ORANGE.darker());
		
//		inviewSON.draw (model, view);
		inviewLRF.draw (model, view);
		inview.draw (model, view);

		if (debug)
		{
			dataSON.draw (model, view);
			dataLRF.draw (model, view);
		}
	}		
}