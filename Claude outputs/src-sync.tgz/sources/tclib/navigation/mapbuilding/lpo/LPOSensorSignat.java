/*
 * (c) 2000 Humberto Martinez
 * (c) 2003 Humberto Martinez
 */

package tclib.navigation.mapbuilding.lpo;

import java.io.*;

import tc.shared.lps.lpo.*;

import wucore.widgets.*;
import wucore.utils.math.*;

public class LPOSensorSignat extends LPO implements Serializable
{
	public LPORangeSignat[]				d;   	// Scanned measures (phi-ordered)
	private int							n;		// Number of stored signature points
	
	// Constructors
	public LPOSensorSignat (int max)
	{
		create (max);

		n	= 0;
	}
	
	// Accessors
	public final void		n (int n)		{ this.n = n; if (d.length < n) create (n); }
	public final int			n ()				{ return n; }

	// Instance methods
	protected void create (int max)
	{
		int			i;
		
		d	= new LPORangeSignat[max];
		
		for (i = 0; i < max; i++)
			d[i]	= new LPORangeSignat (null, LPO.PERCEPT);
	}
	
	public void clamp (Matrix3D rm)
	{
		int				i;
		
		if (!active)	return;

		for (i = 0; i < n; i++)
			d[i].clamp (rm);
	}
	
	public void draw (Model2D model, LPOView view)
	{
		int			i;
		
		if (!active)	return;

		for (i = 0; i < n; i++)
			d[i].draw (model, view);
	}
}
