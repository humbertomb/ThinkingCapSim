/***************************************************************
 *
 *  FSegMap.java
 *
 *
 * Contains the programs to build a map of the environment of the robot
 * from the readings provided by the range sensors (virtual).
 *
 *
 *  (c) 1998 Jorge Gasos & Alessandro Saffiotti
 *  (c) 2000-2001 Humberto Martinez
 ***************************************************************/

package tclib.navigation.mapbuilding;

import tclib.navigation.mapbuilding.lpo.*;

import devices.pos.*;

public class FSegMap extends Object
{	
	static public final int				MAX_INVIEW		= 100;			// Maximum number of segments per inview set
	static public final int				MAX_SEGS		= 500;			// Maximum number of segments per map
	static public final int				MAX_CELLS		= 30;			// Maximum number of cell rows/columns per map
	
	// Current Fuzzy Segments sub-maps
	protected FSegSet					local			= null;			// Local fuzzy segments map
	protected FSegSet					global			= null;			// Global fuzzy segments map
	
	// Current perceived fuzzy segments
	protected LPOFSegments				inview			= null;			// Curent in-view fuzzy segments

	// Constructor
	public FSegMap ()
	{			
		// Generate inview, local and global maps
		inview			= new LPOFSegments (MAX_INVIEW);
		local			= new FSegSet (MAX_SEGS, MAX_CELLS);
		global			= new FSegSet (MAX_SEGS, MAX_CELLS);
	}
	
	// Accessors
	public final FSegSet			local ()			{ return local; }
	public final FSegSet			global ()			{ return global; }
	
	public final LPOFSegments		segs ()				{ return inview; }

	// Instance methods
	
	/* These two methods are intended to be used when localization is not needed,
	 * like when making comparisons or generation tests. They just add the current
	 * inview map to the local or global one, respectively.
	 */
	public void update_local_map ()
	{
		local.merge_segments (inview);
		local.clean_map ();
		inview.reset ();
	}

	public void update_global_map ()
	{
		global.merge_segments (inview);
		global.clean_map ();
		inview.reset ();
	}
	
	public void update_inview (LPOFSegments other, Position pos)
	{		
		int			i;
		
		inview.reset ();		// Is it really necessary?
		
		for (i = 0; i < other.numseg (); i++)
		{
			inview.add (other.segment (i));
			inview.segment (i).set_origin (pos);
		}
	}
	
	public void update_maps (Position pos)
	{		
		global.prev_loc = global.act_loc;
		global.check_self_localization (pos.x (), pos.y ());
		
		if (!global.prev_loc && !global.act_loc)
		{
			/* Not mapped area. Adds the local map to the global map, and the inview
			 * map becomes the local map */
    		global.merge_maps (local);
   			global.clean_map ();
			local.reset_map ();
			local.merge_segments (inview);
		}
		else if (!global.act_loc)
		{
			/* Returns to a not mapped area. Adds the inview map to the local map,
			 * self-localizes and merges the local and global maps. */
			local.merge_segments (inview);
			global.merge_maps (local);
			global.clean_map ();
			local.reset_map ();
		}
		else if (!global.prev_loc)
		{
			/* Arrives to a mapped area. Adds the inview map to the local map */
			local.merge_segments (inview);
		}
		else
		{
			/* In an already mapped area. Adds the inview map to the local map
			 * and self-localizes */
			local.merge_segments (inview);
			global.merge_maps (local);
			global.clean_map ();
			local.reset_map ();
		}
		inview.reset ();
	}
}