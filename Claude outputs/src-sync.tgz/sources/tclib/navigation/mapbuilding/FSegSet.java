/***************************************************************
 *
 *  FSegSet.java
 *
 *	Builds and maintains a segs composed of fuzzy line segments.
 *
 *  (c) 1998 Jorge Gasos & Alessandro Saffiotti
 *  (c) 2000 Humberto Martinez
 *  (c) 2003 Humberto Martinez
 ***************************************************************/

package tclib.navigation.mapbuilding;

import tclib.navigation.mapbuilding.lpo.*;

public class FSegSet extends Object
{
	// Fuzzy Segments
	public LPOFSegments					segs;					/* segs of the sector */
	
	// Binary occupancy grid
	public boolean[][]					grid		= null;		/* grid for visited (mapped) areas */
	public int							gsize;					/* grid size: larger than abs(max(x,y)) */
	
	// State information
	public boolean						act_loc;				/* the robot is in (comes from) a mapped area */
	public boolean						prev_loc;		
	public int							xcell_old;				/* the cell the robot comes from */
	public int							ycell_old;
	
	// Constructors
	
	/* Creates and allocates memory for a new sector segs (returns the segs structure).
	 * Receives the maximum number of segments in the segs, the maximum possible
	 * distance (in meters and measured on the X and Y axis) between a point of the
	 * sector and the origin of coordinates for that sector, and a flag indicating if
	 * we should keep track of the trajectory of the robot in the sector.
	 */
	public FSegSet (int max_segs, int gsize)
	{
		this.gsize	= gsize;

		segs		= new LPOFSegments (max_segs);
		
		if (gsize > 0)
			grid	= new boolean[2 * gsize][2 * gsize];
					
		reset_map ();
	}
	
	public FSegSet (LPOFSegments segs)
	{
		this.segs		= segs;
		
		this.gsize	= 0;
		this.grid		= null;
	}
	
	// Accessors
	public final LPOFSegments		segs ()			{ return segs; }
	public final boolean[][]		grid ()			{ return grid; }
	public final int				grid_n ()		{ return gsize; }
		
	// Instance methods

	/* Deletes all the information contained in a sector segs */
	public void reset_map ()
	{
		set_grid (false);
		segs.reset ();
						
		act_loc			= false;
		prev_loc		= false;
		xcell_old		= -1;
		ycell_old		= -1;		
	}

	/* To set all the grid cells in a sector segs to a given value */
	protected void set_grid (boolean val)
	{
		int			i, j;
		
		if (gsize > 0)
		{
			for (i = 0; i < 2 * gsize; i++)
				for (j = 0; j < 2 * gsize; j++)
					grid[i][j] = val;
		}
	}
	
	public void merge_segments (LPOFSegments other)
	{
		int				i;
		LPOFSegments	segtemp;

		segtemp = new LPOFSegments (segs.numseg () + other.numseg ());
		
		/* Writes both maps in the data structure 'segtemp[]' */
		for (i = 0; i < segs.numseg (); i++)
			segtemp.add (segs.segment (i));
			
		for (i = 0; i < other.numseg (); i++)
			segtemp.add (other.segment (i));
  		
		/* Combines the maps */
		segs.group (segtemp);
	}

	/* This routine combines the segments of two maps (or one, if local=NULL) and
	 * returns the resulting segs in 'smap'. If there are two maps it also combines
	 * their grids, and adds the trajectory of the second segs to the first one.
	 * Normally it should be followed by a call to: fmap_reset_map(local)
	 */
	public void merge_maps (FSegSet other)
	{
		int				i, j;

		merge_segments (other.segs);
		
	    /* Combines the grids. Looks for the intersection of the grids and performs
	     * an OR operation. */
		for (i = 0; i < Math.min (gsize, other.gsize); i++)
			for (j = 0; j < Math.min (gsize, other.gsize); j++)
			{
				if (other.grid[other.gsize+i][other.gsize+j])
					grid[gsize+i][gsize+j] = true;
					
				if (other.grid[other.gsize-1-i][other.gsize+j])
					grid[gsize-1-i][gsize+j] = true;
					
				if (other.grid[other.gsize+i][other.gsize-1-j])
					grid[gsize+i][gsize-1-j] = true;
					
				if (other.grid[other.gsize-1-i][other.gsize-1-j])
					grid[gsize-1-i][gsize-1-j] = true;
			}					
	}

	/* If the robot moved over a segment it deletes the part that intersects with the
	 * volume occupied by the robot. If two segments are very close it merges them
	 * (even if they did not fulfill the requirements in fmap_merge_maps). It also
	 * deletes the segments with less than a few sensor readings.
	 */
	public void clean_map ()
	{
		segs.clean ();
	}

	/* Checks if the robot is moving in an already mapped area in order to activate
	 * (deactivate) self_localization. Returns a flag in the segs structure indicating
	 * if self-localization is active or not. This routine should be called when the
	 * robot has approximately moved 40 cm.
	 * It activates self-localization when the robot reaches a cell that was already
	 * mapped. It deactivates when the robot crosses two consecutive cells that were
	 * not mapped.
	 *
	 *  self_loc   mapped   xy old = xy     .     self_loc   mapped   xy old = xy 
	 *
	 *     F         F           F          .        F         T           T
	 *     F         T           T          .        F         T           T
	 *     F         T           F          .        T         T           T
	 *     T         T           T          .        T         T           T
	 *     T         F           F          .        T         F           T
	 *     T         T           F          .        T      T+T(t-1)       T
	 *     T         F           F          .        F      T+T(t-1)       T
	 *     T         F           T          .        T         F           T
	 *
	 * In case 5: mapped_grid[xcell_old][ycell_old] == TRUE
	 * In case 7: mapped_grid[xcell_old][ycell_old] == FALSE 
	 */
	public void check_self_localization (double x, double y)
	{
		int			xcell, ycell, adj_xcell, adj_ycell;
		double		iaux;

		// Compute in which cell the robot is (each cell is a 1x1 m square)
		xcell = gsize + (int) Math.round (x);
		ycell = gsize + (int) Math.round (y);
		
		/* If the robot moves in a not mapped cell but very close to a mapped cell, it
		 * considers that it is still in a mapped area. 
		 */
		iaux = x - Math.floor (x);
		if (iaux < 0.250)
			adj_xcell = xcell - 1;
		else if (iaux > 0.750)
			adj_xcell = xcell + 1;
		else  
			adj_xcell = xcell;
			
		iaux = y - Math.floor (y);
		if (iaux < 0.250)
			adj_ycell = ycell - 1;
		else if (iaux > 0.750)
			adj_ycell = ycell + 1;
		else
			adj_ycell = ycell;

		if (xcell<0 || xcell>=(2*gsize) || ycell<0 || ycell>=(2*gsize))
		{
			System.out.println ("WARNING:  The robot is outside the area defined for self-localization.");
			return;
		}
		
		if (!act_loc)
		{
			if (!grid[xcell][ycell])
			{
				/* Marks the new cell as already visited */
				grid[xcell][ycell] = true;
				xcell_old = xcell;
				ycell_old = ycell;
			}
			else if (xcell_old!=xcell || ycell_old!=ycell)
			{
				/* Arrives to a mapped cell */
				act_loc = true;
				xcell_old = xcell;
				ycell_old = ycell;
			}
		}
		else
		{
			/* act_loc = TRUE */
			if (grid[xcell][ycell] && (xcell_old!=xcell || ycell_old!=ycell))
			{
				/* Arrives to a mapped cell */
				if (!grid[xcell_old][ycell_old])
					grid[xcell_old][ycell_old] = true;
				xcell_old = xcell;
				ycell_old = ycell;
			}
			else if (!grid[xcell][ycell] && (xcell_old!=xcell || ycell_old!=ycell))
				/* Arrives to a not mapped cell */
				if (grid[xcell_old][ycell_old])
				{
					/* but comes from a mapped cell */
					xcell_old = xcell;
					ycell_old = ycell;
				}
				else if (grid[adj_xcell][ycell] || grid[xcell][adj_ycell])
					/* comes from another not mapped cell but it is very close to a mapped cell*/  ;
				else
				{
					/* comes from another not mapped cell */
					act_loc = false;
					if (!grid[xcell_old][ycell_old])
						grid[xcell_old][ycell_old] = true;
					grid[xcell][ycell] = true;
					xcell_old = xcell;    
					ycell_old = ycell;
				}
		}
	}
}


