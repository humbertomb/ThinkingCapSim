/*
 * (c) 2004 Humberto Martinez
 */

package tclib.navigation.mapbuilding.visualization;

import java.awt.*;

import tc.shared.lps.lpo.*;

import tclib.navigation.mapbuilding.lpo.*;

import wucore.widgets.*;
import wucore.utils.math.*;

public class Scanner2D
{	
	public static final double			MARK		= 1.0;
	public static final double			DELTA1	= 15.0;
	public static final double			DELTA2	= 5.0;
		
	// LPO objects drawing policies
	protected Model2D					model;
	protected LPOView					view;						// Viewing properties
	protected double					range;						// Laser scanner range
	
	/* Constructors */
	public Scanner2D (Model2D model) 
	{
		this.model		= model;
				
		// Setup viewing properties
		view			= new LPOView ();
		view.rotation	= 0.0;
		view.verbose	= true;
	}
	
	/* Accessors */
	public void			range (double range)				{ this.range = range; }
	
	/* Instance methods */
	
	/*
	 * Update the LPS window, by putting both LPOs
	 * and range data.
	 */
	public void update (LPOFSegments fsegs, LPOSensorScanner scan, LPORangeLTG ltg)
	{
		double			x1, y1, x2, y2;
		double			aa, rr;
				
		// Initialise component's model
		model.clearView ();
										
		// Draw references
		for (aa = 0.0; aa <= 180.0; aa += DELTA1)
		{
			x1	= range * Math.cos (aa * Angles.DTOR);
			y1	= range * Math.sin (aa * Angles.DTOR);
			model.addRawLine (0.0, 0.0, x1, y1, Model2D.PLAIN, Color.GRAY);
		}
		for (rr = MARK; rr <= range; rr += MARK)
		{
			x1	= rr;
			y1	= 0.0;
			
			for (aa = DELTA2; aa <= 180.0; aa += DELTA2)
			{
				x2	= rr * Math.cos (aa * Angles.DTOR);
				y2	= rr * Math.sin (aa * Angles.DTOR);		
				model.addRawLine (x1, y1, x2, y2, Model2D.PLAIN, Color.GRAY);				
				x1	= x2;
				y1	= y2;
			}
			
			model.addRawText (rr, -0.3, Integer.valueOf ((int) rr).toString (), Model2D.J_CENTER, Color.BLUE);
			model.addRawText (-rr, -0.3, Integer.valueOf ((int) rr).toString (), Model2D.J_CENTER, Color.BLUE);
		}
		
		// Set LPO specific viewing area
		view.min.set (-range, -range, -range);
		view.max.set (range, range, range);
				
		// Draw active LPOs		
		scan.draw (model, view);
		if (ltg != null) 		ltg.draw (model, view);
		if (fsegs != null)		fsegs.draw (model, view);

		// Set model boundaries
		model.setBB (-range, -0.5, range, range);
	}
}

