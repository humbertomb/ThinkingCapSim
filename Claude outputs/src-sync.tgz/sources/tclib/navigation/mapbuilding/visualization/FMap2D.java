/*
 * (c) 1999-2000 Humberto Martinez
 * (c) 2003 Humberto Martinez
 */
 
package tclib.navigation.mapbuilding.visualization;

import java.awt.*;

import tc.vrobot.*;
import tc.gui.visualization.*;

import tclib.navigation.mapbuilding.*;
import tclib.navigation.mapbuilding.lpo.*;
import tclib.utils.fusion.*;

import devices.pos.*;
import wucore.widgets.*;
import wucore.utils.geom.*;
import wucore.utils.math.*;

public class FMap2D extends World2D
{			
	public static final double			ARROW_ANG		= 15.0 * Angles.DTOR;	
	public static final double			ARROW_SIZ		= 0.0;
	public static final double			RADIUS			= 0.015;
	public static final double			AFACTOR			= 1.7;
	
	public static final int				H_LOCAL			= 0;
	public static final int				H_GLOBAL		= 1;
	public static final int				H_ODOM			= 2;
	public static final int				H_COR			= 3;
	
	protected Component2D 				compo;

	public boolean						draw_hud		= true;
	
	/* Constructors */
	public FMap2D (Model2D model, Component2D compo, RobotDesc rdesc, FusionDesc fdesc) 
	{
    	this.compo = compo;

    	this.initialise (model, rdesc, fdesc, null);
    	this.initialise ();   	
	}
  
	public FMap2D (Model2D model, Component2D compo, RobotDesc rdesc, FusionDesc fdesc, String mapname) 
	{
    	this.compo = compo;

    	this.initialise (model, rdesc, fdesc, mapname);
    	this.initialise ();
	}
  
	/* Instance methods */
	protected void initialise () 
	{
		// Add support for HUD objects
		if (draw_hud)
		{
			compo.hud_n				= 4;
			compo.hud_x[H_LOCAL]	= 45;
			compo.hud_y[H_LOCAL]	= 45;
			compo.hud_x[H_GLOBAL]	= 45;
			compo.hud_y[H_GLOBAL]	= 60;
			compo.hud_x[H_ODOM]		= 250;
			compo.hud_y[H_ODOM]		= 45;
	    	compo.hud_x[H_COR]		= 250;
	    	compo.hud_y[H_COR]		= 60;
		}
	}
  
	public void update (FSegMap fmap, Paths paths, Position pos)
	{
		int				i, j, cells;
		double			xi, yi, xf, yf;
		double			xu, yu, au;
		double			dr0, dr1;		
		double			rx, ry, ra;
		Line2[]			icon;
		LPOFSegments	local;
		LPOFSegments	global;
		boolean[][]		grid;
		double[][]		uncert;
		Position		dpos;
		
		if (fmap == null) return;
		
		// Initialise component's model
		model.clearView ();

		// Initialise auxiliary constants
		local	= fmap.local ().segs ();
		global	= fmap.global ().segs ();
		grid	= fmap.global ().grid ();
		icon	= rdesc.icon;

		if (pos != null)
		{
			rx 		= pos.x ();
			ry	 	= pos.y ();
			ra	 	= pos.alpha ();
			uncert	= pos.uncert ();
		}
		else
		{
			rx 		= -Double.MAX_VALUE;
			ry	 	= -Double.MAX_VALUE;
			ra		= 0.0;
			uncert	= null;
		}

		// Set HUD data values
		if (draw_hud)
		{
			compo.hud_label[H_LOCAL]	= "Local:  " + local.numseg () + " segs";
			compo.hud_label[H_GLOBAL]	= "Global: " + global.numseg () + " segs";
			
			if ((paths != null) && ((dpos = paths.correction ()) != null))
				compo.hud_label[H_COR]	= "Corr:   [" + ((int) Math.round (dpos.x () * 1000.0)) + ", " + ((int) Math.round (dpos.y () * 1000.0)) + ", " + ((int) Math.round (dpos.alpha ()*Angles.RTOD)) + "] mm, deg";
			else
				compo.hud_label[H_COR]	= "Corr:   N/A";
		}
		
		// Draw explored cells
		if (grid != null)
		{
			cells = fmap.global ().grid_n ();
			for (i = 0; i < 2 * cells; i++)
				for (j = 0; j < 2 * cells; j++)
					if (grid[i][j])
						model.addRawBox ((i - cells) - 0.5, (j - cells) - 0.5, (i - cells) + 0.5, (j - cells) + 0.5, Model2D.FILLED, Color.LIGHT_GRAY);
		}
			
		// Draw real map (a priori known map)
		drawWorld ();

		// Draw fuzzy segments (global map)
		if (global != null)
			for (i = 0; i < global.numseg (); i++)
			{
				xi	= global.segment (i).xi ();
				yi	= global.segment (i).yi ();
				xf	= global.segment (i).xf ();
				yf	= global.segment (i).yf ();
				dr0	= global.segment (i).v0_rho ();
				dr1	= global.segment (i).v1_rho ();
				
				model.addRawRotSegment (xi, yi, xf, yf, dr1, 0.0, Color.CYAN);		
				model.addRawRotSegment (xi, yi, xf, yf, dr0, 0.0, Color.BLUE);	
			}

		// Draw fuzzy segments (local map)
		if (local != null)
			for (i = 0; i < local.numseg (); i++)
			{
				xi	= local.segment (i).xi ();
				yi	= local.segment (i).yi ();
				xf	= local.segment (i).xf ();
				yf	= local.segment (i).yf ();
				dr0	= local.segment (i).v0_rho ();
				dr1	= local.segment (i).v1_rho ();
				
				model.addRawRotSegment (xi, yi, xf, yf, dr1, 0.0, Color.GREEN);		
				model.addRawRotSegment (xi, yi, xf, yf, dr0, 0.0, Color.GREEN.darker());		
			}

		// Draw robot paths
		if (drawpath)				drawPaths (paths);
		if (drawtrace)				drawTraces (paths);
		
		// Draw uncertainty estimation
		if (uncert != null)
		{
			xu	= Math.sqrt (uncert[0][0]);
			yu	= Math.sqrt (uncert[1][1]);
			au	= Math.sqrt (uncert[2][2]);
		
			model.addRawRotEllipse (rx, ry, xu, yu, ra, Color.BLUE.darker());
			model.addRawArrow (rx, ry, rdesc.RADIUS * AFACTOR, ra - au, ARROW_SIZ, ARROW_ANG, Model2D.PLAIN, Color.BLUE.darker());
			model.addRawArrow (rx, ry, rdesc.RADIUS * AFACTOR, ra + au, ARROW_SIZ, ARROW_ANG, Model2D.PLAIN, Color.BLUE.darker());

			if (draw_hud)
				compo.hud_label[H_ODOM]	= "Uncert: [" + ((int) Math.round (xu * 1000.0)) + ", " + ((int) Math.round (yu * 1000.0)) + ", " + ((int) Math.round (au * Angles.RTOD)) + "] mm, deg";
		}
		else
			if (draw_hud)
				compo.hud_label[H_ODOM]	= "Uncert: N/A";

		// Draw the real robot
		if (icon == null)
		{
			model.addRawCircle (rx, ry, rdesc.RADIUS, Color.RED);
			model.addRawArrow (rx, ry, rdesc.RADIUS, ra, Color.RED);
		}
		else
			for (i = 0; i < icon.length; i++)
				model.addRawTransRotLine (icon[i], rx, ry, ra, Color.RED);
	}
}

