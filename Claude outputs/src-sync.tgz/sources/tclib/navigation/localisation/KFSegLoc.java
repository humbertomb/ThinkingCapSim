/*
 * (c) 2002 Humberto Martinez
 *			Miguel Zamora
 *			David Herrero
 *
 *		Kalman-based localisation with sonar-ir fusion
 */

package tclib.navigation.localisation;

import tc.shared.lps.lpo.*;
		
import tclib.navigation.mapbuilding.*;
import tclib.navigation.mapbuilding.lpo.*;
import tclib.utils.fusion.*;

import devices.pos.*;
import wucore.utils.math.*;
import wucore.utils.math.jama.*;

public class KFSegLoc extends Object
{	
	// Operation modes
	public static final int			MODE_SIMPLE	= 0;			// Do not use angle to segment in matching
	public static final int			MODE_FULL	= 1;			// Do use angle to segment in matching

	// Initial variances
	public static final double		INIT_VAR_R	= 0.0001218;	// Initial rotation variance (rad2) 	<= 2 deg
	public static final double		INIT_VAR_T	= 0.00009;		// Initial translation variance (m2)	<= 0.003 m

	public static final double		EPSILON		= 0.0000001;	// If less than this, consider it to be zero
	public static final double		CHI2		= 9.0;			// Matching value for the Chi-square test
	public static final double		DIF_ANG		= 15.0;			// Maximum angle between measure and segment (rad)
	public static final double		MAX_RANGE	= 2.0;			// Maximum sensor range (m)
	public static final int			MATCH_SEGS	= 3;			// Minimum number of matched segments for updating
	public static final int			MATCH_SENS	= 5;			// Minimum number of matched measures for updating

	// Matching Parameters
	private static final double		WEI_HEI_WIN		= 0.15;	
	private static final double		WEI_HEI_WIN_2	= 0.15;
	
	// Variances	
	protected double				var_w		= 0.008;		// Rotational velocity variance ([rad/s]2)	<= 0.05
	protected double				var_v		= 0.0005;		// Linear velocity variance ([m/s]2)
	protected double				var_sen		= 0.400;		// sensors uncertainty (m2)
	
	// Global matrices
	protected Matrix				P;							// State prediction covariance
	protected Matrix				X;							// Estimated state
	
	// Position prediction variables
	protected Position				posk;						// Current position, time k
	protected Position				posk1;						// Position at time k-1
	protected long					tk;							// Time at k
	protected long					tk1;						// Time at k-1	

	// Position prediction matrices
	private Matrix					Fx;							// Jacobian with respect to the state of the previous state 
	private Matrix					Fu;							// Jacobian with respect to the input of the previous state 
	private Matrix					Qx;							// Variance of the input projected into the state space 
	private Matrix					Qu;							// Variance of the input 
	
	// Measure matching
	private Matrix					hx;							// Jacobian with respect to the state of the measure prediction 
	private Matrix					s;							// Innovation covariance 
	private Matrix					r;							// Variance of the measure 
	private KMatch					match;						// Store for matched segments
	private double					uncert_x;					// Position uncertainty X (m2)
	private double					uncert_y;					// Position uncertainty Y (m2)
	
	// Position updating matrices
	private Matrix					Hx;							// Jacobian with respect to the state of the measure prediction (only matched measures)
	private Matrix					S;							// Innovance covariance (only matched measures)
	private Matrix					R;							// Variance of the measure  (only matched measures)
	private Matrix					W;							// Kalman gain
	private Matrix					V;							// Innovation
	private Matrix					Pe;							// State prediction covariance (filtered)
	private Matrix					Xe;							// Estimated state (filtered)

	// Other local stuff
	protected FusionDesc			fdesc;
	private boolean					debug			= false;	// Standard console debug
	private boolean					showall			= false;	// Show all matrices for hard debugging
	private int						mode			= MODE_SIMPLE;// Matching mode for segments
	private boolean					firstime;

	// Constructors
	public KFSegLoc (FusionDesc fdesc)
	{
		inisialise(fdesc);
	}
	
	// Accessors
	public final Position			current ()				{ return posk; }

	// Instance methods 
	
	protected void inisialise (FusionDesc fdesc)
	{
		// Set up global parameters
		this.fdesc	= fdesc;
		match		= new KMatch ();
		
		// Create prediction data structures
		posk		= new Position ();
		posk1		= new Position ();
		
		Fx			= new Matrix (3, 3);
		Fu			= new Matrix (3, 2);
		Qu			= new Matrix (2, 2);
		
		// Create matching data structures
		hx			= new Matrix (1, 3);
		r			= new Matrix (1, 1);
				
		firstime	= true;	
	}
	
	protected double zeroValue (double value)
	{
		if ((value < EPSILON) && (value > -EPSILON))
			return 0.0;			// Math.abs (value);
		else		
			return value;
	}
	
	protected boolean testMatching (LPOFSegment seg, double xm, double ym)
	{					
		double xi=seg.xi(), yi=seg.yi(), xf=seg.xf(), yf=seg.yf();
		double xsi,xsf,ysi,ysf,xwin,ywin,xc,yc,phi,rho;
		
		if ((Math.abs(xi-xf)<0.01)){		// Vertical line.
			if ((ym < Math.max(yi,yf))&&(ym > Math.min(yi,yf))){
				xwin = WEI_HEI_WIN + uncert_x;
				xsi = xi - xwin;
				xsf = xi + xwin;
				if ((xm > xsi)&&(xm < xsf))
					return true;
				else
					return false;
			} else
				return false;
		} else if ((Math.abs(yi-yf)<0.01)){		// Horizontal line.
			if ((xm < Math.max(xi,xf))&&(xm > Math.min(xi,xf))){
				ywin = WEI_HEI_WIN + uncert_y;
				ysi = yi - ywin;
				ysf = yi + ywin;
				if ((ym > ysi)&&(ym < ysf))	
					return true;
				else
					return false;
			} else
				return false;
		} else if (((xm < Math.max(xi,xf))&&(xm > Math.min(xi,xf))) && ((ym < Math.max(yi,yf))&&(ym > Math.min(yi,yf)))){
			phi 	= seg.phi();
			rho		= seg.rho();
			xc 		= -1. * ym * Math.tan(phi) +  rho / Math.cos(phi);
			xwin 	= WEI_HEI_WIN_2 + uncert_x;
			xsi 	= xm - xwin;
			xsf 	= xm + xwin;

			if ((xc > xsi)&&(xc < xsf)){
				return true;
			}
			yc = -1.* xm / Math.tan(phi) +  rho / Math.sin(phi);
			ywin = WEI_HEI_WIN_2 + uncert_y;
			ysi = ym - ywin;
			ysf = ym + ywin;
			if ((yc > ysi)&&(yc < ysf)){
				return true;	
			}
			return false;
		} else
			return false;
	}
	
	protected void prediction (Position pos, long time)
	{
		double		dt;
		double 		drho, dphi;
		
		// Update time
		tk1	= tk;
		tk	= time;
		dt	= (double) (tk - tk1) / 1000.0;

		// Update position
		posk1.set (posk);
		posk.set (pos);
		
		if (firstime)
		{
			// Initialise state prediction covariance
			P	= new Matrix (3, 3);
			P.diagonal (INIT_VAR_T);
			P.set (2, 2, INIT_VAR_R);
						
			// Initialise estimated state
			X	= new Matrix (3, 1);
			
			X.set (0, 0, posk.x ());
			X.set (1, 0, posk.y ());
			X.set (2, 0, posk.alpha ());
			firstime	= false;
		}
		else
		{
			// Update current linear/rotational speeds
			drho	= Math.sqrt ((posk.x () - posk1.x ())*(posk.x () - posk1.x ())+(posk.y () - posk1.y ())*(posk.y () - posk1.y ()));
			dphi	= Angles.radnorm_180 (posk.alpha () - posk1.alpha ());
				
			try
			{
				// Fx												[3x3]
				Fx.identity ();
				Fx.set (0, 2, -drho * Math.sin (posk.alpha ()));
				Fx.set (1, 2, drho * Math.cos (posk.alpha ()));
				
				// Qu												[2x2]
				Qu.identity ();
				Qu.set (0, 0, var_v * drho * drho);
				Qu.set (1, 1, var_w * dphi * dphi);

				// Fu												[3x2]
				Fu.set (0, 0, dt * Math.cos (posk.alpha ()));
				Fu.set (0, 1, -drho * dt * Math.sin (posk.alpha ()));
				Fu.set (1, 0, dt * Math.sin (posk.alpha ()));
				Fu.set (1, 1, drho * dt * Math.cos (posk.alpha ()));
				Fu.set (2, 0, 0);
				Fu.set (2, 1, dt);

				// Qx=FuQuFu'										[3x3]
				Qx	= Fu.times (Qu).times (Fu.transpose ());
				
				// P=FxPFx'+Qx										[3x3]
				P	= Fx.times (P).times (Fx.transpose ()).plus (Qx);

				uncert_x	=	Math.sqrt(P.get (0, 0));			
				uncert_y	=	Math.sqrt(P.get (1, 1));	

				posk.set(P);

				// X												[3x1]
				X.set (0, 0, posk.x ());
				X.set (1, 0, posk.y ());
				X.set (2, 0, posk.alpha ());

			} catch (Exception e) { e.printStackTrace (); }
		}
	}

	protected void matching (FSegMap fmap, LPOSensorRange virtual)
	{
		LPOFSegment		seg;
		LPOFSegments	global;
		int			i, j;
		double		sr;
		double		sga, sgr;
		double		xs, ys;
		double		xm, ym;
		double		zp, v, pv;
		double		dms, pdms;
		double		tn, tnd, td, tdd;
		double		disp;
		double		phi, rho;
		
		if (firstime)			return;
		
		global	= fmap.global ().segs ();
		
		match.n		= 0;
		for (i = 0; i < fdesc.MAXVIRTU; i++)
		{
			// Get current sensor local position
			sr		= fdesc.virtufeat[i].rho ();
			
			// Get current sensor global position
			sga		= Angles.radnorm_180 (fdesc.virtufeat[i].orientation () + posk.alpha ());
						
			// Compute current sensor global position
			sgr		= Angles.radnorm_180 (fdesc.virtufeat[i].theta () + posk.alpha ());
			xs		= posk.x () + sr * Math.cos (sgr);
			ys		= posk.y () + sr * Math.sin (sgr);

			// Compute virtual measure global position
			xm		= xs + virtual.range[i] * Math.cos (sga);
			ym		= ys + virtual.range[i] * Math.sin (sga);

			for (j = 0; j < global.numseg (); j++)
			{
				// Test if the measure is in range
				if ((virtual.range[i] > MAX_RANGE) || !virtual.valid[i])		continue;
				
				// Get jth-segment from fuzzy map
				seg		= global.segment (j);
				phi		= seg.phi ();
				rho		= seg.rho ();
				
				// Angle between measure orientation and the perdendicular of the segment
				dms		= Math.min(Math.abs(Angles.radnorm_180 (phi - sga)), Math.abs(Angles.radnorm_180 (phi - (sga - Math.PI))));
				pdms 	= 1.0;		if (dms < 0.0)		pdms = -1.0;
				dms		= Math.abs (dms);
						
				if (dms > DIF_ANG)			
					continue;	
					
				if (!testMatching (seg, xm, ym)) 	
					continue;			
					
				// Prediction of the measure
				zp		= rho - (xs * Math.cos (phi) + ys * Math.sin (phi));
				pv 		= 1.0;		if (zp < 0.0)		pv = -1.0;
				v		= virtual.range[i] - Math.abs (zp);

				try
				{
					switch (mode)
					{
					case MODE_SIMPLE:
						// hx										[1x3]
						hx.set (0, 0,  zeroValue (-Math.cos (phi) * pv));								// dzp/dx
						hx.set (0, 1,  zeroValue (-Math.sin (phi) * pv));								// dzp/dy
						hx.set (0, 2,  pv*sr*(Math.sin(sgr)*Math.cos(phi)-Math.cos(sgr)*Math.sin(phi)));	// dzp/da
						break;
						
					case MODE_FULL:
						// Derivative of zp with respect to robot orientation (parts of)
						tn		= rho - xs * Math.cos (phi) - ys * Math.sin (phi);
						tnd		= sr * Math.sin (Angles.radnorm_180 (sga - phi));
						td		= Math.cos (dms);
						tdd		= -Math.sin (dms) * pdms;
								
						// hx										[1x3]
						hx.set (0, 0, -Math.cos (phi) * pv / Math.cos (dms));											// dzp/dx
						hx.set (0, 1, -Math.sin (phi) * pv / Math.cos (dms));											// dzp/dy
						hx.set (0, 2, (tnd * td - tn * tdd) * pv / (Math.cos (dms) * Math.cos (dms)));		// dzp/da
						break;
						
					default:
					}
				
					// Standar deviation of the measure, computed using the segment uncertainty
					disp	= seg.v1_phi ();
					
					// r											[1x1]
					r.set (0, 0, disp * disp);
					
					// s=hxPhx'+r									[1x1]
					s		= hx.times (P).times (hx.transpose ()).plus (r);
										
					// Matching
					if ((Math.abs ((v * v) / s.get (0, 0)) <= CHI2) && (match.n < KMatch.MAX_MATCHES))
					{
						match.hx[match.n][0]	= hx.get (0, 0);
						match.hx[match.n][1]	= hx.get (0, 1);
						match.hx[match.n][2]	= hx.get (0, 2);
						
						match.r[match.n]		= r.get (0, 0);
						match.v[match.n]		= v;
						
						match.s[match.n]		= j;

						match.n ++;
					}
				} catch (Exception e) { e.printStackTrace (); }
			}
		}
	}
	
	protected void update ()
	{
		int			i;
		
		if (firstime)								return;
		
		match.compute_matches ();
//if ((match.segs != 0) || (match.n != 0)) System.out.println(" Segmentos "+match.segs+" Medidas "+match.n);

//		if ((match.segs < MATCH_SEGS) || (match.n < MATCH_SENS))		return;
		if ((match.segs < 1) || (match.n < 1))		return;
		
//System.out.println("	 	Actualizo ");		
		try
		{
			// Hx													[nx3]
			Hx		= new Matrix (match.n, 3);
			for (i = 0; i < match.n; i++)
			{
				Hx.set (i, 0, match.hx[i][0]);
				Hx.set (i, 1, match.hx[i][1]);
				Hx.set (i, 2, match.hx[i][2]);
			}

			// R													[nxn]
			R		= new Matrix (match.n, match.n);
			for (i = 0; i < match.n; i++)
				R.set (i, i, match.r[i]);

			// V													[nx1]
			V		= new Matrix (match.n, 1);
			for (i = 0; i < match.n; i++)
				V.set (i, 0, match.v[i]);

			// S=HxPHx'+R											[nxn]
			S		= Hx.times (P).times (Hx.transpose ()).plus (R);
		
			// W=PHx'/S												[3xn]
			W		= P.times (Hx.transpose ()).times (S.inverse ());
			
			// Xe=X+WV												[3x1]
			Xe		= X.plus (W.times (V));
			
			// Pe=P-WSW'											[3x3]
			Pe		= P.minus (W.times (S).times (W.transpose ()));
			
			// Update current state and covariances
			X.setMatrix (Xe); 
			P.setMatrix (Pe); 

			posk.set(P);

			uncert_x	=	Math.sqrt(P.get (0, 0));			
			uncert_y	=	Math.sqrt(P.get (1, 1));
			
			// Set the corrected position
			posk.set (X.get (0, 0), X.get (1, 0), X.get (2, 0));
			
		} catch (Exception e) { e.printStackTrace (); }
	}

	public void do_localisation (Position pos, long time, FSegMap fmap, LPOSensorRange virtual)
	{
		prediction (pos, time);
		matching (fmap, virtual);
		update ();
	}			
}
