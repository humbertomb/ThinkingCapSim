/*
 * (c) 2003 Humberto Martinez
 */
 
package wucore.utils.logs;

import java.io.*;

public class LogFile extends Object
{	
	// Debug related structures
	protected PrintWriter		file;		// File for logging
	protected String			preffix;
	protected String			suffix;
	protected boolean		append;
	protected boolean		flush;

	// Constructors
	public LogFile (String preffix, String suffix)
	{
		this (preffix, suffix, false);
	}
	
	public LogFile (String preffix, String suffix, boolean append)
	{
		this.preffix		= preffix;
		this.suffix		= suffix;
		this.append		= append;
		this.file		= null;
		this.flush		= true;
	}
	
	// Instance methods	
	protected String find_name ()
	{
		boolean			notfound = true;
		int				logorder = 0;
		
		if (append)
			return preffix + suffix;
		
		// File a suitable file name
		while (notfound)
		{
			try
			{
				FileReader file = new FileReader (preffix + logorder + suffix);
				try { file.close (); } catch (Exception e) { }
				logorder ++;
			}
			catch (FileNotFoundException fnfe) { notfound = false; }
		}

		return preffix + logorder + suffix;
	}

	public void setFlush(boolean flush){
		this.flush = flush;
	}

	public void open ()
	{
		String			name;
		
		// Check if file already open
		if (file != null)				return;
		
		name = find_name ();
		try
		{
			file = new PrintWriter (new BufferedWriter (new FileWriter (name, append)));  
		} catch (Exception e) { file = null; }
	}

	public void open (String a, String b, String c, String d)
	{
		String			name;
		
		// Check if file already open
		if (file != null)				return;
		
		name = find_name ();
		try
		{
			file = new PrintWriter (new BufferedWriter (new FileWriter (name, append)));  
			file.println (a + "\t" + b + "\t" + c + "\t" + d);
		} catch (Exception e) { file = null; }
	}
	
	public void open (String[] labels)
	{
		int				i;
		String			name;
		
		// Check if file already open
		if (file != null)				return;
		
		name = find_name ();
		try
		{
			file = new PrintWriter (new BufferedWriter (new FileWriter (name, append)));  
			if (labels != null)
				for (i = 0; i < labels.length; i++)
					file.print (labels[i] + "\t");
			file.println ();
		} catch (Exception e) { file = null; }
	}

	public synchronized void write (double a, double b, double c, String label)
	{
		if (file == null)				return;
		
		file.println (a + "\t" + b + "\t" + c + "\t" + label);
		if (flush)	file.flush ();
	}
	
	public synchronized void write (double[] values)
	{
		int				i;
		
		if (file == null)				return;
		
		if (values != null)
			for (i = 0; i < values.length; i++)
				file.print (values[i] + "\t");
		file.println ();
		if (flush)	file.flush ();
	}
	
	public synchronized void writeln (String data)
	{
		if (file == null || data == null)				return;		
		file.println(data);
		if (flush)	file.flush ();
	}
	
	public synchronized void write (String type, long stamp, int count, double[] values)
	{
		int				i;
		
		if (file == null)				return;
		
		file.print (type + "\t" + stamp + " " + count + "\t");
		if (values != null)
			for (i = 0; i < values.length; i++)
				file.print (values[i] + " ");
		file.println ();
		if (flush)	file.flush ();
	}

	public void close ()
	{
		if (file == null)				return;
		
		file.flush ();
		file.close ();
		
		file = null;
	}
}

