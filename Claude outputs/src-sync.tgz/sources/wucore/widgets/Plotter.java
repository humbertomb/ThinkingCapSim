/*
 * (c) 2000-2004 Humberto Martinez
 */
 
package wucore.widgets;

import java.awt.*;
import javax.swing.*;

import ptolemy.plot.Plot;

public class Plotter extends JPanel
{
	static public int				POINTS		= 50;
	
	protected Plot					plot;	
	protected int					curx		= 0;
	
	public Plotter ()
	{		
		plot	= new Plot ();
		plot.setGrid (true);
		plot.setColor (true);
		plot.setMarksStyle ("none");
		plot.setConnected (true);
		plot.setButtons (false);

		setPreferredSize (new Dimension(110, 110));
		setLayout (new GridLayout(1,1));
		add (plot);

		curx	= 0;
	}

	public void setLegend (String[] labels)
	{
		int			i;
		
		plot.clearLegends ();
		for (i = 0; i < labels.length; i++)
			plot.addLegend (i, labels[i]);
	}
	
	public void setLabels (String horiz, String vert)
	{
		plot.setXLabel (horiz);
		plot.setYLabel (vert);
	}
	
	public void setImpulses (boolean stems)
	{
		plot.setImpulses (stems);
	}
	
	public void setYRange (double ymin, double ymax)
	{
		plot.setYRange (ymin, ymax);
	}
	
	public void updateData (double[] data)
	{
		int			i;
		
		if (data == null)			return;
				
		curx ++;
    	for (i = 0; i < data.length; i++)
        	plot.addPoint (i, curx, data[i], true);

		if (curx > POINTS)		plot.setXRange ((double)  (curx - POINTS), (double) curx);
		
		plot.repaint ();
	}	
	
	public void updateData (double data)
	{
		curx ++;
		plot.addPoint (0, curx, data, true);

		if (curx > POINTS)		plot.setXRange ((double)  (curx - POINTS), (double) curx);
		
		plot.repaint ();
	}	
}
