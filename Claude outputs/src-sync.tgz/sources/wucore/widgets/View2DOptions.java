/** 
 * Model2DOptions.java
 *
 * Description:		Information of the current Model display
 * @author			Humberto Martinez Barbera
 * @version			1.0
 */

package wucore.widgets;

import wucore.utils.math.*;

public class View2DOptions extends Object
{
	protected double			scale;
	protected Matrix2D			amat;
	
	// Constructors
	public View2DOptions (double scale, Matrix2D amat)
	{
		this.amat		= new Matrix2D ();

		set (scale, amat);
	}
		
	// Accessors
    public final double			getScale ()								{ return scale; }
    public final Matrix2D		getTransform ()							{ return amat; }

	// Instance methods
	public void set (View2DOptions opts)
	{
		set (opts.getScale (), opts.getTransform ());
		
	}
	public void set (double scale, Matrix2D amat)
	{
		this.scale	= scale;
		this.amat.set (amat);
	}
}
