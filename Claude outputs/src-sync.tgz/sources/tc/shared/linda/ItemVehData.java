/*
 * (c) 2003 Humberto Martinez
 */
 
package tc.shared.linda;

import java.io.*;

import tc.fleet.*;

public class ItemVehData extends Item implements Serializable
{
	public VehicleData				data;
	
	// Constructors
	public ItemVehData () 
	{
		this.set (0);
	}	
	
	// Instance methods
	public void set (VehicleData data, long tstamp)
	{
		set (tstamp);
		this.data = data;
	}
	
	public String toString ()
	{
		return data.toString ();
	}	
}
