/* 
	Title:			Thinking Cap 
	Author:			Humberto Martinez Barbera, Juan Pedro Canovas Quiñonero
	Description:	BGA Architecture Support.
*/

package tc.shared.linda;

import java.io.*;
import tclib.planning.sequence.*;

public class ItemPlan extends Item implements Serializable
{
	public Sequence					seq;
	
	//Constructors
	public ItemPlan ()
	{
		this.set (0);
	}
		
	// Instance methods
	public void set (Sequence seq, long tstamp)
	{
		set (tstamp);
		
		this.seq	= seq;
	}
		
	public String toString ()
	{		
		return seq.toString();				
	}
}