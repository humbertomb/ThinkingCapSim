/* 
	Title:			Thinking Cap 
	Author:			Humberto Martinez Barbera, Juan Pedro Canovas Quiñonero
	Description:	BGA Architecture Support.
*/

package tc.shared.linda;

import java.io.*;

public class ItemStatus extends Item implements Serializable
{	
	public static final int		ALARM		= 10;
	public static final int		IDLE			= 11;
	public static final int		OCCUPIED		= 12;
	public static final int		WAIT			= 13;
	
	public static final int		COMPLETED	= 30;
	public static final int		FAILED		= 31;
	
	public int					type;
	public String				message;
	
	// Constructors
	public ItemStatus ()
	{
		this.set (0);
	}
	
	// Class methods
	static public boolean typeIsReport (int type)
	{
		return (type == ALARM) || (type == COMPLETED) || (type == FAILED);
	}
	
	static public String typeToString (int type)
	{
		switch (type)
		{
		case ALARM:			return "ALARM";				
		case IDLE:			return "NO JOB";
		case OCCUPIED:		return "OCCUPIED";
		case WAIT:			return "WAITING";
		case COMPLETED:		return "COMPLETED";
		case FAILED:			return "FAILED";
		}
		return "N/A";
	}

	// Instance methods
	public void set (int alarmtype, String errormess, long tstamp)
	{
		set (tstamp);
		type = alarmtype;
		message = errormess;
	}
	
	public String toString ()
	{
		return typeToString (type) + ". " + message;
	}
}