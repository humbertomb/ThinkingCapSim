/*
 * (c) 2003 Humberto Martinez
 */
 
package tc.shared.linda;

import java.io.*;

public class ItemBehResult extends Item implements Serializable
{
	// Task completion constants
	static public final int			T_FINISHED		= 0;
	static public final int			T_FAILED		= 1;
	static public final int			T_NOTYET		= 2;
		
	// Failure resons
	static public final int			F_OK			= 0;
	static public final int			F_BEHIND		= 1;
	static public final int			F_SIDE			= 2;
		
	public int		 				result;
	public int		 				reason;
	public long						serial;
	
	//Constructors
	public ItemBehResult ()
	{
		this.set (0);
		
		result	= T_NOTYET;
		reason	= F_OK;
		serial	= 0;
	}
	
	// Class methods
	static public String resultToString (int result)
	{
		switch (result)
		{
			case T_FINISHED:		return "FINISHED";
			case T_FAILED:			return "FAILED";
			case T_NOTYET:			return "NOT YET";
			default:				return "N/A";
		}
	}
	
	static public String reasonToString (int reason)
	{
		switch (reason)
		{
			case F_OK:				return "OK";
			case F_BEHIND:			return "BEHIND";
			case F_SIDE:			return "AT SIDE";
			default:				return "N/A";
		}
	}
	
	// Instance methods
	public void set (int result, int reason, long serial, long tstamp)
	{
		set (tstamp);
		
		this.serial		= serial;
		this.result		= result;
		this.reason		= reason;
	}
		
	public String toString ()
	{		
		return "Behaviour result: " + resultToString (result) + " reason: " + reasonToString (reason) + " serial: " + serial;				
	}
}