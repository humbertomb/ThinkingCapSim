/*
 * (c) 2003 Humberto Martinez
 */
 
package tc.vrobot;

import java.io.*;

public class TrackerData extends Object implements Serializable
{
	// Tracking devices parameters
	public static final int		RANGE		= 0;
	public static final int		ALPHA		= 1;
	public static final int		SPEED		= 2;
	
	public double[][]			trks;
	public boolean[]			valid;

	/* Constructors */
	public TrackerData (RobotDesc rdesc)
	{
		int			i;
		
		// Create sensor structures
		trks		= new double [rdesc.OBJTRK][3];
		valid		= new boolean [rdesc.OBJTRK];

		// Initialise sensor status flag (default = invalid measure)
		for (i = 0; i < rdesc.OBJTRK; i++)
			valid[i]	= false;
	}
}