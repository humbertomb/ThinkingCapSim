/*
 * (c) 1997-2000 Humberto Martinez
 * (c) 2001 Humberto Martinez, Juan Pedro Canovas
 * (c) 2002 Humberto Martinez
 */
 
package tc.vrobot;

import java.io.*;

import devices.data.*;

public class RobotData extends Object implements Serializable
{
	// Robot sensor data (from raw sensors)
	public double[]				sonars;
	public boolean[]			sonars_flg;
	public double[]				irs;
	public boolean[]			irs_flg;
	public double[][]			lrfs;
	public boolean[]			lrfs_flg;
	
	public boolean[]			bumpers;
	public int[]				captors;				// Values of wheel encoders

	// Robot sensor data (from raw sensors) TODO generalise!!!!!
	public double				vm;						// Traction motor displacement (m)
	public double				vel;					// Steering velocity (m/s)
	public double				del;					// Steering motor position (rad)
	public double				fork;					// Value of lift encoder (m)
	public int					pal_switch=-1;				// Palets switch
	
	// Robot sensor data (from raw high-level sensors)
	public TrackerData[]		trackers;

	// Robot positioning data (from raw sensors)
	public double				odom_x;					// Current robot coordinates (m, m, rad)
	public double				odom_y;
	public double				odom_rho;
	public double				odom_a;

	// Robot positioning data (from high-level sensors)
	public GPSData[]			gps;
	public CompassData[]		compass;
	public InsData[]			ins;
	public BeaconData[]			beacon;	

	// Robot ground truth (only for simulation)
	public double				real_x;					// Current robot coordinates (m, m, rad)
	public double				real_y;
	public double				real_a;

	/* Constructors */
	public RobotData (RobotDesc rdesc)
	{
		int			i;
		
		// Create data structures
		sonars		= new double [rdesc.MAXSONAR];
		sonars_flg	= new boolean [rdesc.MAXSONAR];
		irs			= new double [rdesc.MAXIR];
		irs_flg		= new boolean [rdesc.MAXIR];
		lrfs		= new double [rdesc.MAXLRF][rdesc.RAYLRF];
		lrfs_flg	= new boolean [rdesc.MAXLRF];
		bumpers		= new boolean [rdesc.MAXBUMPER];
		captors		= new int[rdesc.MAXENCS];
		
		trackers	= new TrackerData [rdesc.MAXTRACKER];

		gps			= new GPSData[rdesc.MAXGPS];
		compass		= new CompassData[rdesc.MAXCOMPASS];
		ins 		= new InsData[rdesc.MAXINS];
		beacon		= new BeaconData[rdesc.MAXLSB];
		
		// Initialise sensor structures
		for (i = 0; i < rdesc.MAXTRACKER; i++)
			trackers[i]		= new TrackerData (rdesc);

		// Initialise sensor status flag (default = valid measure)
		for (i = 0; i < rdesc.MAXSONAR; i++)
			sonars_flg[i]	= true;
			
		for (i = 0; i < rdesc.MAXIR; i++)
			irs_flg[i]		= true;

		for (i = 0; i < rdesc.MAXLRF; i++)
			lrfs_flg[i]		= true;		
			
		// Initialise positioning structures (default = invalid measure)
		for (i = 0; i < rdesc.MAXLSB; i++)
		{
			beacon[i]		= new BeaconData ();
			beacon[i].setValid (false);
		}
	}
	
	public void location (double x, double y, double a)
	{
		odom_x	= real_x	= x;
		odom_y	= real_y	= y;
		odom_a	= real_a	= a;
	}
}