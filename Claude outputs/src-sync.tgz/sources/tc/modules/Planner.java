/*
 * (c) 2002-2004 Humberto Martinez Barbera
 */
 
package tc.modules;

import tc.runtime.thread.*;
import tc.shared.linda.*;
import tc.shared.lps.*;
import tc.shared.world.*;
		
public abstract class Planner extends StdThread
{
	/**
	 * The actions this kind of planner understands, for whoever offers a task to
	 * be built: the words a plan may name beside a place, which each planner reads
	 * with a parsePlan of its own. A planner that says nothing understands
	 * nothing, and nothing is to be asked of it.
	 */
	static public final String[]	ACTIONS		= { };

	// Linda related variables
	protected Tuple					ltuple;
	protected ItemLPS				litem;
	
	protected Tuple					gtuple;
	protected ItemGoal				gitem;
	
	protected Tuple					stuple;
	protected ItemStatus				sitem;
	
	// World description and models
	protected World					world;					// A priori world model

	// Shared data	
	protected LPS					lps;						// Local Perceptual Space
	protected int					behresult;				// Behaviour execution result
	protected long					behtime;					// Time of behaviour initiation
	protected String					robotid;					// Current robot identification

	// Constructors
	protected Planner (ModuleConfig cfg, Linda linda)
	{
		super (cfg, linda);
	}
	
	// Instance methods
	protected void initialise (ModuleConfig cfg)
	{		
		// Setup local stuff
		litem	= new ItemLPS ();
		ltuple	= new Tuple (Tuple.LPS, litem);

		gitem	= new ItemGoal ();
		gtuple	= new Tuple (Tuple.GOAL, gitem);

		sitem	= new ItemStatus ();
		stuple	= new Tuple (Tuple.STATUS, sitem);

		behtime		= 0;
		behresult	= ItemBehResult.T_NOTYET;
	}
	
	public void setStatus (int reason, String status)
	{	
		if (debug)		System.out.println ("  [Pla] Sending status [" + ItemStatus.typeToString (reason) + "] with : " + status);

		sitem.set (reason, status, System.currentTimeMillis ());
		linda.write (stuple);
	}

	public int taskStatus ()
	{
		int			tmp;
		
		// This is for taskStatus to avaluate to true only once
		tmp			= behresult;
		behresult	= ItemBehResult.T_NOTYET;

		if (debug)		System.out.println ("  [Pla] Evaluating task to [" + ItemBehResult.resultToString (tmp) + "]");

		// This should be a little more elaborated (different error codes)
		if (tmp == ItemBehResult.T_FAILED)
			System.out.println ("--[Pla] The current plan has FAILED");
		
		return tmp;
	}
		
	public void poll () 
	{ 
		Tuple			tuple;
		ItemLPS			item;
		
		if (world == null || linda == null)				return;
		
		tuple	= linda.read (ltuple);
		if (tuple == null)
			lps		= null;
		else
		{
			item	= (ItemLPS) tuple.value;
			lps		= item.lps;
		}
	}	

	public void notify_plan (String space, ItemPlan item) 
	{ 
	}	

	public void notify_config (String space, ItemConfig item)
	{
		// Update world models
		if (item.world != null)
			world	= World.fromJsonText (item.world);
		
		// Initialise variables
		robotid		= space;
	}	

	public void notify_execution (String space, ItemExecution item) 
	{		
		super.notify_execution (space, item);
		
		switch (item.operation)
		{
		case ItemExecution.DEBUG:
			debug	= item.dbg_planner;
			break;
		case ItemExecution.COMMAND:
		default:
		}	
	}	

	public void notify_beh_result (String space, ItemBehResult item) 
	{
		// Check if the answer corresponds to the originating goal ID
		if (item.serial == behtime)
			behresult	= item.result;
		else
			behresult	= ItemBehResult.T_NOTYET;

		if (debug)		System.out.println ("  [Pla] Received task confirmation [" + item + "]");
	}	
}

