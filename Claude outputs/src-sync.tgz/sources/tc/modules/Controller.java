/*
 * (c) 2001 Humberto Martinez
 */
 
package tc.modules;

import tc.runtime.thread.*;
import tc.shared.linda.*;
import tc.shared.lps.*;
import tc.shared.world.World;
import tc.vrobot.*;
import tclib.utils.fusion.*;

public abstract class Controller extends StdThread
{
	protected World					world;					// A priori world model
	protected RobotDesc				rdesc;					// Robot description
	protected FusionDesc			fdesc;					// Fusion method description
	protected LPS					lps;						// Local Perceptual Space
	
	// Linda related variables
	protected Tuple					mtuple;
	protected ItemMotion			mitem;
	protected Tuple					btuple;
	protected ItemBehResult			bitem;

	// Constructors
	protected Controller (ModuleConfig cfg, Linda linda)
	{
		super (cfg, linda);
	}

	// Instance methods
	protected void initialise (ModuleConfig cfg)
	{		
		// Setup local stuff
		mitem	= new ItemMotion ();
		mtuple	= new Tuple (Tuple.MOTION, mitem);
		bitem	= new ItemBehResult ();
		btuple	= new Tuple (Tuple.BEHRESULT, bitem);
	}

	public void setMotion (double speed, double turn)
	{
		if (mitem == null)		return;
		
		mitem.set (speed, turn, System.currentTimeMillis ());
		linda.write (mtuple);
	}
	
	public void setMotion (int mode, double speed, double turn)
	{
		if (mitem == null)		return;
		
		mitem.set (mode, speed, turn, System.currentTimeMillis ());
		linda.write (mtuple);
	}
		
	public void setResult (int result, int reason, long serial)
	{
		if (bitem == null)		return;
		
		bitem.set (result, reason, serial, System.currentTimeMillis ());
		linda.write (btuple);
	}

	public void notify_config (String space, ItemConfig item)
	{
		if (item.props_robot != null)
		{
			rdesc		= new RobotDesc (item.props_robot);
			fdesc		= new FusionDesc (item.props_robot);
		    
		    state 		= RUN;
	    }
		
		if (item.world != null)
			world = World.fromJsonText (item.world);
	}
	
	public void notify_execution (String space, ItemExecution item) 
	{		
		super.notify_execution (space, item);
		
		switch (item.operation)
		{
		case ItemExecution.DEBUG:
			debug	= item.dbg_controller;
			break;
		case ItemExecution.COMMAND:
		default:
		}	
	}	
	
	public void notify_lps (String space, ItemLPS item) 
	{ 
		if (state != RUN)				return;
		
		lps		= item.lps;
		
		try
		{
			if (tdesc.passive)				step (System.currentTimeMillis ());
		} catch (Exception e) { e.printStackTrace (); }
	}	
}

