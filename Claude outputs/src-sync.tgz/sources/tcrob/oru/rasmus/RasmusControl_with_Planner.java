/*
 * @(#)RasmusControl.java		1.0 2004/01/24
 * 
 * (c) 2004 Denis Remondini
 *
 */
package tcrob.oru.rasmus;

import tc.runtime.thread.ModuleConfig;
import java.util.*;
import java.io.*;
import java.text.DecimalFormat;


import tclib.behaviours.fhb.*;
import tclib.behaviours.fhb.bplan.*;
import tclib.behaviours.fhb.exceptions.*;
import tclib.behaviours.fhb.logic.*;
import tclib.planning.sequence.*;

import tc.shared.linda.*;
import tc.modules.*;
import tc.shared.lps.lpo.*;
import devices.pos.*;


/**
 * This class implements the controller.
 * 
 * @version	1.0		24 Jan 2004
 * @author Denis Remondini
 */
public class RasmusControl_with_Planner extends Controller
{
	/* Linda related variables */
	protected Tuple					mtuple;
	protected ItemMotion			mitem;
	
/* BEGIN Jesper added stuff */
	/* Goal and task related variables */
	protected boolean				new_goal;					// New goal received
	protected Task					plan;						// Current goal task
	
	/* Current robot to desired path distance */				
	public static Path				path;						// Desired Robot pass
	protected Position				pos;						// Current Robot position
	protected Position				looka;						// Current look-ahead point
	protected double				looka_dst;					// Current look-ahead distance (m)
	protected double				path_dst;
/* END Jesper added stuff */
	
	/*
	 * The name of the file that contains the BPlan to parse
	 */
	private static final String BPLAN_FILENAME = "./conf/programs/bplan.dat";
	/*
	 * The name of the file where to write the data from the experiments
	 */
	private static final String EXPERIMENT_LOGFILE = "./conf/programs/experimentData.dat";
	/*
	 * It's a parameter that could be passed by argument to the main program class (e.g., tcapp.Exec)
	 * in order to enable the logging procedure. The log file will contain all the data
	 * about active behaviours shown in the Behaviour Information window
	 */
	private static final String PROP_LOG = "tc.rasmus.logging";
	
	/* It stores the result of the main behaviour execution */
	private ControlVariables output;
	/* They contain the values to send to the robot motion engine */
	private double vel, rot;
	/* The list of parameters used by the behaviours */
	private HashMap<String, Object> param;
	/* The main behaviour */
	private BPlanMainBehaviour beh;
	/* The behaviour of which the debug window has requested information */
	private Behaviour behRequested;
	/* The information about a behaviour */
	private BehaviourInfo behInfo;
	/* 
	 * The path that has to be followed to reach the behaviour 
	 * requested by the debug window 
	 */
	private ArrayList<String> behRequestedPath;
	/* Linda Item about the behaviour information */
	private ItemBehInfo bItem;
	/* Linda Tuple about the behaviour information */
	private Tuple bTuple;
	/* This variable tell if a behaviour reload is requested */
	private boolean reloadBehaviour;
	/* This variable tell if the controller has to send the behaviour information */
	private boolean sendDebugInformation;
	/* 
	 * Auxiliary variable that contains the reference to some LPO objects that will be used by the 
	 * behaviours as parameters. 
	 */
	private LPO lpo;
	/*
	 * Indicates that it's the first time that the controller step method is executed.
	 * It's useful to know if it's necessary to parse the BPlan data 
	 */
	private boolean firstTime = true;
	/*
	 * Contains the information given by the BPlan parsing process
	 */
	private BPlanData bPlanData;
	/*
	 * Contains the information about the experiments made with the framework
	 */
	private ExperimentData experimentData;
	/*
	 * It is used to write the experimental information on a stream
	 */
	private BufferedWriter logBuffer;
	/*
	 * It's used to enable or disable the logging procedure
	 */
	private boolean logging;
	
	private DecimalFormat fmt;
	
	
	/**
	 * Creates and initializes a new controller
	 */
	public RasmusControl_with_Planner(ModuleConfig cfg, Linda linda)
	{
		super (cfg, linda);
		super.initialise (cfg); 
	}
	
	/*
	 * Initializes the controller
	 * 
	 * @see tc.runtime.thread.StdThread#initialise(java.util.Properties)
	 */
	protected void initialise (ModuleConfig cfg)
	{		
		// Setup local stuff
		mitem	= new ItemMotion ();
		mtuple	= new Tuple (Tuple.MOTION, mitem);
		
	/* BEGIN Jesper added stuff */
		new_goal	= false;
		looka_dst	= 2.0;
		looka		= new Position();
		pos			= new Position();
		plan 		= new Task();
	/* END Jesper added stuff */
		
		/* creates the linda item and tuple about the behaviour information */
		bItem = new ItemBehInfo();
		bTuple = new Tuple (Tuple.BEHINFO, bItem);
	
		/* variables initialization */
		vel = 0.0;
		rot = 0.0;
		param = new HashMap<String, Object> ();
		behRequested = null;
		behRequestedPath = null;
		reloadBehaviour = false;
		sendDebugInformation = false;
		/* Checks if it's necessary to enable the logging procedure or not */
		String prop = System.getProperty(PROP_LOG); 
		if ((prop != null) && (prop.equals ("true")))
			logging = true;
		else
			logging = false;
		
		fmt = new DecimalFormat();
		fmt.setMaximumFractionDigits(2);

		BehaviourFactory.loadConfiguration (cfg.get ("FACT"));
	}
	
	/*
	 * Creates the main behaviour using the information included in the
	 * file that contains the B-Plan.
	 */
	private void createBPlanMainBehaviour() {
		BPlanParser bPlanParser = null;
		try {
			BufferedReader bPlanBuffer = new BufferedReader(new FileReader(BPLAN_FILENAME));
			bPlanParser = new BPlanParser(bPlanBuffer,lps);
			bPlanParser.parse();
		}
		catch (Exception e) {
			System.out.println(e.toString());
			return;
		}
		
		bPlanData = bPlanParser.getBPlanData();
		
		/* loads the main behaviour */
		beh = new BPlanMainBehaviour();
		beh.createRules(bPlanData);
	}
	
	/**
	 * This method is called every control cycle and it represent the core of the controller
	 */
	public void step (long ctime)
	{
		if (!auto ||(state != RUN) || (lps == null))		return;
		
		if (firstTime) {
			firstTime = false;
			createBPlanMainBehaviour();
		}
//		System.out.println("xxxxxxxxxxxxxxx"+System.currentTimeMillis());
		/* reload the main behaviour if it is requested */
		if (reloadBehaviour) {
			beh.createRules(bPlanData);
			findBehRequested(behRequestedPath);
			reloadBehaviour = false;
		}
		
		/*
		 * This part until LOOK-AHEAD END is necessary only
		 * if you want to use the FollowPath behaviour, otherwise you have to comment it
		 */
		// Compute look-ahead point
		pos.set (lps.cur);
		looka.set (pos);
		looka.valid (false);
		if (!new_goal && (path != null))
		{
			path.check_lookahead (pos, looka_dst);
			if (path.lookahead () != null)
			{
				path_dst	= path.distance ();
				looka.set (path.lookahead ());
				looka.valid (true);
				
			}
		}
		// we do not want to move the robot until the path is calculated
		if (looka.valid() == false)
			return;
		// Update LPS
		LPO l_looka;
		l_looka		= lps.find ("Looka");
		l_looka.locate (looka.x () - pos.x (), looka.y () - pos.y (),pos.alpha());
		l_looka.active (looka.valid ());
		/* LOOK-AHEAD END */
		
		/* behaviour's parameters updating */
		beh.setParam("Looka",l_looka);
		lpo = lps.find("RBuffer");
		beh.setParam("RBuffer",lpo);

		try {
			
			/* behaviour execution */
		 	output = beh.exec();

		}
		catch (RuleException e){
			System.out.println(e.toString());
		}

		/* defuzzication */
		output.defuzzify();
		/* gets the crisp values for the control variables */
		rot = output.getCrispValue(ControlVariables.ROTATION);
		vel = output.getCrispValue(ControlVariables.SPEED);

//		System.out.println("DEBUG: VEL = "+vel+" ROT = "+rot);
		
		/* Sends the values of the control variables to the robot motion engine */
		setMotion(vel,rot*Math.PI/180);
		
		// updates the behaviour information in the linda space
		if (sendDebugInformation) {
			sendBehInformation();
		}
	}	
	
	/*
	 * Writes the behaviour information to the linda space 
	 */
	private void sendBehInformation() {
		if (logging == true) {
			try {
				logBuffer.write("Time: "+System.currentTimeMillis());
				logBuffer.write(" RobotPos: "+fmt.format(lps.cur.x())+" "+fmt.format(lps.cur.y()));
			}
			catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if (behRequested == null)
			behInfo = setBehInfo(beh);
		else 
			behInfo = setBehInfo(behRequested);
		
		if (logging == true) {
			try {
				experimentData.writeBehInformation(behInfo);
			}
			catch (Exception e) {
				System.out.println(e);
			}
		}
		bItem.set(behInfo);		 	
		linda.write(bTuple);	
	}
		
	/*
	 * Finds the behaviour requested. The list contains the path to reach the behaviour.
	 */
	private void findBehRequested(ArrayList<String> list) {
		RuleSet rules;
		ArrayList<String> rulesNames;
		Behaviour currentBeh;
		
		if ((list == null) || (list.isEmpty()))
			behRequested = null;
		else {
			currentBeh = beh;
			for (int i = 0; i < list.size(); i++) {
				String ruleName = list.get(i);
				int j = 0;
				rules = currentBeh.getRuleSet();
				rulesNames = rules.getRulesNames();
				while ((j < rulesNames.size()) && (!ruleName.equals(rulesNames.get(j))))
					j++;
				if (j == rulesNames.size())
					break;
				currentBeh = rules.getRule(ruleName).getSubBehaviour();
			}
			behRequested = currentBeh;
		}
	}
	
	/*
	 * Sets the information about a behaviour 
	 */
	private BehaviourInfo setBehInfo(Behaviour b) {
		
		BehaviourInfo behInfo = new BehaviourInfo(b.getName());
		behInfo.setAntecedentPredicates(b.getAntecedentValues());
		RuleSet behRules = b.getRuleSet();
		setRulesInformation(behInfo,behRules);
		behInfo.setOutputFSets(b.getOutputFSets());
		behInfo.setValuesSentToRobot(output.getCrispValues());
		return behInfo;
	}

	/*
	 * Sets the information about the rules of a behaviour
	 */
	private void setRulesInformation(BehaviourInfo behInfo, RuleSet rules) {
		Rule currentRule;
		Behaviour beh;
		ArrayList<String> rulesNames = rules.getRulesNames();
		for (int i = 0; i < rulesNames.size(); i++) {
			currentRule = rules.getRule(rulesNames.get(i));

			beh = currentRule.getSubBehaviour();			
			if (beh != null)
				behInfo.addRule(rulesNames.get(i),currentRule.getAntecedentValue(),currentRule.getOutputFSets(),beh.getName(),beh.getParameters());
			else 
				behInfo.addRule(rulesNames.get(i),currentRule.getAntecedentValue(),currentRule.getOutputFSets(),null,null);
//			rulen++;
		}
		
	}
	
	/**
	 * This method is called when the BehDebug item is written to the linda space
	 * @param item the BehDebug item written to the linda space
	 */
	public void notify_beh_debug(String space, ItemBehDebug item) {
		if (item.getCommand() == ItemBehDebug.START) {
			if (logging == true) {
				try {
					logBuffer = new BufferedWriter(new FileWriter(EXPERIMENT_LOGFILE));
					experimentData = new ExperimentData(logBuffer);
				}
				catch (Exception e) {
					System.out.println(e.toString());
				}
			}
			sendDebugInformation = true;
		} else {
			if (logBuffer != null) {
				try {
					logBuffer.close();
				} catch (Exception e) { System.out.println(e.toString()); }
			}
			sendDebugInformation = false;
		}
		behRequested = null;
		behRequestedPath = null;
	}
	
	/**
	 * This method is called when the BehName item is written to the linda space
	 * @param item the BehName item written to the linda space 
	 */
	public void notify_beh_name(String space, ItemBehName item) {
		BehaviourFactory.createBehaviour(item.get(),true);
		reloadBehaviour = true;
	}
	
	/**
	 * This method is called by monitor to tell what is the behaviour requested by the
	 * debug information window
	 */
	public void notify_beh_rules(String space, ItemBehRules item) {
		behRequestedPath = item.get();
		findBehRequested(behRequestedPath);	
		sendBehInformation();	
	}
	

	public void notify_config (String space, ItemConfig item) 
	{
		super.notify_config (space, item);
		
	}
		
	public void notify_goal (String space, ItemGoal goal) 
	{
		LPOPoint			l_goal;
	
		// Update LPS
		l_goal		= (LPOPoint) lps.find ("Goal");
		if (l_goal != null)
		{
			l_goal.update (pos, goal.task.tpos);
			l_goal.active (true);
		}
			
		plan.set (goal.task);
		new_goal	= true;
	}

	public void notify_path (String space, ItemPath item)
	{
		path		= item.path;	
		new_goal	= false;
	}
}
