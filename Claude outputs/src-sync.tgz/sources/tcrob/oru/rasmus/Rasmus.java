package tcrob.oru.rasmus;

import tc.runtime.thread.ModuleConfig;
import tc.vrobot.*;
import tc.shared.linda.*;

import java.lang.Math;

public class Rasmus extends VirtualRobot
{
	// Fields
	static public final String 	PROP_CONNECT = "oru.ramus.connect";
  	      
	// Driver
	protected RasmusDriver driver;
	protected boolean connected = true;
	
	
	// Odomentry
	boolean first_time = true;
	Pose_t GL_pos = new Pose_t();
	
	
	// Tempory solution
	//static boolean 	manual 		=true;
	double 	old_speed 	= 0.0;
	double 	old_turn 	= 0.0;
	double[] lasers;
	boolean	laser_flg;

	
	
	
	// Constructors
	public Rasmus (ModuleConfig cfg, Linda linda)
	{
		super (cfg, linda);
		this.initialise (cfg);
	}

	// Instance methods
	protected void initialise (ModuleConfig cfg)
	{
		// Configure whatever your system needs to be configurated
		String			prop;
		this.lasers		= new double[181];//rdesc.RAYLRF]; 
		
		super.initialise (cfg);
		
		// Check if robot is to be connected
		prop = System.getProperty (PROP_CONNECT);
		if ((prop != null) && (prop.equals ("false")))
			connected = false;
		
		// Initialise robot driver
		if (connected)
		{
			driver = new RasmusDriver ();
			boolean check = driver.connect("192.168.200.12", 36100.98);	//36274.98		
			if( !check )
				connected = false;
			else
				driver.initalize();
		} 
		// Reset the system
		reset ();
	}


	public void reset ()
	{
		if( connected )
			driver.restart();
	}
	
	public synchronized void process_sensors (long dtime)
	{	
	// -- Update the current valuse in the Robot --
		driver.update();
		
	// -- Get the sonarvalues to the data variable --
		driver.sonars(data.sonars, data.sonars_flg );
		
	// -- Update laser range sensors --
		driver.lasers(data.lrfs[0]);
		data.lrfs_flg[0]=true;
		
	// -- ODOMENTRY CALCULATIONS --
		driver.odomentry();
		if( this.first_time )
			this.first_time = false;
		else
		{
			Pose_t rasmus_pos = new Pose_t( RasmusDriver.odom_x, RasmusDriver.odom_y, RasmusDriver.odom_a);
			GL_pos.add_to_global( rasmus_pos );
		}
		GL_pos.update_data( data );
		
	}


	
	public synchronized void notify_motion (String space, ItemMotion item)
	{
    	int	 ctrlmode;
    	double speed, turn;
    	super.notify_motion (space, item);
    	
    	
		speed		= item.speed;
		turn		= item.turn;
		ctrlmode	= item.ctrlmode;
		
				

		// Movement commands
    	if (ctrlmode != ItemMotion.CTRL_NONE)
    	{
			switch (ctrlmode)
			{
				case ItemMotion.CTRL_MANUAL:
				// Motor control stuff
						driver.motor( speed, turn);//((turn*180)/Math.PI) );
				break;
				case ItemMotion.CTRL_AUTO:
				// Motor control stuff
					//driver.motor( speed, ((turn*180)/Math.PI) );
					driver.motor( speed, turn/2);
				break;
				default:
					System.out.println ("--[Rasmus] Unrecognised control-mode command");
			}
		}
		old_speed = speed;
		old_turn = turn;
	}
	
	
	// Private class for odemtry
	private class Pose_t
	{
		public double X;
		public double Y;
		public double Theta;
		
		Pose_t()
		{
			X=0.0;
			Y=0.0;
			Theta = 0.0;
		}
		
		Pose_t(double x, double y, double theta)
		{
			this.X = x;
			this.Y = y;
			this.Theta = theta;
		}
		

		private void normalize()
		{
			if( Theta> Math.PI )
			{
				double diff = Theta - Math.PI; 
				Theta 		= -(Theta-diff);
			}
			if( Theta < -Math.PI )
			{	
				double diff = -(Theta+Math.PI);
				Theta 		= -(Theta+diff);
			}
		}
		public void add_to_global( Pose_t pos )
		{
			this.X 		= this.X + pos.X * Math.cos(this.Theta) - pos.Y * Math.sin(this.Theta);
			this.Y 		= this.Y + pos.X * Math.sin(this.Theta) - pos.Y * Math.cos(this.Theta); 
			this.Theta 	= this.Theta + pos.Theta;			
			this.normalize();
		}
		public void update_data( RobotData data )
		{
			data.odom_x 	= this.X;
			data.odom_y 	= this.Y;
			data.odom_a 	= this.Theta;
		}
		public void print_values(String source)
		{
			System.out.println("---"+source+"----------------------");
			System.out.println( " X = "+this.X);
			System.out.println( " Y = "+this.Y);
			System.out.println( " A = "+(180*this.Theta/Math.PI)+"  Grader");
			System.out.println();
		}
	}
}