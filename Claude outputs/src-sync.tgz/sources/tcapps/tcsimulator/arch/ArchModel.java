/*
 * (c) 2026 Humberto Martinez Barbera
 */

package tcapps.tcsimulator.arch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import tc.DeployArch;
import tc.DeployArch.Event;
import tc.DeployArch.Linda;
import tc.DeployArch.Module;
import tc.DeployArch.Robot;

/**
 * Editor view of a {@link DeployArch} as blocks: the global Linda space and,
 * for each robot, its local Linda space, optional router, modules and
 * virtual robot. Blocks are addressed by kind, robot index and (for the
 * modules) position; the model translates property keys (the ADF suffixes
 * the runtime reads) to the fields of the deployment.
 */
public class ArchModel
{
	/** Block kinds. */
	static public final int		GLOBAL_LINDA	= 0;
	static public final int		LOCAL_LINDA		= 1;
	static public final int		ROUTER			= 2;
	static public final int		MODULE			= 3;
	static public final int		VROBOT			= 4;
	static public final int		ROBOT			= 5;		// the robot container itself

	static public final String[]	KIND_NAMES	= { "Global Linda Space", "Local Linda Space", "Router", "Module", "Virtual Robot", "Robot" };


	/* --- property presentation ---------------------------------------- */

	/** Editor types of a property. */
	static public final int		P_TEXT		= 0;
	static public final int		P_BOOLEAN	= 1;
	static public final int		P_CHOICE	= 2;
	static public final int		P_FILE		= 3;
	static public final int		P_CLASS		= 4;		// chosen among the classes of the development deriving from one

	/** The class the modules and the robots of an architecture are run as threads of. */
	static public final String	THREAD_BASE	= "tc.runtime.thread.StdThread";
	/** The class the robot of an architecture is. */
	static public final String	VROBOT_BASE	= "tc.vrobot.VirtualRobot";
	/** The class a router of the coordination layer is. */
	static public final String	ROUTER_BASE	= "tc.modules.LindaRouter";
	/** The class the value of a tuple of the coordination space is. */
	static public final String	ITEM_BASE	= "tc.shared.linda.Item";
	/** Where the deployments of the project live. */
	static public final String	DEPLOY_DIR	= "./conf/deploy";
	/** What a module is not, though it is a thread of the runtime as they are. */
	static public final String[]	MODULE_NOT	= { VROBOT_BASE };
	/**
	 * What a robot of a deployment is not, though it is a virtual robot: the robot
	 * of the simulator itself, which stands for a real robot and is only used when
	 * running on one.
	 */
	static public final String		SIM_ROBOT	= "tcapps.tcsimulator.simulator.objects.SimRobot";
	static public final String[]	VROBOT_NOT	= { SIM_ROBOT };

	/**
	 * The kinds of module an architecture is made of, which are the classes of
	 * <code>tc.modules</code> they derive from: the kind a module is created as is
	 * kept with it (TYPE) and is what names it and says which classes it may be.
	 */
	static public final String[]	MODULE_TYPES	= { "Controller", "Navigation", "Perception", "Planner" };

	/** The kind of module that runs a program of its own. */
	static public final String		CONTROLLER		= "Controller";

	/**
	 * The program a controller runs (PRG). Any file will do: whether it is one the
	 * controller can read is for the controller to say when it loads it.
	 */
	static public final Property	PRG_PROP		= new Property ("PRG", "Program", "./conf/programs", "Programs");

	/**
	 * Whether a controller starts running of its own accord (AUTO), instead of
	 * waiting to be told to start. It is what the module is given in its
	 * configuration, and nothing is taken to be no.
	 */
	static public final Property	AUTO_PROP		= new Property ("AUTO", "Autostart", P_BOOLEAN);

	/** The class the modules of a kind derive from. */
	static public String moduleTypeBase (String type)
	{
		if (type == null)						return null;
		type	= type.trim ();
		for (String t : MODULE_TYPES)			if (t.equalsIgnoreCase (type))		return "tc.modules." + t;
		return null;
	}

	/** Execution modes of a module (ThreadDesc.parse_mode) and protocols towards the global Linda (RouterDesc GMODE). */
	static public final String[]	MODES		= { "shared", "udp", "tcp" };
	static public final String[]	PROTOCOLS	= { "tcp", "udp", "shared" };

	/** How a property (suffix) of a block is shown and edited. */
	static public class Property
	{
		public String	key;			// suffix of the ADF key (INFO, CLASS, ...)
		public String	label;			// name shown to the user
		public int		type;			// P_TEXT, P_BOOLEAN, P_CHOICE, P_FILE, P_CLASS
		public String[]	choices;		// P_CHOICE values
		public String	classBase;		// P_CLASS: the class the ones offered derive from
		public String[]	classNot;		// P_CLASS: and what they must not derive from
		public boolean	classBlank;		// P_CLASS: whether it may be left with no class at all
		public String	fileDir;		// P_FILE: default directory
		public String	fileDesc;		// P_FILE: filter description
		public String[]	fileExts;		// P_FILE: filter extensions
		public String	fixed;			// the one value it can have (shown, not edited); null if it can be edited
		public String	why;			// and why it cannot be anything else

		public Property (String key, String label)								{ this (key, label, P_TEXT); }
		public Property (String key, String label, int type)						{ this.key = key; this.label = label; this.type = type; }
		public Property (String key, String label, String[] choices)				{ this (key, label, P_CHOICE); this.choices = choices; }
		public Property (String key, String label, String dir, String desc, String... exts)	{ this (key, label, P_FILE); fileDir = dir; fileDesc = desc; fileExts = exts; }
		/** A property naming a class: what is offered are the ones of the development deriving from <code>base</code>. */
		static public Property ofClass (String key, String label, String base)		{ return ofClass (key, label, base, (String[]) null); }

		static public Property ofClass (String key, String label, String base, String... not)
		{
			Property	p = new Property (key, label, P_CLASS);
			p.classBase	= base;
			p.classNot	= not;
			return p;
		}

		/** The same, which may also be left blank: the first thing offered is no class at all. */
		public Property orNone ()						{ classBlank = true; return this; }
		/** A property that can only have one value: it is shown, not edited. */
		public Property fixedTo (String value, String why)	{ fixed = value; this.why = why; return this; }
		public String toString ()	{ return label; }
	}

	/** Names of the start points of the world (START_1, ...), offered for the robots; set by the editor. */
	protected List<String>		startNames	= new ArrayList<String> ();

	public void setStartNames (List<String> names)	{ startNames = new ArrayList<String> (names); }

	/** Robot block: the start point of the world it departs from ("" = the i-th one, by order). */
	protected Property[] robotProps ()
	{
		String[]	choices = new String[startNames.size () + 1];
		choices[0]	= "";
		for (int i = 0; i < startNames.size (); i++)		choices[i + 1] = startNames.get (i);
		return new Property[] { new Property ("START", "Start Position", choices) };
	}
	static public final Property[]	LINDA_PROPS	=
	{
		new Property ("ADDR",	"Address"),
		new Property ("PORT",	"Port"),
		new Property ("CREATE",	"Instantiate",	P_BOOLEAN),
	};
	static public final Property[]	ROUTER_PROPS	=
	{
		new Property ("INFO",	"Name"),
		Property.ofClass ("CLASS", "Class", ROUTER_BASE),
		new Property ("MODE",	"Mode",			MODES),
		new Property ("GMODE",	"Protocol",		PROTOCOLS),
		new Property ("GFX",	"Graphics",	P_BOOLEAN),
	};
	static public final Property[]	MODULE_PROPS	=
	{
		new Property ("INFO",	"Name"),
		Property.ofClass ("CLASS", "Class", THREAD_BASE, MODULE_NOT).orNone (),
		new Property ("MODE",	"Mode",			MODES),
		new Property ("PASSIVE","Passive",		P_BOOLEAN),
		new Property ("QUEUED",	"Queued",		P_BOOLEAN),
		new Property ("POLLED",	"Polled",		P_BOOLEAN),
		new Property ("EXTIME",	"Exec. time (ms)"),
		new Property ("GFX",	"Graphics",	P_BOOLEAN),
	};
	static public final Property[]	VROBOT_PROPS	=
	{
		new Property ("INFO",	"Name"),
		// the description comes right after the name: it is what says which robot this is
		new Property ("DESC",	"Robot Definition",	"./conf/robots",	"Robot descriptions (*.robot)",	"robot"),
		Property.ofClass ("CLASS", "Class", VROBOT_BASE, VROBOT_NOT).orNone (),
		new Property ("MODE",	"Mode",			MODES),
		// a robot, simulated or real, runs on its own cycle: nothing else would make it read its sensors
		new Property ("PASSIVE","Passive",		P_BOOLEAN).fixedTo ("false", "A robot, simulated or physical, is never passive: it runs on its own cycle"),
		new Property ("EXTIME",	"Exec. time (ms)"),
		new Property ("GFX",	"Graphics",	P_BOOLEAN),
	};

	/** Suffixes that exist in the ADF but are not shown in the editor, per kind. */
	static public final String[]	LINDA_HIDDEN	= { "CLASS" };
	static public final String[]	ROUTER_HIDDEN	= { "PRI", "CONNECT" };
	static public final String[]	MODULE_HIDDEN	= { "PRI", "CONNECT", "TYPE" };		// CONNECT is edited in the events table, TYPE is what the module was created as
	static public final String[]	VROBOT_HIDDEN	= { "PRI", "CONNECT" };

	/** A block of the deployment: kind, robot (-1 for the global Linda) and, for modules, position in the robot. */
	static public class Block
	{
		public int		kind;
		public int		robot;			// index of the robot the block belongs to (-1: global)
		public int		index;			// MODULE: position in the module list; -1 otherwise

		public Block (int kind, int robot)				{ this (kind, robot, -1); }
		public Block (int kind, int robot, int index)	{ this.kind = kind; this.robot = robot; this.index = index; }

		public boolean equals (Object o)
		{
			if (!(o instanceof Block))		return false;
			Block	b = (Block) o;
			return (b.kind == kind) && (b.robot == robot) && (b.index == index);
		}
		public int hashCode ()		{ return (kind * 31 + robot) * 31 + index; }
		public String toString ()	{ return KIND_NAMES[kind] + " R" + robot + ((index >= 0) ? "#" + index : ""); }
	}

	protected DeployArch		deploy;

	public ArchModel (DeployArch deploy)		{ this.deploy = deploy; }

	public DeployArch	getDeploy ()				{ return deploy; }

	/* ------------------------------------------------------------------ */
	/* Robots                                                              */
	/* ------------------------------------------------------------------ */

	/** Indices of the robots, in order. */
	public List<Integer> robots ()
	{
		List<Integer>	l = new ArrayList<Integer> ();
		for (int i = 0; i < deploy.robots.size (); i++)		l.add (i);
		return l;
	}

	protected Robot robot (int r)					{ return deploy.robots.get (r); }

	public String	getRobotId (int r)				{ return robot (r).name; }
	public String	getRobotId ()					{ return deploy.robots.isEmpty () ? DeployArch.DEFAULT_ROBOT : getRobotId (0); }
	public void		setRobotName (int r, String n)	{ if ((n != null) && (n.trim ().length () > 0)) robot (r).name = n.trim (); }

	/* ------------------------------------------------------------------ */
	/* Queries                                                             */
	/* ------------------------------------------------------------------ */

	public boolean hasGlobalLinda ()				{ return deploy.globalLinda != null; }
	public boolean hasRobot ()						{ return deploy.robots.size () > 0; }
	public boolean hasRobot (int r)					{ return (r >= 0) && (r < deploy.robots.size ()); }
	public boolean hasLocalLinda (int r)			{ return hasRobot (r); }
	public boolean hasRouter (int r)				{ return hasRobot (r) && (robot (r).router != null); }
	public boolean hasVRobot (int r)				{ return hasRobot (r); }
	public int	   moduleCount (int r)				{ return hasRobot (r) ? robot (r).modules.size () : 0; }

	/** The module behind a block (router, module or virtual robot), or null. */
	public Module moduleOf (Block b)
	{
		if (!hasRobot (b.robot))		return null;
		Robot	r = robot (b.robot);
		switch (b.kind)
		{
		case ROUTER:	return r.router;
		case VROBOT:	return r.virtualRobot;
		case MODULE:	return ((b.index >= 0) && (b.index < r.modules.size ())) ? r.modules.get (b.index) : null;
		default:		return null;
		}
	}

	/** The Linda space behind a block (global or local), or null. */
	public Linda lindaOf (Block b)
	{
		if (b.kind == GLOBAL_LINDA)		return deploy.globalLinda;
		if ((b.kind == LOCAL_LINDA) && hasRobot (b.robot))		return robot (b.robot).linda;
		return null;
	}

	/** Blocks of a robot in display order: local Linda, router, modules, virtual robot. */
	public List<Block> robotBlocks (int r)
	{
		List<Block>	l = new ArrayList<Block> ();
		if (!hasRobot (r))		return l;
		l.add (new Block (LOCAL_LINDA, r));
		if (hasRouter (r))		l.add (new Block (ROUTER, r));
		for (int i = 0; i < robot (r).modules.size (); i++)		l.add (new Block (MODULE, r, i));
		l.add (new Block (VROBOT, r));
		return l;
	}

	/** Blocks of every robot. */
	public List<Block> allRobotBlocks ()
	{
		List<Block>	l = new ArrayList<Block> ();
		for (int r : robots ())		l.addAll (robotBlocks (r));
		return l;
	}

	/** True when the block is part of the model. */
	public boolean exists (Block b)
	{
		if (b.kind == GLOBAL_LINDA)		return hasGlobalLinda ();
		if (b.kind == ROBOT)			return hasRobot (b.robot);
		return robotBlocks (b.robot).contains (b);
	}

	/** Display label of a block: the module name, or the kind name. */
	public String labelOf (Block b)
	{
		if (b.kind == ROBOT)			return "ROBOT " + getRobotId (b.robot);
		if (b.kind == GLOBAL_LINDA)		return "Global Linda Space";
		if (b.kind == LOCAL_LINDA)		return "Local Linda Space";
		Module	m = moduleOf (b);
		return (m != null) ? m.name : KIND_NAMES[b.kind];
	}

	/** True when the block can be deleted: everything but the local Linda space and the virtual robot, which every robot must have. */
	public boolean isRemovable (Block b)
	{
		return (b.kind != LOCAL_LINDA) && (b.kind != VROBOT);
	}

	/** True when the name of the block can be edited (robot name or module name). */
	public boolean isRenameable (Block b)
	{
		return (b.kind == ROBOT) || (b.kind == ROUTER) || (b.kind == MODULE) || (b.kind == VROBOT);
	}

	/** Editable name of a block: the robot name, or the module name. */
	public String nameOf (Block b)
	{
		return (b.kind == ROBOT) ? getRobotId (b.robot) : labelOf (b);
	}

	public void setName (Block b, String name)
	{
		if ((name == null) || (name.trim ().length () == 0))		return;
		if (b.kind == ROBOT)		setRobotName (b.robot, name);
		else
		{
			Module	m = moduleOf (b);
			if (m != null)		m.name = name.trim ();
		}
	}

	/**
	 * Properties shown in the editor for a block: the standard ones of its
	 * kind (with their labels and editors), then any other existing in the
	 * module as plain text, minus the hidden ones.
	 */
	public List<Property> propertiesOf (Block b)
	{
		Property[]		std;
		String[]		hidden;
		switch (b.kind)
		{
		case ROBOT:			return java.util.Arrays.asList (robotProps ());
		case GLOBAL_LINDA:
		case LOCAL_LINDA:	return java.util.Arrays.asList (LINDA_PROPS);
		case ROUTER:		std = ROUTER_PROPS;	hidden = ROUTER_HIDDEN;	break;
		case MODULE:		std = MODULE_PROPS;	hidden = MODULE_HIDDEN;	break;
		case VROBOT:		std = VROBOT_PROPS;	hidden = VROBOT_HIDDEN;	break;
		default:			return new ArrayList<Property> ();
		}
		List<Property>	props = new ArrayList<Property> ();
		List<String>	known = new ArrayList<String> ();
		for (Property p : std)
		{
			props.add (p);
			known.add (p.key);
			// only a controller runs a program, and it is of a piece with its class
			if ((b.kind == MODULE) && p.key.equals ("CLASS") && CONTROLLER.equalsIgnoreCase (get (b, "TYPE")))
			{
				props.add (PRG_PROP);
				known.add (PRG_PROP.key);
				// and whether it starts on its own, which goes with the program it runs
				props.add (AUTO_PROP);
				known.add (AUTO_PROP.key);
			}
		}
		for (String h : hidden)		known.add (h);
		Module	m = moduleOf (b);
		if (m != null)
		{
			List<String>	extra = new ArrayList<String> ();
			for (String k : m.properties.keySet ())
				if (!known.contains (k))		extra.add (k);
			Collections.sort (extra);
			for (String k : extra)		props.add (new Property (k, k));
		}
		return props;
	}

	/** Value of a property of a block ("" when unset). Linda blocks: ADDR, PORT, CREATE; modules: INFO (name) or a property. */
	public String get (Block b, String key)
	{
		if ((b.kind == ROBOT) && key.equals ("START"))
		{
			String	st = hasRobot (b.robot) ? robot (b.robot).start : null;
			return (st == null) ? "" : st;
		}
		Linda	l = lindaOf (b);
		if (l != null)
		{
			if (key.equals ("ADDR"))		return l.address;
			if (key.equals ("PORT"))		return String.valueOf (l.port);
			if (key.equals ("CREATE"))		return String.valueOf (l.instantiate);
			return "";
		}
		Module	m = moduleOf (b);
		if (m == null)					return "";
		if (key.equals ("INFO"))		return m.name;
		String	v = m.get (key);
		// a controller that says nothing of starting on its own does not, which is
		// what a description written before it was asked for says
		if ((v == null) && key.equals (AUTO_PROP.key) && CONTROLLER.equalsIgnoreCase (m.get ("TYPE")))
			return "false";
		return (v == null) ? "" : v;
	}

	public void set (Block b, String key, String value)
	{
		String	v = (value == null) ? "" : value.trim ();
		if ((b.kind == ROBOT) && key.equals ("START"))
		{
			if (!hasRobot (b.robot))		return;
			robot (b.robot).start = (v.length () == 0) ? null : v;
			return;
		}
		Linda	l = lindaOf (b);
		if (l != null)
		{
			if (key.equals ("ADDR"))		l.address = (v.length () > 0) ? v : "localhost";
			else if (key.equals ("PORT"))	{ try { l.port = Integer.parseInt (v); } catch (Exception e) { } }
			else if (key.equals ("CREATE"))	l.instantiate = Boolean.parseBoolean (v);
			return;
		}
		Module	m = moduleOf (b);
		if (m == null)					return;
		for (Property p : propertiesOf (b))
			if (p.key.equals (key) && (p.fixed != null))		v = p.fixed;		// what can only be one thing is that thing
		if (key.equals ("INFO"))		{ if (v.length () > 0) m.name = v; }
		else							m.set (key, v);
	}

	/* --- events --- */

	/** True when the block registers events: modules and the virtual robot. */
	public boolean hasEvents (Block b)
	{
		return (b != null) && ((b.kind == MODULE) || (b.kind == VROBOT));
	}

	/**
	 * True when the symbols of a block are part of the drawing of the
	 * architecture: the modules and the virtual robot, which say in the
	 * deployment what they are given, and the router, which says it in its own
	 * code.
	 */
	public boolean hasSymbols (Block b)
	{
		return (b != null) && ((b.kind == MODULE) || (b.kind == VROBOT) || (b.kind == ROUTER));
	}

	/** Events of a module as { symbol, class, method } rows. */
	public List<String[]> events (Block b)
	{
		List<String[]>	l = new ArrayList<String[]> ();
		Module			m = moduleOf (b);
		if (m != null)
			for (Event e : m.events)		l.add (new String[] { e.symbol, e.itemClass, e.method });
		return l;
	}

	/**
	 * Symbols a class takes out of the space by itself: it is not notified of
	 * them, it goes and reads them, so no deployment declares them and a module
	 * has them all the same. Read off a class file there is no telling a tuple
	 * built to be read from one built to be written, so the few there are are
	 * said here, by the class they are found in and by whether it also writes
	 * them.
	 */
	static private final String[][]	WIRED	=
	{
		{ "tc.modules.Planner",					"LPS",	"reads" },		// it polls the perceptual space when it plans
		{ "tcrob.ingenia.ifork.IForkPlanner",	"SYNC",	"writes" },		// it says it is waiting for a dock, and takes the answer
	};

	/** True when the class of a block, or one of its ancestors, takes that symbol by itself. */
	private boolean isWired (Block b, String sym, boolean written)
	{
		java.util.Map<String, List<String>>	found = named (b);

		if ((b == null) || (b.kind == ROUTER))			return false;		// a router is read for its whole traffic already
		for (String[] w : WIRED)
			if (w[1].equals (sym) && (written == w[2].equals ("writes"))
					&& found.containsKey (w[0]) && found.get (w[0]).contains (sym))		return true;
		return false;
	}

	/**
	 * Symbols the robot writes only when its platform carries the devices behind
	 * them, by the family of {@link tc.vrobot.RobotDef} that has to have one: the picture of
	 * a camera (CAMERA) when the description declares a camera, and what a vision
	 * made of what it saw (OBJECT) when it declares a vision.
	 *
	 * The code of the virtual robot names both whichever platform it runs, since
	 * it writes them if its subclass hands it something to write; whether anything
	 * ever does is said by the description and not by the code, so it is looked up
	 * there instead of being drawn always.
	 */
	static private final String[][]	BY_DEVICE	=
	{
		{ "CAMERA",	"camera" },			// tc.shared.linda.ItemCamera: the frame of a camera
		{ "OBJECT",	"vis" },			// tc.shared.linda.ItemObject: the blobs of a vision
	};

	/** Descriptions of the robots already read, by file and by when it was last written. */
	static private java.util.Map<String, tc.vrobot.RobotDef>	DESCS = new java.util.HashMap<String, tc.vrobot.RobotDef> ();

	/**
	 * The description of the platform a block runs, or null: the file its DESC
	 * names, read once and read again whenever it is written.
	 */
	static private synchronized tc.vrobot.RobotDef description (String path)
	{
		java.io.File	f;
		String			key;

		if ((path == null) || (path.trim ().length () == 0))		return null;
		f		= new java.io.File (path.trim ());
		if (!f.isFile ())										return null;
		key		= f.getAbsolutePath () + "@" + f.lastModified ();
		if (DESCS.containsKey (key))								return DESCS.get (key);
		tc.vrobot.RobotDef	d = null;
		try { d = tc.vrobot.RobotDef.load (f); } catch (Exception e) { }
		DESCS.put (key, d);
		return d;
	}

	/**
	 * True when a symbol is one the platform has to carry a device for and this
	 * one does not: a description that cannot be read carries nothing, since what
	 * is not said is not there.
	 */
	private boolean lacksDevice (Block b, String sym)
	{
		tc.vrobot.RobotDef	d;

		if ((b == null) || (b.kind != VROBOT))					return false;
		for (String[] r : BY_DEVICE)
			if (r[0].equals (sym))
			{
				d	= description (get (b, "DESC"));
				return (d == null) || (d.family (r[1]).n () == 0);
			}
		return false;
	}

	/**
	 * The symbols a block takes by itself, in the order they are said in: they
	 * are drawn like the standard events, because a module has them whether the
	 * deployment says so or not.
	 */
	public List<String> wired (Block b)
	{
		List<String>	l = new ArrayList<String> ();

		if ((b == null) || !hasSymbols (b))				return l;
		for (String[] w : WIRED)
			if (!l.contains (w[1]) && (isWired (b, w[1], false) || isWired (b, w[1], true)))		l.add (w[1]);
		return l;
	}

	/**
	 * The class a block runs, as it is read: what a description names when the
	 * development builds it, and what stands for it when it does not -- the robot
	 * of the simulator, and the plain router of the coordination layer, which is
	 * the case of the classes left out of the development for the hardware they
	 * need.
	 */
	private String classOf (Block b)
	{
		String		cls = get (b, "CLASS");

		if (tcapps.tceditor.DriverClasses.exists (cls))		return cls;
		if (b.kind == VROBOT)								return SIM_ROBOT;
		if (b.kind == ROUTER)								return ROUTER_BASE;
		return cls;
	}

	/** The symbols the class of a block, or one of its ancestors, names. */
	private java.util.Map<String, List<String>> named (Block b)
	{
		return tcapps.tceditor.DriverClasses.symbolsOf (classOf (b), symbols ());
	}

	/**
	 * The events every thread of the runtime registers for itself, whatever a
	 * deployment says: {@link tc.runtime.event.ExecutionDesc} and
	 * {@link tc.runtime.event.ConfigDesc}, which
	 * {@link tc.runtime.thread.StdThread#setTDesc} puts in after the ones the
	 * deployment asks for. A module and the robot are given them whether they
	 * want them or not, so they are not edited with the others; they are drawn
	 * with them, since being given them is no less true for not being written
	 * down.
	 */
	static public final String[][]	STD_EVENTS	=
	{
		{ "EXECUTION",	"tc.shared.linda.ItemExecution",	"notify_execution" },
		{ "CONFIG",		"tc.shared.linda.ItemConfig",		"notify_config" },
	};

	/** True when a symbol is one of those. */
	static public boolean isStandard (String sym)
	{
		for (String[] e : STD_EVENTS)
			if (e[0].equals (sym))		return true;
		return false;
	}

	/**
	 * The standard events a block is given: a module and the robot are threads of
	 * the runtime and so get them; a router is none, and gets none.
	 */
	public List<String> standard (Block b)
	{
		List<String>	l = new ArrayList<String> ();
		List<String>	dec;

		if ((b == null) || ((b.kind != MODULE) && (b.kind != VROBOT)))		return l;
		dec		= declared (b);
		for (String[] e : STD_EVENTS)
			if (!dec.contains (e[0]))		l.add (e[0]);
		return l;
	}

	/**
	 * What a block is given whatever its deployment says: the events every thread
	 * of the runtime registers and the symbols its own code takes out of the
	 * space. They are written in bold, being no one's to edit.
	 */
	public List<String> fixed (Block b)
	{
		List<String>	l = new ArrayList<String> (standard (b));

		for (String sym : wired (b))
			if (!l.contains (sym))		l.add (sym);
		return l;
	}

	/** Symbols the events of a block register, as the deployment says them. */
	public List<String> declared (Block b)
	{
		List<String>	in = new ArrayList<String> ();

		if ((b == null) || !hasEvents (b))					return in;
		for (String[] e : events (b))
		{
			String	sym = (e[0] != null) ? e[0].trim () : "";
			if ((sym.length () > 0) && !in.contains (sym))			in.add (sym);
		}
		return in;
	}

	/**
	 * Symbols a block is given: the ones its events register and the ones every
	 * thread of the runtime gets anyway, in the order they are registered in;
	 * and, for a router, the ones its code registers for, which is the whole
	 * traffic of a robot.
	 */
	public List<String> inputs (Block b)
	{
		List<String>	in = new ArrayList<String> ();

		if ((b == null) || !hasSymbols (b))					return in;
		if (b.kind == ROUTER)
		{
			for (List<String> syms : named (b).values ())
				for (String sym : syms)
					if (!in.contains (sym))		in.add (sym);
			return in;
		}
		in.addAll (declared (b));
		for (String sym : fixed (b))
			if (!in.contains (sym))		in.add (sym);
		return in;
	}

	/**
	 * Symbols a block produces: the ones the class it runs, or one of its
	 * ancestors, names -- which is how a module says what it writes, since a
	 * deployment only says what it is given -- less the ones it is given and less
	 * the ones a class is known to read rather than write.
	 *
	 * A router is the exception to the first of those: it routes what it is
	 * registered for, so what comes into it is what goes out of it, and taking
	 * the one from the other would leave it writing nothing.
	 *
	 * What is taken away is what the deployment asks for and not what the runtime
	 * hands out anyway: every thread is given CONFIG, and the robot, which is
	 * given it as they all are, is the one that writes it.
	 *
	 * And less, for the robot, the ones its platform carries no device for: see
	 * {@link #BY_DEVICE}.
	 */
	public List<String> produces (Block b)
	{
		List<String>				out = new ArrayList<String> ();
		List<String>				in;

		if ((b == null) || !hasSymbols (b))					return out;
		in		= (b.kind == ROUTER) ? inputs (b) : declared (b);
		for (java.util.Map.Entry<String, List<String>> e : named (b).entrySet ())
			for (String sym : e.getValue ())
			{
				if (out.contains (sym))											continue;
				// a symbol it only reads it does not write, however it is named in it
				if (isWired (b, sym, false))									continue;
				// nothing of this platform ever writes it: it carries no such device
				if (lacksDevice (b, sym))										continue;
				if (isWired (b, sym, true))										{ out.add (sym); continue; }
				if ((b.kind != ROUTER) && in.contains (sym))					continue;
				out.add (sym);
			}
		return out;
	}

	/**
	 * What a symbol carries, which is not a matter of opinion: a symbol is one
	 * kind of item and the deployment says which only because the runtime reads
	 * it there. It is worked out instead of being asked for.
	 *
	 * Where it is looked for, in this order: the events every thread registers by
	 * itself; the deployments of the project, which are what the project itself
	 * says a symbol carries (COORD, ZONE, PALLET_CTRL, whose classes are named
	 * after something else); and the items of the development named after the
	 * symbol, which is the rule the rest of them follow. Nothing found is nothing
	 * said: the answer is blank rather than a guess.
	 */
	public String itemClassOf (String symbol)
	{
		String		sym = (symbol == null) ? "" : symbol.trim ();
		String		found;

		if (sym.length () == 0)					return "";
		for (String[] e : STD_EVENTS)
			if (e[0].equals (sym))				return e[1];
		found	= learned ().get (sym);
		if (found != null)						return found;
		found	= named ().get (plain (sym));
		return (found != null) ? found : "";
	}

	/** A symbol and the name of an item class read as the same word: no underscores, no case. */
	static private String plain (String s)		{ return s.replace ("_", "").toUpperCase (); }

	static private java.util.Map<String, String>	LEARNED;
	static private java.util.Map<String, String>	NAMED;

	/** What the deployments of the project pair a symbol with, read once. */
	static private synchronized java.util.Map<String, String> learned ()
	{
		java.io.File[]	files;

		if (LEARNED != null)					return LEARNED;
		LEARNED	= new java.util.HashMap<String, String> ();
		files	= new java.io.File (DEPLOY_DIR).listFiles ();
		if (files == null)						return LEARNED;
		java.util.Arrays.sort (files);
		for (java.io.File f : files)
		{
			if (!f.getName ().toLowerCase ().endsWith ("." + DeployArch.EXTENSION))		continue;
			try
			{
				DeployArch	d = DeployArch.load (f);
				for (Robot r : d.robots)
				{
					List<Module>	ms = new ArrayList<Module> (r.modules);
					if (r.router != null)			ms.add (r.router);
					if (r.virtualRobot != null)		ms.add (r.virtualRobot);
					for (Module m : ms)
						for (Event e : m.events)
							if ((e.symbol != null) && (e.itemClass != null) && (e.itemClass.trim ().length () > 0))
								if (!LEARNED.containsKey (e.symbol))		LEARNED.put (e.symbol, e.itemClass.trim ());
				}
			} catch (Throwable e)		{ }						// a deployment that cannot be read teaches nothing
		}
		return LEARNED;
	}

	/** The items of the development, by the symbol their name reads as. */
	static private synchronized java.util.Map<String, String> named ()
	{
		if (NAMED != null)						return NAMED;
		NAMED	= new java.util.HashMap<String, String> ();
		for (String cls : tcapps.tceditor.DriverClasses.of (ITEM_BASE, false, true))
		{
			String	simple = cls.substring (cls.lastIndexOf ('.') + 1);
			if (!simple.startsWith ("Item") || simple.equals ("Item"))		continue;
			String	key = plain (simple.substring (4));
			if (!NAMED.containsKey (key))		NAMED.put (key, cls);
			// the control of a thing is CTRL in a symbol and either in a class name
			if (key.endsWith ("CONTROL"))		key = key.substring (0, key.length () - 7) + "CTRL";
			else if (key.endsWith ("CTRL"))		key = key.substring (0, key.length () - 4) + "CONTROL";
			else								continue;
			if (!NAMED.containsKey (key))		NAMED.put (key, cls);
		}
		return NAMED;
	}

	/** Forgets what the project and the development were read to say (either having changed). */
	static public synchronized void flushSymbols ()		{ LEARNED = null; NAMED = null; DESCS.clear (); }

	/**
	 * The methods of the class of a block an event carrying that item can arrive
	 * at: the ones that take exactly one of it, whatever else they take. A class
	 * the development does not hold has none to offer.
	 */
	public List<String> methodsFor (Block b, String itemClass)
	{
		java.util.TreeSet<String>	found = new java.util.TreeSet<String> ();
		String						cls;

		if ((b == null) || (itemClass == null) || (itemClass.trim ().length () == 0))		return new ArrayList<String> ();
		cls		= classOf (b);
		if (!tcapps.tceditor.DriverClasses.exists (cls))									return new ArrayList<String> ();
		try
		{
			Class<?>	item = Class.forName (itemClass.trim ());
			for (Class<?> c = Class.forName (cls); c != null; c = c.getSuperclass ())
				for (java.lang.reflect.Method m : c.getDeclaredMethods ())
				{
					int		n = 0;

					if (!java.lang.reflect.Modifier.isPublic (m.getModifiers ()))		continue;
					for (Class<?> p : m.getParameterTypes ())
						if (p == item)		n++;
					if (n == 1)				found.add (m.getName ());
				}
		} catch (Throwable e)		{ }							// what cannot be loaded offers nothing
		return new ArrayList<String> (found);
	}

	/** Replaces the events of a module (blank rows are dropped). */
	public void setEvents (Block b, List<String[]> rows)
	{
		Module	m = moduleOf (b);
		if (m == null)		return;
		m.events.clear ();
		for (String[] e : rows)
		{
			if ((e[0].trim ().length () == 0) && (e[1].trim ().length () == 0) && (e[2].trim ().length () == 0))		continue;
			m.events.add (new Event (e[0].trim (), e[1].trim (), e[2].trim ()));
		}
	}

	/**
	 * Every symbol there is to be recognised, which is what a class is read
	 * against: the keys defined in {@link tc.shared.linda.Tuple}, the ones the
	 * items of the development are named after -- a class writing a key of its
	 * own names it in full (GRIDMAP, FSEGMAP, VEHDATA, SYNC), and the item is
	 * what says the name is a symbol at all -- and the ones the deployments use.
	 */
	public List<String> symbols ()
	{
		java.util.TreeSet<String>	set = new java.util.TreeSet<String> (named ().keySet ());

		set.addAll (offered ());
		return new ArrayList<String> (set);
	}

	/**
	 * The symbols an event of a deployment can be registered for: the keys
	 * defined in {@link tc.shared.linda.Tuple} and the ones the deployments of
	 * the project use (COORD, ZONE, ...), less the ones every thread of the
	 * runtime is given anyway, since asking for CONFIG or EXECUTION is asking
	 * for what one already has.
	 */
	public List<String> offered ()
	{
		java.util.TreeSet<String>	set = new java.util.TreeSet<String> ();

		for (java.lang.reflect.Field f : tc.shared.linda.Tuple.class.getFields ())
			if (java.lang.reflect.Modifier.isStatic (f.getModifiers ()) && (f.getType () == String.class))
				try { set.add ((String) f.get (null)); } catch (Exception e) { }
		set.addAll (learned ().keySet ());							// what the deployments of the project use (COORD, ZONE, ...)
		for (Block b : allRobotBlocks ())
			if (hasEvents (b))
				for (String[] e : events (b))
					if (e[0].length () > 0)		set.add (e[0]);
		for (String[] e : STD_EVENTS)			set.remove (e[0]);
		return new ArrayList<String> (set);
	}

	/* ------------------------------------------------------------------ */
	/* Edition                                                             */
	/* ------------------------------------------------------------------ */

	public Block addGlobalLinda ()
	{
		if (deploy.globalLinda == null)		deploy.globalLinda = DeployArch.newGlobalLinda ();
		return new Block (GLOBAL_LINDA, -1);
	}

	/** Adds a robot named "Unnamed" (or "Unnamed2", ...) with its local Linda space and virtual robot, plus a Linda router when the deployment has a global Linda space. */
	public Block addRobot ()
	{
		String	name = DeployArch.DEFAULT_ROBOT;
		for (int i = 2; robotNames ().contains (name); i++)		name = DeployArch.DEFAULT_ROBOT + i;
		Robot	r = new Robot (name);
		if (deploy.globalLinda != null)		r.router = DeployArch.newRouter ();		// only with a global space to route to
		deploy.robots.add (r);
		return new Block (ROBOT, deploy.robots.size () - 1);
	}

	protected List<String> robotNames ()
	{
		List<String>	l = new ArrayList<String> ();
		for (Robot r : deploy.robots)		l.add (r.name);
		return l;
	}

	public Block addRouter (int r)
	{
		if (!hasRobot (r))				return null;
		if (robot (r).router == null)	robot (r).router = DeployArch.newRouter ();
		return new Block (ROUTER, r);
	}

	/** Adds a module named "Module 1", "Module 2", ... (first name not used in the robot). */
	public Block addModule (int r)
	{
		if (!hasRobot (r))				return null;
		robot (r).modules.add (DeployArch.newModule (uniqueModuleName (r, "Module")));
		return new Block (MODULE, r, robot (r).modules.size () - 1);
	}

	/**
	 * Adds a module of a kind ({@link #MODULE_TYPES}), named after it: "Perception"
	 * and, when the robot already has one, "Perception 2".
	 */
	public Block addModule (int r, String type)
	{
		if (!hasRobot (r))				return null;
		if (moduleTypeBase (type) == null)		return addModule (r);
		type	= type.trim ();
		robot (r).modules.add (DeployArch.newModule (uniqueName (r, type), type));
		return new Block (MODULE, r, robot (r).modules.size () - 1);
	}

	protected String uniqueModuleName (int r, String base)
	{
		List<String>	names = new ArrayList<String> ();
		for (Block b : robotBlocks (r))		names.add (labelOf (b));
		for (int i = 1; ; i++)
			if (!names.contains (base + " " + i))		return base + " " + i;
	}

	/** The name itself when the robot has nothing by it, and the name with a numeral when it has. */
	protected String uniqueName (int r, String base)
	{
		List<String>	names = new ArrayList<String> ();

		for (Block b : robotBlocks (r))		names.add (labelOf (b));
		if (!names.contains (base))			return base;
		for (int i = 2; ; i++)
			if (!names.contains (base + " " + i))		return base + " " + i;
	}

	/** Removes a block (the robot container removes the whole robot; local Linda and virtual robot cannot be removed). */
	public void remove (Block b)
	{
		switch (b.kind)
		{
		case GLOBAL_LINDA:	deploy.globalLinda = null;						break;
		case ROUTER:		if (hasRobot (b.robot))		robot (b.robot).router = null;	break;
		case MODULE:		if (moduleOf (b) != null)	robot (b.robot).modules.remove (b.index);	break;
		case ROBOT:			if (hasRobot (b.robot))		deploy.robots.remove (b.robot);	break;
		default:			break;
		}
	}
}
