/*
 * (c) 2002 Juan Pedro Canovas, Humberto Martinez Barbera
 * (c) 2003 Bernardo Canovas Segura
 * (c) 2004 Humberto Martinez Barbera
 */
 
package tcapps.tcsimulator.simulator.objects;

import tc.shared.world.WMAObject;

import wucore.utils.geom.*;
import wucore.utils.math.*;

public class SimMobileObject extends SimObject
{
	public final static int	CONSTANT_MOVE		= 121;
	public final static int	ACCELERATED_MOVE 	= 122;

	public double v;
	
	//MOVEMENT VALUES
	protected int	 m_type;
	
	public double SPEED; // Speed (metres per second)
	public double ACC;   // Acceleration (metres per square second)
	public double MASS = 0.4;  // Mass (Kilograms)

	public double RES_COEF = 0.75; // Restitution coeficient

	public double FRIC_COEF = 0.001; // Friction coeficient

	/** The movement parameters come from the world object (movement, speed, acceleration, mass, coef_res, coef_fric). */
	public SimMobileObject (WMAObject odesc)
	{
		super (odesc);

		m_type		= (odesc.movement == WMAObject.Movement.ACCELERATED) ? ACCELERATED_MOVE : 0;
		SPEED		= odesc.speed;
		ACC			= odesc.acceleration;
		MASS		= odesc.mass;
		RES_COEF	= odesc.coef_res;
		FRIC_COEF	= odesc.coef_fric;
	}
	
	/** Moves the object. Returns false if the object hasn't been moved */
	public boolean move (double time)
	{
		double ds, dv;

		switch (m_type)
		{
			case CONSTANT_MOVE:	
			case ACCELERATED_MOVE:  if (!((SPEED == 0.0) && (ACC == 0.0)))
 									{
										ds = SPEED*time;
										dv = (ACC*time) - (FRIC_COEF*9.8*time);
										SPEED = SPEED + dv;
										if (SPEED < 0.0)
											SPEED = 0.0;
										odesc.pos.x (odesc.pos.x () + (ds*Math.cos (odesc.a)));
										odesc.pos.y (odesc.pos.y () + (ds*Math.sin (odesc.a)));

										return (true);
									}
			
			default: return (false);
		}
	}
	
	/** Indicates odesc.a puntual collision of another object to this one
	 * @param edge : object's edge that has collided with this object
	 * @param xobj : horizontal position of the center of the collided object
	 * @param yobj : vertical position of the center of the collided object 
	 * @param aobj : angle of the collided object
	 * @param vobj : velocity of the collided object
	 * @param mobj : mass of the collided object
	 */
	public void object_collision (Line2 edge, double xobj, double yobj, double aobj, double vobj, double mobj)
	{
		recalc_angle(edge);
		SPEED=(mobj*SPEED+MASS*Math.abs(vobj)-mobj*RES_COEF*(Math.abs(vobj)-SPEED))/(MASS+mobj);
	}
	
	/** Indicates that an object 'pushes' this one 
	 * @param edge: Line of the object that pushes this one
	 * @param vobj: Velocity module ob the object
	*/
	public void object_pushed (Line2 edge, double vobj)
	{
		if (vobj == 0.0) // Is like odesc.a wall!
			wall_collision(edge);
		else
		{
			SPEED = Math.abs(vobj);

			// The angle of the object movement will be the same of the surface normal
			double xcomp, ycomp; // Normal vector components

			double dirx, diry, norx,nory,xproy,yproy;

			dirx = edge.dest().x()-edge.orig().x();
			diry = edge.dest().y()-edge.orig().y();
			// Special cases:
			if (dirx == 0.0) // Vertical line
			{
				xproy = edge.dest().x();
				yproy = odesc.pos.y ();
			}
			else if (diry == 0.0) // Horizontal line
			{
				xproy = odesc.pos.x ();
				yproy = edge.dest().y();
			}
			else
			{
				norx = -diry;
				nory= dirx;

				xproy = (-edge.orig().x()*diry*norx+edge.orig().y()*dirx*norx+odesc.pos.x()*nory*dirx-odesc.pos.y()*norx*dirx)/(nory*dirx-diry*norx);
				yproy = (xproy*nory-odesc.pos.x()*nory+odesc.pos.y()*norx)/norx;
			}
			xcomp=odesc.pos.x()-xproy;
			ycomp=odesc.pos.y()-yproy;

			if (Math.sqrt(xcomp*xcomp+ycomp*ycomp)==0) // ¿the edge length is 0?¿The edge is really odesc.a point?
				return;
			odesc.a = Math.acos(xcomp/Math.sqrt(xcomp*xcomp+ycomp*ycomp));

			// Extracts ball from robot
			double dist;
			dist = (radius-edge.distance(odesc.pos.x(),odesc.pos.y()))+0.02; // Added odesc.a 0.02 offset to avoid aproximation errors
			odesc.pos.x (odesc.pos.x() + dist*Math.cos(odesc.a));
			odesc.pos.y (odesc.pos.y() + dist*Math.sin(odesc.a));
		}
	} 
	
	/** Indicates odesc.a wall collision */
	public void wall_collision (Line2 wall)
	{
		SPEED=SPEED*RES_COEF;
		recalc_angle(wall);		
		// Avoid that the ball pass off the wall
		if (wall.distance(odesc.pos.x(),odesc.pos.y())<= radius)
		{
			double dist;
			dist = (radius-wall.distance(odesc.pos.x(),odesc.pos.y()))+0.02; // Added odesc.a 0.02 offset to avoid aproximation errors

			odesc.pos.x (odesc.pos.x()+dist*Math.cos(odesc.a));
			odesc.pos.y (odesc.pos.y()+dist*Math.sin(odesc.a));
		}
	}
	
	/** Recalculates angle after odesc.a collision with odesc.a surface */
	protected void recalc_angle(Line2 wall)
	{
		double Ntan = (wall.dest().x()-wall.orig().x())/(wall.orig().y()-wall.dest().y());
		double Nang = Math.atan (Ntan);
					
		if (Nang < 0) Nang += Angles.PI2;
		
		double alpha = Math.PI - (Nang - odesc.a);
		if (alpha < 0) alpha += Angles.PI2;
					
		odesc.a = Nang - alpha;
		if (odesc.a < 0) odesc.a += Angles.PI2;
	}

}
