/*
 * (c) 2026 Humberto Martinez Barbera
 */

package tcapps.tceditor;

/**
 * Reference to one editable element of a robot description: a kind, the index
 * inside its collection and, for a sensor, the family it belongs to. The
 * platform, the kinematics and the other properties use index 0.
 */
public class RobotItem
{
	static public final int		PLATFORM	= 0;		// name, radius, drawings
	static public final int		KINEMATICS	= 1;		// drive model and its parameters
	static public final int		LINE		= 2;		// a segment of the robot drawing
	static public final int		BUMPER		= 3;
	static public final int		SENSOR		= 4;		// one sensor of a family
	static public final int		FAMILY		= 5;		// the parameters shared by a family of sensors
	static public final int		EXTRA		= 6;		// the properties the model does not describe
	static public final int		WHEEL		= 7;		// one wheel of the drive train
	static public final int		GROUP		= 8;		// one sensor of an area: a sector standing for a group of the real ones
	static public final int		GROUPS		= 9;		// all of them together, as a family holds its sensors
	static public final int		FUSED		= 10;		// one fused sensor: one direction, read from the real sensors looking that way
	static public final int		FUSEDS		= 11;		// all of them together
	static public final int		SCAN		= 12;		// one reduced laser scan: the fan a laser is taken down to
	static public final int		SCANS		= 13;		// all of them together
	static public final int		FILTERING	= 14;		// both lots at once: what is worked out of the real sensors

	static public final int		NKINDS		= 15;

	static public final String[]	NAMES	= { "Platform", "Kinematics", "Drawing line", "Bumper", "Sensor", "Sensors",
												"Other properties", "Wheel", "Area group", "Area groups",
												"Fused sensor", "Fused sensors",
												"Laser reduction", "Laser reduction", "Sensor filtering" };

	public int			kind;
	public int			index;
	public String		family;						// only for SENSOR and FAMILY

	public RobotItem (int kind, int index)					{ this (kind, index, null); }

	public RobotItem (int kind, int index, String family)
	{
		this.kind	= kind;
		this.index	= index;
		this.family	= family;
	}

	public boolean equals (Object o)
	{
		if (!(o instanceof RobotItem))			return false;
		RobotItem	it = (RobotItem) o;
		return (it.kind == kind) && (it.index == index)
				&& ((it.family == null) ? (family == null) : it.family.equals (family));
	}

	public int hashCode ()
	{
		return kind * 100003 + index * 31 + ((family != null) ? family.hashCode () : 0);
	}

	public String toString ()
	{
		return NAMES[kind] + ((family != null) ? " " + family : "") + " " + index;
	}
}
